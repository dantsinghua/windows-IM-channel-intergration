'''
WeChatAuto
===========


微信4.0版本自动化主模块,实现了绝大多数的自动化功能,包括发送消息,文件,音视频通话等
所有的方法都位于这些静态类内,导入后使用XX.yy的方式使用即可

    - `AutoReply`:微信自动回复的一些方法,自动回复指定好友,自动回复会话列表所有新消息
    - `Call`:给某个好友打视频或语音电话
    - `Collections`:与收藏相关的一些方法
    - `Contacts`:获取通讯录联系人的一些方法
    - `Files`:关于微信文件的一些方法,包括发送文件,导出文件等功能
    - `Messages`:关于微信消息的一些方法,包括收发消息,获取聊天记录,获取聊天会话等功能
    - `Monitor`:关于微信监听消息的一些方法,包括监听单个聊天窗口的消息
    - `Moments`:与朋友圈相关的一些方法,发布朋友圈,导出朋友圈,好友朋友圈内容
    - `Settings`:与微信设置相关的一些方法,更换主题,更换语言,修改自动下载文件大小
    - `FriendSettings`:与好友设置相关的一些方法

Examples:
=========

使用模块时,你可以:
    ```
    >>> from pyweixin.WeChatAuto import Monitor
    >>> from pyweixin.WeChatTools import Navigator 
    >>> dialog_window=Navigator.open_seperate_dialog_window(friend='好友')
    >>> newMessages=Monitor.listen_on_chat(dialog_window,'1min')
    >>> print(newMessages)
    ```
或者:
    ```
    >>> from pyweixin import Monitor,Navigator
    >>> dialog_window=Navigator.open_seperate_dialog_window(friend='好友')
    >>> newMessages=Monitor.listen_on_chat(dialog_window,'1min')
    >>> print(newMessages)
    ```

Also:
====
    pyweixin内所有方法及函数的位置参数支持全局设定,be like:
    ```
        from pyweixin import Navigator,GlobalConfig
        GlobalConfig.load_delay=2.5
        GlobalConfig.is_maximize=True
        GlobalConfig.close_weixin=False
        Navigator.search_channels(search_content='微信4.0')
        Navigator.search_miniprogram(name='问卷星')
        Navigator.search_official_account(name='微信')
    ```

'''

#########################################依赖环境#####################################
#第三方库
import os
import re
import time
import json
import pyautogui
import win32clipboard
import win32gui,win32con
from typing import Literal
from warnings import warn
from pywinauto import WindowSpecification
from pywinauto.controls.uia_controls import ListItemWrapper,ListViewWrapper#TypeHint要用到
from typing import Callable
from packaging import version#字符串版本比较,4.1.9>4.1.8>4.1.7
#####################################################################################
#内部依赖
from .Config import GlobalConfig
from .utils import At,At_all,ColorMatch
from .utils import traverse_chat_history,traverse_message
from .utils import parse_chat_history,parse_group_chat_history
from .utils import parse_messages,parse_group_messages
from .utils import scan_for_new_messages,get_new_message_num,process_audios
from .Warnings import LongTextWarning,NoChatHistoryWarning
from .WeChatTools import Tools,Navigator,mouse,Desktop
from .WinSettings import SystemSettings
from .Errors import TimeNotCorrectError
from .Errors import NoFilesToSendError
from .Errors import NotFolderError
from .Errors import NotFriendError
from .Uielements import (Main_window,SideBar,Buttons,TabItems,
Edits,Texts,Lists,Panes,Windows,CheckBoxes,MenuItems,Groups,Customs,ListItems)#导入的是自动判断语言与版本后的实例化对象,如果自行使用需要导入xxx_Control
from .Uielements import Regex_Patterns,Special_Labels
from .Uielements import MousePos
#######################################################################################
desktop=Desktop(backend='uia')#pywinauto的windows桌面对象(WindowSpecification)实例化
pyautogui.FAILSAFE=False#防止鼠标在屏幕边缘处造成的误触
#主要功能：
class AutoReply():
    @staticmethod
    def auto_reply_to_friend(dialog_window:WindowSpecification,duration:str,callback:Callable[[str,list[str]],str],contexts:list[str]=[],save_file:bool=False,save_media:bool=False,target_folder:str=None,close_dialog_window:bool=True)->dict:
        '''
        该方法通过轮询的方式在指定时间内自动回复会话窗口内的新消息并监听内容
        Args:
            dialog_window:好友单独的聊天窗口或主界面内的聊天窗口,可使用Navigator内的open_seperate_dialoig_window打开
            duraiton:监听持续时长,监听消息持续时长,格式:'s','min','h'单位:s/秒,min/分,h/小时
            callback:新消息处理函数,入参是当前消息和上下文消息(可见的消息列表内的所有文本构成的列表)
            contexts:上下文信息字符串列表,可通过Messages.dump_chat_history获取后传入,在实际运行时会传入给callback函数
            save_file:是否保存文件,需开启自动下载文件并设置为1024MB,默认为False
            save_media:是否保存图片或视频
            target_folder:文件或图片的保存文件夹
            close_dialog_window:是否关闭dialog_window,默认关闭
        Examples:
            >>> from pyweixin import AutoReply,Navigator
            >>> def reply_func(newMessage:str,contexts:list[str]):
            >>>     return '自动回复[微信机器人]:您好,我当前不在,请您稍后再试'
            >>> main_window=Navigator.open_dialog_window(friend='abcdefghijklmnopqrstuvwxyz123456')
            >>> AutoReply.auto_reply_to_friend(dialog_window=main_window,duration='5min',callback=reply_func)
        Returns:
            details:该聊天窗口内的新消息(文本内容),格式为{'新消息总数':x,'文本数量':x,'文件数量':x,'图片数量':x,'视频数量':x,'链接数量':x,'文本内容':x}
        '''
        duration=Tools.match_duration(duration)#将's','min','h'转换为秒
        #不按照指定的时间格式输入,需要提前中断退出
        if duration is None:raise TimeNotCorrectError
        if save_file and target_folder is None:
            target_folder=os.path.join(os.getcwd(),f'{dialog_window.window_text()}_auto_reply_to_friend聊天文件保存')
            print(f'未传入文件夹路径,文件,图片,群昵称截图将分别保存到{target_folder}内的Files,Images,Alias文件夹下\n')
            os.makedirs(target_folder,exist_ok=True)
        if save_file:
            file_folder=os.path.join(target_folder,'Files')
            os.makedirs(file_folder,exist_ok=True)
        if save_media:
            media_folder=os.path.join(target_folder,'Media')
            os.makedirs(media_folder,exist_ok=True)
        files=[]
        texts=[]
        total=0
        link_count=0
        video_count=0
        image_count=0
        initial_runtime_id=0
        link_label=Special_Labels.Link
        image_labal=Special_Labels.Image
        video_label=Special_Labels.Video
        file_label=Special_Labels.File
        file_pattern=Regex_Patterns.File_pattern
        timestamp=time.strftime('%Y-%m')
        friend=dialog_window.window_text()
        chatName=dialog_window.child_window(**Texts.CurrentChatNameText)
        if chatName.exists(timeout=0.1):friend=chatName.window_text()
        chatfile_folder=Tools.where_chatfiles_folder()
        chatList=dialog_window.child_window(**Lists.FriendChatList)#聊天界面内存储所有信息的容器
        input_edit=dialog_window.child_window(**Edits.InputEdit)
        Tools.activate_chatList(chatList)
        if chatList.children(control_type='ListItem'):
            initial_message=chatList.children(control_type='ListItem')[-1]#刚打开聊天界面时的最后一条消息的listitem
            initial_runtime_id=initial_message.element_info.runtime_id    
        end_timestamp=time.time()+duration#根据秒数计算截止时间
        SystemSettings.open_listening_mode(volume=False)
        while time.time()<end_timestamp:
            if chatList.children(control_type='ListItem'):
                newMessage=chatList.children(control_type='ListItem')[-1]
                runtime_id=newMessage.element_info.runtime_id
                if runtime_id!=initial_runtime_id: 
                    total+=1
                    if newMessage.class_name()=='mmui::ChatTextItemView':
                        texts.append(newMessage.window_text())
                        dialog_window.restore()
                        is_my_bubble=Tools.is_my_bubble(newMessage)
                        if not is_my_bubble:
                            reply_content=callback(newMessage.window_text(),contexts)
                            if reply_content is not None:
                                input_edit.click_input()
                                input_edit.set_text(reply_content)
                                pyautogui.hotkey('alt','s')
                    if newMessage.class_name()=='mmui::ChatBubbleItemView' and newMessage.window_text()[:2]==link_label:
                        link_count+=1 
                    if newMessage.class_name()=='mmui::ChatBubbleReferItemView' and newMessage.window_text()==image_labal:
                        image_count+=1      
                    if newMessage.class_name()=='mmui::ChatBubbleReferItemView' and video_label in newMessage.window_text():
                        video_count+=1
                    if newMessage.class_name()=='mmui::ChatBubbleItemView' and file_label in newMessage.window_text():
                        filename=file_pattern.search(newMessage.window_text()).group(1)
                        filepath=os.path.join(chatfile_folder,timestamp,filename)
                        files.append(filepath)
                    initial_runtime_id=runtime_id
        media_count=image_count+video_count
        SystemSettings.close_listening_mode()
        if close_dialog_window:dialog_window.close()
        #最后结束时再批量复制到target_folder,不在循环里逐个复制是考虑到若文件过大(几百mb)没有自动下载完成移动不了
        if save_file and files:SystemSettings.copy_files(files,file_folder)#文件复制粘贴到target_folder/Files内
        if save_media and media_count:Messages.save_media(friend=friend,number=media_count,target_folder=target_folder)#保存图片到target_folder/Images内
        details={'新消息总数':total,'文本数量':len(texts),'文件数量':len(files),'图片数量':image_count,'视频数量':video_count,'链接数量':link_count,'文本内容':texts}
        return details
    
    @staticmethod
    def auto_reply_messages(callback:Callable[[str,str],str],duration:str,chatOnly:bool=False,maxPages:int=1,never_reply:list=[],scroll_delay:float=0.5,is_maximize:bool=None,close_weixin:bool=None)->dict:
        '''
        该方法用来遍历会话列表查找新消息自动回复,最大回复数量=max_pages*(8~10)
        Args:
            callback:新消息处理函数,入参是好友名称和当前消息
            duration:自动回复持续时长,格式:'s','min','h'单位:s/秒,min/分,h/小时
            chatOnly:不回复群聊只回复私聊(即使有群聊新消息也不回复)
            maxPages:遍历会话列表页数,一页为8~10人,为0时只在可见顶部置顶会话列表中查找不滚动遍历
            never_reply:在never_reply列表中的好友即使有新消息时也不会回复
            scroll_delay:滚动遍历max_pages页会话列表间隔
            is_maximize:微信界面是否全屏,默认全屏
            close_weixin:任务结束后是否关闭微信,默认关闭
        Examples:
            >>> from pyweixin import AutoReply
            >>> def reply_func(friend,newMessage):
            >>>     if friend!='家族群':
            >>>         if '你好' in newMessage:
            >>>             return '你好,亲~，在的,[呲牙]'#微信emoji表情可以用[表情名称]的格式文本输入
            >>>         if '产品A' in newMessage:
            >>>             return '产品A是我们的旗舰产品,详情可见 https:'
            >>>         return '不好意思,智能客服暂时未能理解您的需求,正在为您转人工服务,请稍等...'
            >>> AutoReply.auto_reply_messages(callback=reply_func,duration='3min',maxPages=0)#maxPages为0只在顶部置顶的好友中回复,不滚动遍历,安全性高
        Returns:
            responded_detail:{'好友':responded_friends,'群聊':responded_groups,'未回复群聊':unresponded_groups}
        '''
        def sacn_for_new_messages(sessionList:ListViewWrapper)->dict:
            new_message_dict={}
            full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)
            new_message_num=int(re.search(r'\d+',full_desc).group(0)) if re.search(r'\d+',full_desc) is not None else 0
            if new_message_num and scorllable:#有新消息且可以滚动的时候才滚动
                if maxPages:#maxPages设置为0，只关注顶部置顶可见的好友
                    for _ in range(maxPages):
                        traverse_result=traverse_session_list(sessionList)
                        new_message_dict.update(traverse_result)
                        sessionList.type_keys('{PGDN}',pause=scroll_delay)
                        if sum(new_message_dict.values())>=new_message_num:
                            break
                    sessionList.type_keys('{HOME}',pause=scroll_delay)
                else:#
                    traverse_result=traverse_session_list(sessionList)
                    new_message_dict.update(traverse_result)
            if new_message_num and not scorllable:
                traverse_result=traverse_session_list(sessionList)
                new_message_dict.update(traverse_result)
            return new_message_dict
        
        def traverse_session_list(sessionList:ListViewWrapper)->dict:
            listItems=[listItem for listItem in sessionList.children(control_type='ListItem') if listItem.automation_id().replace('session_item_','') not in NeverReply
            and muteNotifications_Lable not in listItem.window_text()]
            listItems=[listItem for listItem in listItems if new_message_pattern.search(listItem.window_text())]
            newMessageTips=[listItem.window_text() for listItem in listItems]
            senders=[listItem.automation_id().replace('session_item_','') for listItem in listItems]
            nums=[int(new_message_pattern.search(text).group(1)) for text in newMessageTips]
            newMessages_dict=dict(zip(senders,nums))
            return newMessages_dict

        #监听并且回复右侧聊天界面
        def reply_current_chat(initial_runtime_id):
            is_group_chat=Tools.is_group_chat(main_window)#判断是否是群聊
            chatList=main_window.child_window(**Main_window.FriendChatList)#聊天界面内存储所有聊天信息的消息列表
            #判断好友类型
            if is_group_chat:
                friend_type='群聊'
            if not is_group_chat:
                friend_type='好友' if chat_history_button.exists(timeout=0.1) else '非好友'   
            if friend_type!='非好友' and chatList.children(control_type='ListItem'):
                #自动回复逻辑
                current_chat_name=main_window.child_window(**Texts.CurrentChatNameText).window_text()#主界面右半部分左上角的聊天对象文本
                if friend_type=='好友' and current_chat_name not in NeverReply:
                    latest_message=chatList.children(control_type='ListItem')[-1]#最新的消息
                    runtime_id=latest_message.element_info.runtime_id
                    if runtime_id!=initial_runtime_id and not Tools.is_my_bubble(latest_message):#不等于刚打开页面时的那条消息且发送者是对方
                        input_edit.click_input()
                        reply_content=callback(current_chat_name,latest_message.window_text())
                        input_edit.set_text(reply_content)
                        pyautogui.hotkey('alt','s',_pause=False)
                        responded_friends.append(current_chat_name)
                if friend_type=='群聊' and current_chat_name not in NeverReply:
                    latest_message=chatList.children(control_type='ListItem')[-1]#最新的消息
                    runtime_id=latest_message.element_info.runtime_id
                    if runtime_id!=initial_runtime_id and not Tools.is_my_bubble(latest_message):
                        if not chatOnly:
                            input_edit.click_input()
                            reply_content=callback(current_chat_name,latest_message.window_text())
                            input_edit.set_text(reply_content)
                            pyautogui.hotkey('alt','s',_pause=False)
                            responded_friends.append(current_chat_name)
                            responded_groups.append(current_chat_name)
                        if chatOnly:#设置了仅回复私聊
                            unresponded_groups.append(current_chat_name)
                initial_runtime_id=chatList.children(control_type='ListItem')[-1].element_info.runtime_id
            return initial_runtime_id

        #用来回复在会话列表中找到的头顶有红色数字新消息提示的好友
        def reply_other_chat(friend:str):
            Navigator.find_friend_in_SessionList(friend=friend,search_pages=maxPages+1,is_maximize=is_maximize)
            is_group_chat=Tools.is_group_chat(main_window)#判断是否是群聊
            chatList=main_window.child_window(**Main_window.FriendChatList)
            if chatList.children(control_type='ListItem'):#有聊天记录时才判断然后回复,一片空白什么也不用做
                latest_message=chatList.children(control_type='ListItem')[-1]
                #判断好友类型
                if is_group_chat:
                    friend_type='群聊'
                if not is_group_chat:
                    friend_type='好友' if chat_history_button.exists(timeout=0.1) else '非好友'                
                if friend_type=='好友':
                    current_chat_name=main_window.child_window(**Texts.CurrentChatNameText).window_text()
                    if current_chat_name not in never_reply:
                        input_edit.click_input()
                        reply_content=callback(current_chat_name,latest_message.window_text())
                        input_edit.set_text(reply_content)
                        pyautogui.hotkey('alt','s',_pause=False)
                        responded_friends.append(friend) 
                if friend_type=='群聊':
                    current_chat_name=main_window.child_window(**Texts.CurrentChatNameText).window_text()
                    if not chatOnly and current_chat_name not in never_reply:
                        input_edit.click_input()
                        reply_content=callback(current_chat_name,latest_message.window_text())
                        input_edit.set_text(reply_content)
                        pyautogui.hotkey('alt','s',_pause=False)
                        responded_friends.append(friend) 
                        responded_groups.append(friend)
                    if current_chat_name not in never_reply and chatOnly:#设置了仅回复私聊
                        unresponded_groups.append(friend)

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        has_newMessage=True
        NeverReply=Special_Labels.NeverReply
        responded_friends=[]
        responded_groups=[]
        unresponded_groups=[]
        NeverReply.extend(never_reply)#所有不需要回复的对象合并在一起
        duration=Tools.match_duration(duration)
        if not duration:raise TimeNotCorrectError
        main_window=Navigator.open_weixin(is_maximize=is_maximize)
        weixinButton=main_window.child_window(**Buttons.WeixinButton)
        weixinButton.click_input()
        muteNotifications_Lable=Special_Labels.MuteNotifications
        new_message_pattern=Regex_Patterns.newMessage_pattern
        sessionList=main_window.child_window(**Main_window.SessionList)#左侧的会话列表
        input_edit=main_window.child_window(**Edits.CurrentChatEdit)
        chat_history_button=main_window.child_window(**Buttons.ChatHistoryButton)
        if chat_history_button.exists(timeout=0.1):#打开后的主界面是好友
            chatList=main_window.child_window(**Main_window.FriendChatList)#有聊天记录
            if chatList.children(control_type='ListItem'):
                initial_runtime_id=chatList.children(control_type='ListItem')[-1].element_info.runtime_id#刚打开聊天界面时的最后一条消息的runtime_id
            else:#无聊天记录
                initial_runtime_id=0
        else:#打开后的界面不是好友可能是公众号或其他什么界面
            initial_runtime_id=0
        full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)
        if re.search(r'\d+',full_desc) is not None:
            has_newMessage=True
            initial_newMessage_num=int(re.search(r'\d+',full_desc).group(0))
        else:
            has_newMessage=False
            initial_newMessage_num=0
        scorllable=Tools.is_scrollable(sessionList)#只调用一次Scrollable函数来判断会话列表是否可以滚动
        if scorllable:sessionList.type_keys('{HOME}')
        new_message_dict=sacn_for_new_messages(sessionList) if has_newMessage else {}
        end_timestamp=time.time()+duration
        SystemSettings.open_listening_mode()#开个不息屏,不然时间长息屏了就难办了
        #轮询自动回复，只干两件事儿，一边在会话列表查找新消息逐个回复，一边盯着当前聊天界面回复
        while time.time()<end_timestamp:
            if new_message_dict:#如果有新消息就挨个回复
                for sender,num in new_message_dict.items():reply_other_chat(sender)
                new_message_dict.clear()#回复完清空记录
            #盯着当前聊天界面
            initial_runtime_id=reply_current_chat(initial_runtime_id)
            full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)
            if re.search(r'\d+',full_desc) is not None:
                newMessage_num=int(re.search(r'\d+',full_desc).group(0))
            else:
                newMessage_num=0
            has_newMessage=newMessage_num-initial_newMessage_num#这个是关键，得判断用不用扫描，如果没变化不用扫描
            if has_newMessage:
                new_message_dict=sacn_for_new_messages(sessionList)
                initial_newMessage_num=newMessage_num
        SystemSettings.close_listening_mode()#最后把不息屏关掉
        #回复明细
        responded_friends=list(dict.fromkeys(responded_friends))
        responded_groups=list(dict.fromkeys(responded_groups))
        unresponded_groups=list(dict.fromkeys(unresponded_groups))
        responded_detail={'好友':responded_friends,'群聊':responded_groups,'未回复群聊':unresponded_groups}
        if close_weixin:main_window.close()
        return responded_detail
    
class Call():
    @staticmethod
    def voice_call(friend:str,wait:bool=False,is_maximize:bool=None,close_weixin:bool=None)->(WindowSpecification|None):
        '''
        该方法用来给好友拨打语音电话
        Args:
            friend:好友备注
            wait:是否等待接听,最多等待60s
            close_weixin:任务结束后是否关闭微信,默认关闭
        Returns:
            VoipCall_window:语音电话窗口,wait设置为True时返回,如果被挂断或接听超时返回None
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        current_version=version.parse(GlobalConfig.Version)
        old_version=version.parse('4.1.7')#4.1.8开始微信把语言和视频电话合并在顶部，并且在简体中文时更名为语音通话
        main_window=Navigator.open_dialog_window(friend=friend,is_maximize=is_maximize)  
        is_group=Tools.is_group_chat(main_window)
        voice_call_button=main_window.child_window(**Buttons.VoiceCallButton)
        if not is_group:
            if current_version>old_version:
                voice_call_button.click_input()
                pyautogui.press('down')
                pyautogui.press('enter')
            else:
                voice_call_button=main_window.child_window(**Buttons.VoiceCallButton)
                voice_call_button.click_input()
            hwnd=win32gui.FindWindow('Qt51514QWindowIcon',Special_Labels.VoipCall)
            VoipCall_window=Tools.move_window_to_center(Window_handle=hwnd)
            if close_weixin:main_window.close()
            if wait:
                try:
                    #等待出现接通后顶部的计时文本
                    VoipCall_window.child_window(class_name="mmui::VOIPDurationTextView").wait(wait_for='ready',timeout=55)
                    return VoipCall_window
                except Exception:
                    print(f'本次通话已挂断!')
                    return None
            return None
        if is_group:
            print(f'不支持群聊语音电话(SessionPicker-Window Ui自动化有Bug,微信会卡死崩溃！')
            if close_weixin:main_window.close()
            return None

    @staticmethod
    def video_call(friend:str,wait:bool=False,is_maximize:bool=None,close_weixin:bool=None)->(WindowSpecification|None):
        '''
        该方法用来给好友拨打视频电话
        Args:
            friend:好友备注
            wait:是否等待接听,最多等待60s
            close_weixin:任务结束后是否关闭微信,默认关闭
        Returns:
            VoipCall_window:视频电话窗口,wait设置为True时返回,如果被挂断或接听超时返回None
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        current_version=version.parse(GlobalConfig.Version)
        old_version=version.parse('4.1.7')#4.1.8开始微信把语言和视频电话合并在顶部
        main_window=Navigator.open_dialog_window(friend=friend,is_maximize=is_maximize) 
        is_group=Tools.is_group_chat(main_window)
        if not is_group: 
            if current_version>old_version:
                voice_call_button=main_window.child_window(**Buttons.VoiceCallButton)
                voice_call_button.click_input()
                pyautogui.press('down',presses=2)
                pyautogui.press('enter')
            else:
                video_call_button=main_window.child_window(**Buttons.VideoCallButton)
                video_call_button.click_input()
            hwnd=win32gui.FindWindow('Qt51514QWindowIcon',Special_Labels.VoipCall)
            VoipCall_window=Tools.move_window_to_center(Window_handle=hwnd)
            if close_weixin:main_window.close()
            if wait:
                try:
                    #等待出现接通后顶部的计时文本
                    VoipCall_window.child_window(class_name="mmui::VOIPDurationTextView").wait(wait_for='ready',timeout=55)
                    return VoipCall_window
                except Exception:
                    print(f'本次通话已挂断!')
                    return None
            return None
        if is_group:
            print(f'不支持群聊视频电话(SessionPicker-Window Ui自动化有Bug,微信会卡死崩溃！')
            if close_weixin:main_window.close()
            return None
    
       
class Collections():
    
    @staticmethod
    def take_notes(text:str,files:list[str]=[],share_moments:bool=False,is_maximize:bool=None,close_weixin:bool=None)->None:
        '''该方法用来新建一个微信笔记
        Args:
            text:笔记内的文本
            files:需要在单条笔记内保存的文件,单个不超过100MB
            is_maximize:微信界面是否全屏,默认全屏
            close_weixin:任务结束后是否关闭微信,默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if files:            
            files=[file for file in files if os.path.isfile(file)]
            files=[file for file in files if 0<os.path.getsize(file)<104857600]#0到100MB之间的文件才可以发送
        note_window=Navigator.open_note(is_maximize=is_maximize,close_weixin=close_weixin)
        edit_area=note_window.child_window(auto_id='xeditorInputId')
        if text:edit_area.set_text(text)
        if files:
            SystemSettings.copy_files_to_clipboard(files)
            pyautogui.hotkey('ctrl','v')
        pyautogui.hotkey('ctrl','s')
        if share_moments:
            note_window.child_window(**Buttons.MoreButton).click_input()
            pyautogui.press('up',presses=2)
            pyautogui.press('enter')
        note_window.close()

    # @staticmethod
    # def save_media(target_folder:str=None,number:int=None,scroll_delay:float=0.15,load_delay:float=0.5,is_maximize:bool=None,close_weixin:bool=None)->None:
    #     '''该方法用来保存收藏内的图片与视频(图片与视频的ui与其他项目并不完全相同,实现难度较大,建议先选择并设为标签后导出不然无法获取时间)
    #         Args:
    #         开发ing
    #     '''
    #     if is_maximize is None:
    #         is_maximize=GlobalConfig.is_maximize
    #     if close_weixin is None:
    #         close_weixin=GlobalConfig.close_weixin
    #     if target_folder is not None and not os.path.isdir(target_folder):
    #         raise NotFolderError(f'所选路径不是文件夹!无法保存聊天记录,请重新选择!')
    #     if target_folder is None:
    #         target_folder=os.path.join(os.getcwd(),'save_media收藏图片视频保存')
    #         os.makedirs(name=target_folder,exist_ok=True)
    #         print(f'未传入文件夹路径,聊天图片或视频将保存至 {target_folder}')

    #     main_window=Navigator.open_collections(is_maximize=is_maximize)
    #     media_listitem=main_window.child_window(**ListItems.MediaListItem)
    #     if not media_listitem.exists(timeout=0.2):
    #         main_window.close()
    #         return []
    #     saved_details=[]
    #     MediaGroup=main_window.child_window(control_type='Group',auto_id='fav_photo_list')
    #     mutltiselect_item=main_window.child_window(**MenuItems.SelectMenuItem)
    #     MediaGroup.type_keys('{HOME}')
    #     container=MediaGroup.children()[0].children()[0]
    #     visible_items=[listitem for listitem in container.children() if listitem.is_visible() and listitem.window_text()!=""]
    #     visible_items[-1].right_click_input()
    #     mutltiselect_item.click_input()

    
    @staticmethod
    def save_files(number:int,target_folder:str=None,scroll_delay:float=0.15,load_delay:float=0.5,is_maximize:bool=None,close_weixin:bool=None)->list[tuple]:
        '''该方法用来保存收藏内的文件
        Args:
            target_folder:导出收藏文件的文件夹
            number:需要导出的笔记数量
            scroll_delay:滚动暂停时间,默认0.15s
            load_delay:等待复制文件到剪贴板的时间,默认0.5s
        Returns:
            saved_details:[(6月2日,xxx.docx),(2021年6月2日,yyy.ppt)...]
        '''
        def save_file(FileListiem:ListItemWrapper):
            FileListiem.right_click_input()
            copy_item.click_input()
            filename=SystemSettings.save_pasted_file(target_folder)
            time.sleep(load_delay)#必须等待一会儿,不然剪贴板获取不到内容
            text=FileListiem.window_text()
            timestamp=Fav_Timestamp_pattern.findall(text)[-1].replace(' ','')
            return filename,timestamp
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if target_folder is not None and not os.path.isdir(target_folder):
            raise NotFolderError(f'所选路径不是文件夹!无法保存聊天记录,请重新选择!')
        if target_folder is None:
            target_folder=os.path.join(os.getcwd(),'save_files收藏文件保存')
            os.makedirs(name=target_folder,exist_ok=True)
            print(f'未传入文件夹路径,文件将保存至 {target_folder}')

        saved_num=0
        Fav_Timestamp_pattern=Regex_Patterns.Fav_Timestamp_pattern
        main_window=Navigator.open_collections(is_maximize=is_maximize)
        files_listitem=main_window.child_window(**ListItems.FilesListItem)
        copy_item=main_window.child_window(**MenuItems.CopyMenuItem)
        if not files_listitem.exists(timeout=0.3):
            main_window.close()
            return []
        saved_details=[]
        files_listitem.click_input()
        FilesList=main_window.child_window(**Lists.CollectionRightList)
        FilesList.type_keys('{HOME}')
        while saved_num<number:
            FilesList.type_keys('{DOWN}',pause=scroll_delay)
            selected=[item for item in FilesList.children(control_type='ListItem') if item.has_keyboard_focus()]
            if selected:
                saved_num+=1
                filename,timestamp=save_file(selected[0])
                saved_details.append((timestamp,filename)) 
            if not selected:
                break
        FilesList.type_keys('{HOME}')
        if close_weixin:main_window.close
        return saved_details
        
    @staticmethod
    def save_notes(number:int,target_folder:str=None,scroll_delay:float=0.1,load_delay:float=1.5,is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''该方法用来将收藏内的笔记导出为MarkDown
        Args:
            number:需要导出的笔记数量
            target_folder:导出markdown的文件夹
            scroll_delay:滚动暂停时间,默认0.15s
            load_delay:等待点击笔记后笔记窗口弹出的时间,默认1.5s
        Returns:
            saved_detail:['今天','昨天','6月15日',...],微信笔记的保存时间
        '''
        def extract_info(NoteListiem:ListItemWrapper):
            text=NoteListiem.window_text()
            timestamp=Fav_Timestamp_pattern.findall(text)[-1]
            return timestamp
    
        def export_favoriteTemp(NoteListiem:ListItemWrapper):
            output_dir=os.path.join(target_folder,str(saved_num))
            NoteListiem.double_click_input()
            try:
                note_window.wait(wait_for='ready',timeout=load_delay)
                files=[os.path.join(favoriteTemp_folder,item) for item in os.listdir(favoriteTemp_folder)]
                #清空output_dir是因为如果内部还有其他的htm无法判断哪个是微信笔记缓存里的htm
                SystemSettings.clear_folder_with_powershell(output_dir)
                SystemSettings.copy_files(files,output_dir)#迁移到本地来
                os.makedirs(output_dir,exist_ok=True)
                #清空微信收藏缓存文件夹,为了保证每次点击一个笔记只会把当前笔记内的所有东西保存到temp里
                #如果不清空随着点击打开笔记的次数增加，temp里的内容会增加,有多个htm也无法准确导出
                SystemSettings.clear_folder_with_powershell(favoriteTemp_folder)#必须用powershell命令才能删除,直接os.remove或shutil.rmtree都会遇到permission error
                remove_thumbs(output_dir)#去掉缩略图,微信缓存的缩略图tmd连个_t的后缀都不加根本无法直接区分,必须分组匹配比大小再删
                note_window.close()
            except Exception:
                pass
            return output_dir
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if target_folder is not None and not os.path.isdir(target_folder):
            raise NotFolderError(f'所选路径不是文件夹!无法保存聊天记录,请重新选择!')
        if target_folder is None:
            target_folder=os.path.join(os.getcwd(),'save_notes收藏笔记保存')
            os.makedirs(name=target_folder,exist_ok=True)
            print(f'未传入文件夹路径,笔记内容将保存至 {target_folder}')
       
        main_window=Navigator.open_collections(is_maximize=is_maximize)
        note_window=desktop.window(**Windows.NoteWindow)
        note_listitem=main_window.child_window(**ListItems.NotesListItem)
        if not note_listitem.exists(timeout=0.3):
            main_window.close()
            return []
        saved_num=0
        saved_details=[]
        from .Notes2MD import remove_thumbs,export_weixin_note
        favoriteTemp_folder=Tools.where_favoriteTemp_folder(False)
        Fav_Timestamp_pattern=Regex_Patterns.Fav_Timestamp_pattern
        SystemSettings.clear_folder_with_powershell(favoriteTemp_folder)
        NotesList=main_window.child_window(**Lists.CollectionRightList)
        mouse.click(coords=MousePos(main_window).ActiveNoteListPos)
        NotesList.type_keys('{HOME}')
        while saved_num<number:
            NotesList.type_keys('{DOWN}',pause=scroll_delay)
            selected=[item for item in NotesList.children(control_type='ListItem') if item.has_keyboard_focus()]
            if selected:
                saved_num+=1
                timestamp=extract_info(selected[0])
                saved_details.append(timestamp) 
                output_dir=export_favoriteTemp(selected[0])
                export_weixin_note(output_dir,md_name=f'{timestamp}.md')
            if not selected:
                break
        NotesList.type_keys('{HOME}')
        if close_weixin:main_window.close
        return saved_details

    @staticmethod
    def cardLink_to_url(number:int,delete:bool=False,scroll_delay:float=0.15,load_delay:float=0.5,is_maximize:bool=None,close_weixin:bool=None)->dict[str,str]:
        '''该方法用来获取收藏界面内指定数量的卡片链接的url,返回值为字典
        Args:
            number:卡片链接的数量
            delete:复制链接后是否将该条卡片链接移除掉
            scroll_delay:滚动暂停时间,默认0.15s
            load_delay:复制链接后的等待时间,默认为0.5s,不要设置太低,建议在0.5s左右。
            is_maximize:微信界面是否全屏,默认全屏
            close_weixin:任务结束后是否关闭微信,默认关闭
        Returns:
            links:{'https//':'卡片标题',...},url做key不可能重复,标题就不一定了
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin

        def copy_url(LinkListitem:ListItemWrapper):
            LinkListitem.right_click_input()
            copylink_item.click_input()
            win32clipboard.OpenClipboard()
            url=win32clipboard.GetClipboardData(win32clipboard.CF_UNICODETEXT)
            win32clipboard.CloseClipboard()
            if delete:
                LinkListitem.right_click_input()
                deletelink_item.click_input()
                delete_button.click_input()
            time.sleep(load_delay)#0.5是极限,等待复制到剪贴板
            return url
       
        timestamp_pattern=Regex_Patterns.Article_Timestamp_pattern
        main_window=Navigator.open_collections(is_maximize=is_maximize)
        link_item=main_window.child_window(**ListItems.LinkListItem)
        if not link_item.exists(timeout=0.3):
            main_window.close()
            return {}
        links={}
        copylink_item=main_window.child_window(**MenuItems.CopyLinkMenuItem)
        deletelink_item=main_window.child_window(**MenuItems.DeleteMenuItem)
        delete_button=main_window.child_window(**Buttons.DeleteButton)
        link_item.double_click_input()
        LinkList=main_window.child_window(**Lists.CollectionRightList)
        LinkList.type_keys('{HOME}')
        while True:
            LinkList.type_keys('{DOWN}',pause=scroll_delay)
            selected=[listitem for listitem in LinkList.children(control_type='ListItem') if listitem.has_keyboard_focus() and listitem.window_text()!='']
            if selected:
                title=timestamp_pattern.sub('',selected[0].window_text()[2:])#前两个字是固定的,为链接二字,后边的文本才是需要的替换掉时间戳
                url=copy_url(selected[0])
                links[url]=title
            if not selected:
                break
            if len(links)>=number:
                break
        LinkList.type_keys('{HOME}')
        if close_weixin:main_window.close()
        return links
    
    @staticmethod
    def collect_offAcc_articles(name:str,number:int,delay:float=0.3,is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用来收藏一定数量的某个公众号的文章
        Args:
            name:公众号名称
            delay:点击收藏后的延迟等待时间
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            collected_num:实际收藏的数量
        '''
        #注意,公众号窗口内的内容pywinauto,dump_tree后与inspect看到的不一致
        #使用pywinauto只能定位到每篇文章的发布日期,点赞数量这样的文本,该方法便是基于此实现,不断右键可见的每篇文章的日期点击收藏
        #pagedown翻页重复记录达到收藏数量或者已到达底部没有文章日期可用于点击
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        clicked=[]
        collected_num=0
        seperate_window=Navigator.open_seperate_dialog_window(friend=name,is_maximize=is_maximize,close_weixin=close_weixin)
        homepage_button=seperate_window.child_window(**Buttons.HomePageButton)
        homepage_button.double_click_input()
        offAcc_window=Tools.move_window_to_center(Window=Panes.OfficialAccountPane)
        seperate_window.close()
        offAcc_window.maximize()
        cardLinkPos=MousePos(offAcc_window).CardLinkPos
        offAcc_window.child_window(title='文章',control_type='Hyperlink').click_input()
        container=offAcc_window.child_window(control_type='Group')
        timestamp_pattern=Regex_Patterns.Article_Timestamp_pattern
        while collected_num<number:
            visible_texts=[child for child in container.children() if child.is_visible() and timestamp_pattern.search(child.window_text()) and child.element_info.runtime_id not in clicked]
            if visible_texts:
                for child in visible_texts:
                    collected_num+=1
                    time.sleep(delay)
                    child.right_click_input()
                    clicked.append(child.element_info.runtime_id)
                    offAcc_window.child_window(title='收藏',control_type='Text').click_input()
                    if collected_num>=number:
                        break
                mouse.click(coords=cardLinkPos)
                container.type_keys('{DOWN}'*4)
        offAcc_window.close()
        return collected_num

            
class Contacts():
    '''
    用来获取通讯录联系人的一些方法
    '''
    @staticmethod
    def check_my_info(is_maximize:bool=None,close_weixin:bool=None)->dict:
        '''
        该方法用来查看个人信息
        Args:
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            myinfo:个人资料{'昵称':,'微信号':,'地区':,'wxid':}
        '''
        #鼠标移动到朋友圈顶部右下角,点击头像按钮，激活弹出窗口
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        wxid=Tools.get_current_wxid()
        profile_pane,main_window=Navigator.open_my_profile(is_maximize=is_maximize)
        group=profile_pane.child_window(control_type='Group',found_index=3).children()[1]
        text_ctrls=group.descendants(control_type='Text')
        texts=[item.window_text() for item in text_ctrls]
        profile_pane.close()
        myinfo={'昵称':texts[0],'微信号':texts[2],'wxid':wxid}
        if len(texts)==5:
            myinfo['地区']=texts[4]
        if close_weixin:
            main_window.close()
        return myinfo

    @staticmethod
    def get_groupMembers_info(group:str,is_maximize:bool=None,search_pages:int=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来获取群聊内所有成员的名称
        Args:
            group:群聊名称
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            groupMembers:群成语名称列表,['xxx','yyy'...'zzz']
        '''
        #鼠标移动到朋友圈顶部右下角,点击头像按钮，激活弹出窗口
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        groupMembers=[]
        runtime_ids=[]
        main_window=Navigator.open_dialog_window(friend=group,is_maximize=is_maximize,search_pages=search_pages)
        is_group_chat=Tools.is_group_chat(main_window)
        chat_history_window=Navigator.open_chat_history(friend=group,is_maximize=is_maximize,search_pages=search_pages,close_weixin=close_weixin)
        if is_group_chat:
            total_num=int(re.search(rf'\((\d+)\)',chat_history_window.window_text()).group(1))
            win32gui.SendMessage(chat_history_window.handle,win32con.WM_SYSCOMMAND,win32con.SC_MAXIMIZE,0)
            Tools.cancel_pin(chat_history_window)
            chat_history_window.child_window(**TabItems.GroupMembersTabItem).click_input()
            pop_over=Tools.find_Popover()
            groupMember_list=pop_over.child_window(control_type='List')
            groupMember_list.type_keys('{PGUP}')#激活列表
            while len(groupMembers)<total_num:
                selected=[listitem for listitem in groupMember_list.children(control_type='ListItem') if listitem.has_keyboard_focus()]
                if selected and selected[0].window_text()!='':
                    runtime_ids.append(selected[0].element_info.runtime_id)
                    #同一个runtime_id挨着重复出现就说明到底部了无法继续下滑
                    if len(runtime_ids)>2 and runtime_ids[-1]==runtime_ids[-2]:
                        break
                    groupMembers.append(selected[0].window_text())
                pyautogui.press('down',_pause=False)
            groupMember_list.type_keys('{HOME}')
            pop_over.close()
        else:
            print(f'非群聊,无法获取群内成员名称!')
        chat_history_window.close()
        return groupMembers

    @staticmethod
    def get_friends_info(is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来快速获取通讯录内好友备注名称
        Args:

            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            friends_name:所有好友的名字(注意,同名的好友只保留一个!)
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin

        friends_name=[]
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        #鼠标移动到右侧
        area=(contact_custom.rectangle().mid_point().x,contact_custom.rectangle().mid_point().y)
        Tools.collapse_contacts(main_window,contact_list)
        contact_item=main_window.child_window(**ListItems.ContactsListItem)
        if contact_item.exists(timeout=0.1):
            contact_item.click_input()
            mouse.move(coords=area)
            contact_list.type_keys('{END}'*2)
            last_friend=contact_list.children(control_type='ListItem',class_name='mmui::ContactsCellItemView')[-1].window_text()
            contact_list.type_keys('{HOME}'*2)
            while True:
                names=[listitem.window_text() for listitem in contact_list.children(class_name='mmui::ContactsCellItemView')]
                friends_name.extend(names)
                if names[-1]==last_friend:
                    break
                contact_list.type_keys('{PGDN}')
            Tools.collapse_contacts(main_window,contact_list)
        friends_name=list(dict.fromkeys(friends_name))
        if close_weixin:
            main_window.close()
        return friends_name
    
    @staticmethod
    def get_wecom_friends_info(is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来快速获取通讯录内企业微信好友备注名称
        Args:

            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            friends_name:所有企业微信好友的名字(注意,同名的好友只保留一个!)
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin

        friends_name=[]
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        #鼠标移动到右侧
        area=(contact_custom.rectangle().mid_point().x,contact_custom.rectangle().mid_point().y)
        Tools.collapse_contacts(main_window,contact_list)
        wecom_item=main_window.child_window(**ListItems.WeComContactsListItems)
        if not wecom_item.exists(timeout=0.1):
            print(f'你没有企业微信联系人,无法获取企业微信好友信息！')
        else:
            wecom_item.click_input()
            mouse.move(coords=area)
            contact_list.type_keys('{END}'*2)
            last_friend=contact_list.children(control_type='ListItem',class_name='mmui::ContactsCellItemView')[-1].window_text()
            contact_list.type_keys('{HOME}'*2)
            while True:
                names=[listitem.window_text() for listitem in contact_list.children(class_name='mmui::ContactsCellItemView')]
                friends_name.extend(names)
                if names[-1]==last_friend:
                    break
                contact_list.type_keys('{PGDN}')
            Tools.collapse_contacts(main_window,contact_list)
        friends_name=list(dict.fromkeys(friends_name))
        if close_weixin:
            main_window.close()
        return friends_name
    
    @staticmethod
    def get_serAcc_info(is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来快速获取通讯录内所有服务号名称
        Args:

            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            friends_name:所有服务号的备注(注意,同名的服务号只保留一个!)
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin

        friends_name=[]
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        #鼠标移动到右侧
        area=(contact_custom.rectangle().mid_point().x,contact_custom.rectangle().mid_point().y)
        Tools.collapse_contacts(main_window,contact_list)
        if version.parse(GlobalConfig.Version)>=version.parse('4.1.12'):
            serAcc_item=main_window.child_window(**ListItems.offAndSerAccListItem)
        else:
            serAcc_item=main_window.child_window(**ListItems.SerAccListItem)
        if not serAcc_item.exists(timeout=0.2):
            print(f'你没有关注过任何服务号,无法获取服务号信息！')
        else:
            serAcc_item.click_input()
            mouse.move(coords=area)
            contact_list.type_keys('{END}'*2)
            last_friend=contact_list.children(control_type='ListItem',class_name='mmui::ContactsCellItemView')[-1].window_text()
            contact_list.type_keys('{HOME}'*2)
            while True:
                names=[listitem.window_text() for listitem in contact_list.children(class_name='mmui::ContactsCellItemView')]
                friends_name.extend(names)
                if names[-1]==last_friend:
                    break
                contact_list.type_keys('{PGDN}')
            Tools.collapse_contacts(main_window,contact_list)
        friends_name=list(dict.fromkeys(friends_name))
        if close_weixin:
            main_window.close()
        return friends_name

    @staticmethod
    def get_offAcc_info(is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来快速获取通讯录内所有公众号名称
        Args:

            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            friends_name:所有公众号的名称(注意,同名的公众号只保留一个!)
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin

        friends_name=[]
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        #鼠标移动到右侧
        area=(contact_custom.rectangle().mid_point().x,contact_custom.rectangle().mid_point().y)
        Tools.collapse_contacts(main_window,contact_list)
        if version.parse(GlobalConfig.Version)>=version.parse('4.1.12'):
            offAcc_item=main_window.child_window(**ListItems.offAndSerAccListItem)
        else:
            offAcc_item=main_window.child_window(**ListItems.OffAccListItem)
        if not offAcc_item.exists(timeout=0.2):
            print(f'你没有关注过任何公众号,无法获取公众号信息！')
        else:
            offAcc_item.click_input()
            mouse.move(coords=area)
            contact_list.type_keys('{END}'*2)
            last_friend=contact_list.children(control_type='ListItem',class_name='mmui::ContactsCellItemView')[-1].window_text()
            contact_list.type_keys('{HOME}'*2)
            while True:
                names=[listitem.window_text() for listitem in contact_list.children(class_name='mmui::ContactsCellItemView')]
                friends_name.extend(names)
                if names[-1]==last_friend:
                    break
                contact_list.type_keys('{PGDN}')
            Tools.collapse_contacts(main_window,contact_list)
        friends_name=list(dict.fromkeys(friends_name))
        if close_weixin:
            main_window.close()
        return friends_name

    @staticmethod
    def get_friends_detail(interval:float=0.1,is_maximize:bool=None,close_weixin:bool=None,is_json:bool=False)->(list[dict]|str):
        '''
        该方法用来获取通讯录内好友信息
        Args:
            interval:遍历过程中的停留间隔,默认为0.1秒
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
            is_json:是否以json格式返回
        Returns:
            friends_detail:所有好友的信息
        '''
        #切换到联系人分区内的第一个好友
        def switch_to_first_friend():
            contact_list.type_keys('{HOME}')
            items=contact_list.children(control_type='ListItem')
            for i in range(len(items)):
                if items[i]==contact_item and i<len(items)-1:
                    first_friend=i+1
                    if items[i+1].window_text()=='':
                        first_friend+=1
                    break
            items[first_friend].click_input()     
  
        #获取右侧好友信息面板
        def get_specific_info():
            wx_number='无'
            region='无'#好友的地区
            tag='无'#好友标签
            common_group_num='无'
            remark='无'#备注
            signature='无'#个性签名
            source='无'#好友来源
            descrption='无'#描述
            mobile='无'#电话号
            privacy='无'#朋友权限
            texts=contact_profile.descendants(control_type='Text')
            texts=[item.window_text() for item in texts]
            nickname=texts[0]
            if wxnum_label in texts:wx_number=texts[texts.index(wxnum_label)+1]#微信号
            if nickname_label in texts:nickname=texts[texts.index(nickname_label)+1]
            if region_label in texts:region=texts[texts.index(region_label)+1]
            if remark_label in texts:
                remark=texts[texts.index(remark_label)+1]
                if remark in labels:remark='无'
            if sharedgroups_label in texts:common_group_num=texts[texts.index(sharedgroups_label)+1]
            if signature_label in texts:signature=texts[texts.index(signature_label)+1]
            if source_label in texts:source=texts[texts.index(source_label)+1]
            if mobile_label in texts:mobile=texts[texts.index(mobile_label)+1]
            if description_label in texts:descrption=texts[texts.index(description_label)+1]
            if tags_label in texts:tag=texts[texts.index(tags_label)+1]
            if privacy_label in texts:privacy=texts[texts.index(privacy_label)+1]
            info={'昵称':nickname,'微信号':wx_number,'地区':region,'备注':remark,'电话':mobile,
            '标签':tag,'描述':descrption,'朋友权限':privacy,'共同群聊':f'{common_group_num}','个性签名':signature,'来源':source}
            return info
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        #所有的标签,这些标签的下一个便是其对应的值,即texts[texts.index(label)+1]
        wxnum_label=Special_Labels.WxNum
        nickname_label=Special_Labels.Nickname
        region_label=Special_Labels.Region
        remark_label=Special_Labels.Remark
        sharedgroups_label=Special_Labels.SharedGroups
        signature_label=Special_Labels.Signature
        source_label=Special_Labels.Source
        mobile_label=Special_Labels.Mobile
        description_label=Special_Labels.Description
        tags_label=Special_Labels.Tags
        privacy_label=Special_Labels.Privacy
        moments_label=Special_Labels.Moments
        friends_detail=[]
        labels={wxnum_label,nickname_label,region_label,remark_label,sharedgroups_label,signature_label,
        source_label,mobile_label,description_label,tags_label, privacy_label,moments_label}#联系人分区的标签
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        #右侧自定义面板下的好友信息所在面板
        contact_profile=contact_custom.child_window(**Groups.ContactProfileGroup)
        area=(contact_custom.rectangle().mid_point().x,contact_custom.rectangle().mid_point().y)
        #联系人分区
        Tools.collapse_contacts(main_window,contact_list)
        contact_item=main_window.child_window(**ListItems.ContactsListItem)
        if contact_item.exists(timeout=0.1):
            total_num=int(re.search(r'\d+',contact_item.window_text()).group(0))
            contact_item.click_input()
            switch_to_first_friend()#找到别切换到第一个好友
            info=get_specific_info()#获取该好友信息
            friends_detail.append(info)
            mouse.move(coords=area)#把鼠标移动右侧profile面板,如果在左侧
            for _ in range(total_num-1):
                if interval:time.sleep(interval)
                pyautogui.keyDown('down',_pause=False)#不能press,press比keydown更频繁容易被检测,keydown是一直长按
                info=get_specific_info()
                friends_detail.append(info)
            Tools.collapse_contacts(main_window,contact_list)
        if is_json:
            friends_detail=json.dumps(obj=friends_detail,ensure_ascii=False,indent=2)
        if close_weixin:
            main_window.close()
        return friends_detail

    @staticmethod
    def get_wecom_friends_detail(interval:float=0.1,is_maximize:bool=None,close_weixin:bool=None,is_json:bool=False)->(list[dict]|str):
        '''
        该方法用来获取通讯录内企业微信好友详细信息
        Args:
            interval:遍历过程中的停留间隔,默认为0.1秒
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
            is_json:是否以json格式返回
        Returns:
            friends_detail:所有企业微信好友的信息
        '''
        #切换到企业微信联系人分区内的第一个好友
        def switch_to_first_friend():
            contact_list.type_keys('{HOME}')
            items=contact_list.children(control_type='ListItem')
            for i in range(len(items)):
                if items[i]==wecom_item and i<len(items)-1:
                    first_friend=i+1
                    if items[i+1].window_text()=='':
                        first_friend+=1
                    break
            items[first_friend].click_input()
        
        #获取右侧好友信息面板内的具体信息
        def get_specific_info():
            company='无'#好友的企业
            remark='无'#备注
            realname='无'#实名
            state='在职'#员工状态
            duty='无'#职务
            online_time='无'#在线时间
            working_time='无'#工作时间
            location='无'#地址
            texts=contact_profile.descendants(control_type='Text')
            texts=[item.window_text() for item in texts]
            nickname=texts[0] 
            company=texts[texts.index(enterprise_label)+1]#微信号
            if nickname_label in texts:nickname=texts[texts.index(nickname_label)+1]
            if remark_label in texts:
                remark=texts[texts.index(remark_label)+1]
                if remark==enterprise_label or remark==moments_label:
                    remark='无'
            if realname_label in texts:realname=texts[texts.index(realname_label)+1]
            if duty_label in texts:duty=texts[texts.index(duty_label)+1]
            if state_label in texts:state=texts[texts.index(state_label)+1]
            if workingtime_label in texts:working_time=texts[texts.index(workingtime_label)+1]
            if onlinetime_label in texts:online_time=texts[texts.index(onlinetime_label)+1]
            if location_label in texts:location=texts[texts.index(location_label)+1]
            info={'昵称':nickname,'备注':remark,'企业':company,'实名':realname,'在职状态':state,
            '职务':duty,'工作时间':working_time,'在线时间':online_time,'地址':location}
            no_need_labels.extend(info.values())
            others=[text for text in texts if text not in no_need_labels and text!=f'@{company}']
            if others:info['其他']=others
            return info
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        #所有的标签,这些标签的下一个是其对应的值
        wecom_label=Special_Labels.WeCom
        nickname_label=Special_Labels.Nickname
        enterprise_label=Special_Labels.EnterPrise
        moments_label=Special_Labels.Moments
        remark_label=Special_Labels.Remark
        realname_label=Special_Labels.RealName
        duty_label=Special_Labels.Duty
        state_label=Special_Labels.State
        workingtime_label=Special_Labels.WorkingTime
        onlinetime_label=Special_Labels.OnlineTime
        location_label=Special_Labels.Location
        messages_label=Special_Labels.Messages
        voicecall_label=Special_Labels.VoiceCall
        from_label=Special_Labels.From
        enterinfo_label=Special_Labels.EnterPriseInfomation
        videocall_label=Special_Labels.VideoCall
        #没用的文本信息
        no_need_labels=[enterprise_label,nickname_label,remark_label,realname_label,duty_label,state_label,moments_label,workingtime_label,
        onlinetime_label,location_label,messages_label,voicecall_label,videocall_label,enterinfo_label,from_label,wecom_label]
        friends_detail=[]
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        #右侧自定义面板下的好友信息所在面板
        contact_profile=contact_custom.child_window(**Groups.ContactProfileGroup)
        area=(contact_custom.rectangle().mid_point().x,contact_custom.rectangle().mid_point().y)
        #企业微信联系人分区
        Tools.collapse_contacts(main_window,contact_list)
        wecom_item=main_window.child_window(**ListItems.WeComContactsListItems)
        if not wecom_item.exists(timeout=0.2):
            print(f'你没有企业微信联系人,无法获取企业微信好友信息！')
        else:
            total_num=int(re.search(r'\d+',wecom_item.window_text()).group(0))
            wecom_item.click_input()
            switch_to_first_friend()
            info=get_specific_info()
            friends_detail.append(info)
            mouse.move(coords=area)
            for _ in range(total_num+1):
                if interval:time.sleep(interval)
                pyautogui.keyDown('Down',_pause=False)
                info=get_specific_info()
                friends_detail.append(info)
            Tools.collapse_contacts(main_window,contact_list)
            if is_json:
                friends_detail=json.dumps(obj=friends_detail,ensure_ascii=False,indent=2)
        if close_weixin:main_window.close()
        return friends_detail 
    
    @staticmethod
    def get_serAcc_detail(interval:float=0.1,is_maximize:bool=None,close_weixin:bool=None,is_json:bool=False)->(list[dict]|str):
        '''
        该方法用来获取通讯录内服务号信息
        Args:
            interval:遍历过程中的停留间隔,默认为0.1秒
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
            is_json:是否以json格式返回
        Returns:
            friends_detail:所有关注过的服务号的详细信息
        '''
        def remove_duplicates(list):
            seen=set()
            result=[]
            for item in list:
                if item['微信号'] not in seen:
                    seen.add(item['微信号'])
                    result.append(item)
            return result

        #切换到服务号分区内的第一个好友
        def switch_to_first_friend():
            contact_list.type_keys('{HOME}')
            items=contact_list.children(control_type='ListItem')
            for i in range(len(items)):
                if items[i]==serAcc_item and i<len(items)-1:
                    first_friend=i+1
                    if items[i+1].window_text()=='':
                        first_friend+=1
                    break
            items[first_friend].click_input()
        
        #获取右侧好友信息面板内的具体信息
        def get_specific_info():
            texts=contact_profile.descendants(control_type='Text')
            texts=[item.window_text() for item in texts]
            name=texts[0]
            wx_number=texts[texts.index(wxnum_label)+1]
            if friendProfile_label in texts:
                description=texts[texts.index(friendProfile_label)+1]  
            else: 
                description='无'
            info={'名称':name,'微信号':wx_number,'描述':description}
            return info
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        wxnum_label=Special_Labels.WxNum
        friendProfile_label=Special_Labels.FriendProfile
        friends_detail=[]
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        area=(contact_custom.rectangle().mid_point().x,contact_custom.rectangle().mid_point().y)
        #右侧自定义面板下的好友信息所在面板
        contact_profile=contact_custom.child_window(**Groups.ContactProfileGroup)
        #企业微信联系人分区
        Tools.collapse_contacts(main_window,contact_list)
        if version.parse(GlobalConfig.Version)>=version.parse('4.1.12'):
            serAcc_item=main_window.child_window(**ListItems.offAndSerAccListItem)
        else:
            serAcc_item=main_window.child_window(**ListItems.SerAccListItem)
        if not serAcc_item.exists(timeout=0.2):
            print(f'你没有关注过任何服务号,无法获取服务号信息！')
        else:
            total_num=int(re.search(r'\d+',serAcc_item.window_text()).group(0))
            serAcc_item.click_input()
            switch_to_first_friend()
            info=get_specific_info()
            friends_detail.append(info)
            mouse.move(coords=area)
            for _ in range(total_num):
                time.sleep(interval)
                pyautogui.keyDown('Down',_pause=False)
                info=get_specific_info()
                friends_detail.append(info)
            Tools.collapse_contacts(main_window,contact_list)
            friends_detail=remove_duplicates(friends_detail)
            if is_json:
                friends_detail=json.dumps(obj=friends_detail,ensure_ascii=False,indent=2)
        if close_weixin:main_window.close()
        return friends_detail 

    @staticmethod
    def get_offAcc_detail(interval:float=0.1,is_maximize:bool=None,close_weixin:bool=None,is_json:bool=False)->(list[dict]|str):
        '''
        该方法用来获取通讯录内公众号信息
        Args:
            interval:遍历过程中的停留间隔,默认为0.1秒
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
            is_json:是否以json格式返回
        Returns:
            friends_detail:所有关注过的公众号的详细信息
        '''
        def remove_duplicates(list):
            seen=set()
            result=[]
            for item in list:
                if item['微信号'] not in seen:
                    seen.add(item['微信号'])
                    result.append(item)
            return result

        #切换到公众号分区内的第一个好友
        def switch_to_first_friend():
            contact_list.type_keys('{HOME}')
            items=contact_list.children(control_type='ListItem')
            for i in range(len(items)):
                if items[i]==offAcc_item and i<len(items)-1:
                    first_friend=i+1
                    if items[i+1].window_text()=='':
                        first_friend+=1
                    break
            items[first_friend].click_input()
        
        #获取右侧好友信息面板内的具体信息
        def get_specific_info():
            texts=contact_profile.descendants(control_type='Text')
            texts=[item.window_text() for item in texts]
            name=texts[0]
            wx_number=texts[texts.index(wxnum_label)+1]
            if friendProfile_label in texts:
                description=texts[texts.index(friendProfile_label)+1]  
            else: 
                description='无'
            info={'名称':name,'微信号':wx_number,'描述':description}
            return info
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        wxnum_label=Special_Labels.WxNum
        friendProfile_label=Special_Labels.FriendProfile
        friends_detail=[]
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        area=(contact_custom.rectangle().mid_point().x,contact_custom.rectangle().mid_point().y)
        #右侧自定义面板下的好友信息所在面板
        contact_profile=contact_custom.child_window(**Groups.ContactProfileGroup)
        #企业微信联系人分区
        Tools.collapse_contacts(main_window,contact_list)
        if version.parse(GlobalConfig.Version)>=version.parse('4.1.12'):
            offAcc_item=main_window.child_window(**ListItems.offAndSerAccListItem)
        else:
            offAcc_item=main_window.child_window(**ListItems.OffAccListItem)
        if not offAcc_item.exists(timeout=0.2):
            print(f'你没有关注过任何公众号,无法获取公众号信息！')
        else:
            total_num=int(re.search(r'\d+',offAcc_item.window_text()).group(0))
            offAcc_item.click_input()
            switch_to_first_friend()
            info=get_specific_info()
            friends_detail.append(info)
            mouse.move(coords=area)
            for _ in range(total_num):
                if interval:time.sleep(interval)
                pyautogui.keyDown('Down',_pause=False)
                info=get_specific_info()
                friends_detail.append(info)
            Tools.collapse_contacts(main_window,contact_list)
            friends_detail=remove_duplicates(friends_detail)
            if is_json:
                friends_detail=json.dumps(obj=friends_detail,ensure_ascii=False,indent=2)
        if close_weixin:main_window.close()
        return friends_detail 
        
    @staticmethod
    def get_groups_info(is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来获取我加入的所有群聊,原理是搜索个人昵称在群聊结果一栏中遍历查找
        Args:

            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            groups:所有已加入的群聊名称
        '''
        def switct_to_top():
            first_group=Tools.get_next_item(search_results,group_label)
            pyautogui.press('up',presses=4,_pause=False)
            pyautogui.press('down')
            focused_item=[listitem for listitem in 
            search_results.children(control_type='ListItem') 
            if listitem.has_keyboard_focus()]
            while focused_item[0]!=first_group:#当前选中对象不是群聊标签下方第一个群聊时一直向下
                pyautogui.press('down')
                focused_item=[listitem for listitem in 
                search_results.children(control_type='ListItem') 
                if listitem.has_keyboard_focus()]

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        groups=[]
        viewAll_label=Special_Labels.ViewAll
        main_window=Navigator.open_weixin(is_maximize=is_maximize)
        myname=Contacts.check_my_info(close_weixin=False,is_maximize=is_maximize).get('昵称')
        chat_button=main_window.child_window(**SideBar.Weixin)
        chat_button.click_input()
        search_edits=main_window.descendants(**Main_window.Search)
        search_edit=search_edits[1] if len(search_edits)==2 else search_edits[0]
        search_edit.click_input()
        search_edit.set_text(myname)
        search_results=main_window.child_window(title='',control_type='List')
        search_results.wait(wait_for='active',timeout=3)
        group_label=search_results.child_window(**ListItems.GroupLabelListItem)
        if group_label.exists(timeout=0.2):
            check_all_buttons=[button for button in search_results.children() if viewAll_label in button.window_text()]
            if check_all_buttons:
                total=int(re.search(r'\d+',check_all_buttons[0].window_text()).group(0))
                check_all_buttons[0].click_input()
                switct_to_top()
                for _ in range(total+1):
                    #获取灰色的被选中的listitem记录
                    focused_item=[listitem for listitem in search_results.children(control_type='ListItem',class_name="mmui::SearchContentCellView") if listitem.has_keyboard_focus()]
                    if focused_item:
                        groups.append(focused_item[0].window_text())
                    else:
                        break
                    pyautogui.press('down',_pause=False)
            else:
                total=4
                #先定位到群聊这个灰色标签
                length=len(search_results.children(control_type='ListItem'))
                for i in range(length):
                    if search_results.children(control_type='ListItem')[i]==group_label:#群聊标签的下一个，也就是第一个共同群聊
                        break
                for listitem in search_results.children(control_type='ListItem')[i:i+total]:
                    if listitem.class_name()=="mmui::SearchContentCellView":
                        groups.append(listitem.window_text())#
                #从前往后逆序倒过来total个
            groups=groups[-total:]
        chat_button.click_input()
        if close_weixin:main_window.close()
        return groups

    @staticmethod
    def get_common_groups(friend:str,is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来获取我与某些好友加入的所有共同群聊名称
        Args:

            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            groups:所有已加入的群聊名称
        '''
        def switct_to_top():
            first_group=Tools.get_next_item(search_results,group_label)
            pyautogui.press('up',presses=20,_pause=False)#回到顶部,无法使用Home健
            pyautogui.press('down')
            focused_item=[listitem for listitem in 
            search_results.children(control_type='ListItem') 
            if listitem.has_keyboard_focus()]
            while focused_item[0]!=first_group:#当前选中对象不是群聊标签下方第一个群聊时一直向下
                pyautogui.press('down')
                focused_item=[listitem for listitem in 
                search_results.children(control_type='ListItem') 
                if listitem.has_keyboard_focus()]

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        groups=[]
        viewAll_label=Special_Labels.ViewAll
        main_window=Navigator.open_weixin(is_maximize=is_maximize)
        chat_button=main_window.child_window(**SideBar.Weixin)
        chat_button.click_input()
        search_edits=main_window.descendants(**Main_window.Search)
        search_edit=search_edits[1] if len(search_edits)==2 else search_edits[0]
        search_edit.click_input()
        search_edit.set_text(friend)
        search_results=main_window.child_window(title='',control_type='List')
        search_results.wait(wait_for='ready',timeout=1)
        group_label=search_results.child_window(**ListItems.GroupLabelListItem)
        #微信搜索相关好友后会显示共同群聊，如果搜索结果中有群聊这个灰色标签的ListItem，说明有共同群聊
        if not group_label.exists():
            print(f'你与 {friend} 并无共同群聊!')
        else:#
            #只有当共同群聊数量大于4时候微信才会将其收起，此时有一个名为查看全部(\d+)的按钮
            check_all_buttons=[button for button in search_results.children() if viewAll_label in button.window_text()]
            if check_all_buttons:
                total=int(re.search(r'\d+',check_all_buttons[0].window_text()).group(0))
                check_all_buttons[0].click_input()#点一下查看全部按钮，此时focus的listitem是第共同群聊中的第四个
                switct_to_top()
                #然后按total+1下按钮获取被选中的listitem的window_text*()
                for _ in range(total+1):
                    #获取灰色的被选中的listitem记录
                    focused_item=[listitem for listitem in search_results.children(control_type='ListItem',class_name="mmui::SearchContentCellView") if listitem.has_keyboard_focus()]
                    if focused_item:
                        groups.append(focused_item[0].window_text())
                        pyautogui.press('down',_pause=False)
                    else:
                        break
            else:#共同群聊总数小于4,最多就是3
                total=4
                #先定位到群聊这个灰色标签
                length=len(search_results.children(control_type='ListItem'))
                for i in range(length):
                    if search_results.children(control_type='ListItem')[i]==group_label:#群聊标签的下一个，也就是第一个共同群聊
                        break
                for listitem in search_results.children(control_type='ListItem')[i:i+total]:
                    if listitem.class_name()=="mmui::SearchContentCellView":
                        groups.append(listitem.window_text())#
            #从前往后逆序倒过来total个
            groups=groups[-total:]
        chat_button.click_input()
        if close_weixin:main_window.close()
        return groups
    
    @staticmethod
    def get_friend_profile(friend:str,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用来获取单个好友的个人简介信息
        Args:
            friend:好友备注
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            profile:好友简介面板上的所有内容
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        wxnum_label=Special_Labels.WxNum
        nickname_label=Special_Labels.Nickname
        region_label=Special_Labels.Region
        remark_label=Special_Labels.Remark
        sharedgroups_label=Special_Labels.SharedGroups
        signature_label=Special_Labels.Signature
        source_label=Special_Labels.Source
        mobile_label=Special_Labels.Mobile
        description_label=Special_Labels.Description
        tags_label=Special_Labels.Tags
        privacy_label=Special_Labels.Privacy
        wx_number='无'#好友的微信号
        region='无'#好友的地区
        tag='无'#好友标签
        common_group_num='无'
        remark='无'#备注
        signature='无'#个性签名
        source='无'#好友来源
        descrption='无'#描述
        mobile='无'#电话号
        privacy='无'#朋友权限
        #没用的文本信息
        no_need_labels=['企业','昵称：','备注','实名','职务','员工状态','朋友圈','工作时间',
        '在线时间','地址','发消息','语音聊天','视频聊天','企业信息','来自','企业微信']
        profile_pane,main_window=Navigator.open_friend_profile(friend=friend,search_pages=search_pages,is_maximize=is_maximize)
        text_uis=profile_pane.descendants(control_type='Text')
        texts=[item.window_text() for item in text_uis]
        nickname=texts[0]#昵称肯定有
        if wxnum_label in texts:wx_number=texts[texts.index(wxnum_label)+1]
        if nickname_label in texts:nickname=texts[texts.index(nickname_label)+1]
        if region_label in texts:region=texts[texts.index(region_label)+1]
        if remark_label in texts:
            remark=texts[texts.index(remark_label)+1]
            if remark in no_need_labels:remark='无'
        if sharedgroups_label in texts:common_group_num=texts[texts.index(sharedgroups_label)+1]
        if signature_label in texts:signature=texts[texts.index(signature_label)+1]
        if source_label in texts:source=texts[texts.index(source_label)+1]
        if mobile_label in texts:mobile=texts[texts.index(mobile_label)+1]
        if description_label in texts:  descrption=texts[texts.index(description_label)+1]
        if tags_label in texts:tag=texts[texts.index(tags_label)+1]
        if privacy_label in texts:privacy=texts[texts.index(privacy_label)+1]
        profile={'昵称':nickname,'微信号':wx_number,'地区':region,'备注':remark,'电话':mobile,
        '标签':tag,'描述':descrption,'朋友权限':privacy,'共同群聊':f'{common_group_num}','个性签名':signature,'来源':source}
        main_window.child_window(**Buttons.ChatInfoButton).click_input()#点一下聊天信息按钮关闭侧边栏
        if close_weixin:main_window.close()
        return profile
    
    @staticmethod
    def get_recent_groups(is_maximize:bool=None,close_weixin:bool=None)->list[tuple[str]]:
        '''
        该方法用来获取最近群聊信息(包括群聊名称与群聊人数)
        Args:

            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            recent_groups:最近群聊信息
        '''
        def get_specific_info(texts):
            nums=[int(num_pattern.search(text).group(1)) for text in texts]
            names=[num_pattern.sub('',text) for text in texts]
            return names,nums

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
    
        texts=[]
        num_pattern=Regex_Patterns.GroupMember_Num_pattern
        contacts_manage=Navigator.open_contacts_manage(is_maximize=is_maximize,close_weixin=close_weixin)
        contacts_manage_list=contacts_manage.child_window(**Lists.ContactsManageList)
        recent_group=contacts_manage.child_window(**ListItems.RecentGroupListItem)
        Tools.collapse_contact_manage(contacts_manage)
        if not recent_group.exists(timeout=0.1):
            print(f'无最近群聊,无法获取!')
            contacts_manage.close()
            return []
        else:
            recent_group.click_input()
            contacts_manage_list.type_keys('{END}',pause=1)
            last=contacts_manage_list.children(control_type='ListItem',
            class_name="mmui::ContactsManagerControlSessionCell")[-1].window_text()
            contacts_manage_list.type_keys('{HOME}')
            listitems=contacts_manage_list.children(control_type='ListItem',class_name="mmui::ContactsManagerControlSessionCell")
            texts.extend([listitem.window_text() for listitem in listitems])
            while texts[-1]!=last:
                contacts_manage_list.type_keys('{PGDN}')
                listitems=contacts_manage_list.children(control_type='ListItem',class_name="mmui::ContactsManagerControlSessionCell")
                texts.extend([listitem.window_text() for listitem in listitems])
            texts=list(dict.fromkeys(texts))#保留顺序去重,Texts内是群聊+(人数)构成的文本,如果群聊名称与人数都相同那就没法筛选了
            group_names,member_nums=get_specific_info(texts)#正则提取与替换便是群名与人数
            recent_groups=list(zip(group_names,member_nums))#不使用dict(zip)是考虑到可能有相同群聊的,dict key不能有重复
            contacts_manage.close()
            return recent_groups

    @staticmethod
    def get_tags(is_maximize:bool=None,close_weixin:bool=None)->list[tuple[str]]:
        '''
        该方法用来获取所有标签(包括标签名称与该标签下的人数)
        Args:

            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            tags:所有的标签
        '''
        def get_specific_info(texts):
            nums=[int(num_pattern.search(text).group(1)) for text in texts]
            names=[num_pattern.sub('',text) for text in texts]
            return names,nums

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
    
        texts=[]
        num_pattern=Regex_Patterns.GroupMember_Num_pattern
        contacts_manage=Navigator.open_contacts_manage(is_maximize=is_maximize,close_weixin=close_weixin)
        contacts_manage_list=contacts_manage.child_window(**Lists.ContactsManageList)
        tag_item=contacts_manage.child_window(**ListItems.TagListItem)
        Tools.collapse_contact_manage(contacts_manage)
        if not tag_item.exists(timeout=0.3):
            print(f'无标签,无法获取!')
            contacts_manage.close()
            return []
        else:
            tag_item.click_input()
            contacts_manage_list.type_keys('{END}',pause=1)
            last=contacts_manage_list.children(control_type='ListItem',class_name="mmui::ContactsManagerControlLabelCell")[-1].window_text()
            contacts_manage_list.type_keys('{HOME}')
            listitems=contacts_manage_list.children(control_type='ListItem',class_name="mmui::ContactsManagerControlLabelCell")
            texts.extend([listitem.window_text() for listitem in listitems])
            while texts[-1]!=last:
                contacts_manage_list.type_keys('{PGDN}')
                listitems=contacts_manage_list.children(control_type='ListItem',class_name="mmui::ContactsManagerControlLabelCell")
                texts.extend([listitem.window_text() for listitem in listitems])
            texts=list(dict.fromkeys(texts))#保留顺序去重,Texts内是群聊+(人数)构成的文本,如果群聊名称与人数都相同那就没法筛选了
            tag_names,member_nums=get_specific_info(texts)#正则提取与替换便是群名与人数
            tags=list(zip(tag_names,member_nums))[1:]#不使用dict(zip)是考虑到可能有相同群聊的,dict key不能有重复
            contacts_manage.close()
            return tags
    
    @staticmethod
    def check_new_friends(verify:bool=False,limit:int=8,clear:bool=False,is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来检查一遍通讯录中新的朋友的信息,可以通过验证被动添加好友
        Args:
            verify:是否通过好友验证同意添加好友
            limit:通过验证的上限数:单次≤8人,每日≤4次,间隔≥2小时,无论新老号超过这个频率大概率封号
            clear:是否删除单条验证消息,遍历结束后会全部删除
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            newfriends_detail:所有新朋友的信息
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        
        def clear_item(current_item):
            current_item.right_click_input()
            pyautogui.press('down')
            pyautogui.press('enter')
        
        def friend_verification(current_item):
            time.sleep(1)
            if verify and verify_button.exists(timeout=0.1):
                verify_button.click_input()
                confirm_button=verifyFriend_window.child_window(**Buttons.ConfirmButton)
                confirm_button.click_input()
                current_item.click_input()
                return True
            return False

        verified_num=0
        newfriends_detail=[]
        #通讯录列表
        contact_list,main_window=Navigator.open_contacts(is_maximize=is_maximize)
        #右侧的自定义面板
        chat_button=main_window.child_window(**SideBar.Weixin)
        contact_custom=main_window.child_window(**Customs.ContactDetailCustom)
        verify_button=contact_custom.child_window(**Buttons.VerifyNowButton)
        more_button=contact_custom.child_window(**Buttons.MoreButton)
        Tools.collapse_contacts(main_window,contact_list)
        #验证好友窗口
        verifyFriend_window=desktop.window(**Windows.VerifyFriendWindow2)
        #新的朋友联系人分区
        newfriend_item=main_window.child_window(**ListItems.NewFriendListItem)
        if not newfriend_item.exists(timeout=0.1):
            print(f'你没有新的朋友,无法获取新的朋友信息!')
        if newfriend_item.exists(timeout=0.1):
            newfriend_item.click_input()
            contact_list.type_keys('{END}')
            newfriends=[listitem for listitem in contact_list.children() if listitem.class_name()=='mmui::XTableCell']
            if newfriends:
                last=newfriends[-1].window_text()
                contact_list.type_keys('{HOME}')
                contact_list.type_keys('{DOWN}'*2)
                selected=[listitem for listitem in contact_list.children(control_type='ListItem') if listitem.is_selected()]
                while selected[0].window_text()!=last:
                    newfriends_detail.append(selected[0].window_text())
                    if verified_num<limit:
                        is_verified=friend_verification(selected[0])
                        if is_verified:verified_num+=1
                    if clear:
                        clear_item(selected[0])
                        contact_list.children(control_type='ListItem')[2].click_input()
                    else:
                        pyautogui.keyDown('down')
                    selected=[listitem for listitem in contact_list.children(control_type='ListItem') if listitem.is_selected()]
            if clear:clear_item(selected[0])
            contact_list.type_keys('{HOME}')
            Tools.collapse_contacts(main_window,contact_list)
        chat_button.click_input()
        if close_weixin:main_window.close()
        return newfriends_detail


class FriendSettings():
    '''关于好友设置的一些方法'''
    
    @staticmethod
    def add_new_friend(number:str,greetings:str=None,remark:str=None,chat_only:bool=False,is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用来添加新朋友,不建议频繁使用,会封号!
        Args:
            number:微信号或手机号
            greetings:添加好友时的招呼用语
            remark:给对方的备注
            chat_only:朋友权限仅聊天
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        add_friend_pane,main_window=Navigator.open_add_friend_panel(is_maximize=is_maximize)
        search_edit=add_friend_pane.child_window(control_type='Edit')
        search_edit.set_text('')
        search_edit.type_keys(number,with_spaces=True)
        search_edit.type_keys('{ENTER}')
        contact_profile_view=add_friend_pane.child_window(**Groups.ContactProfileViewGroup)
        if contact_profile_view.exists(timeout=2):
            add_to_contact=contact_profile_view.child_window(**Buttons.AddToContactsButton)
            if add_to_contact.exists(timeout=2):
                add_to_contact.click_input()
                verify_friend_window=Tools.move_window_to_center(Window=Windows.VerifyFriendWindow)
                request_content_edit=verify_friend_window.child_window(control_type='Edit',found_index=0)
                remark_edit=verify_friend_window.child_window(control_type='Edit',found_index=1)
                chat_only_group=verify_friend_window.child_window(**Groups.ChatOnlyGroup)
                confirm_button=verify_friend_window.child_window(**Buttons.ConfirmButton)
                if greetings is not None:
                    request_content_edit.set_text(greetings)
                if remark is not None:
                    remark_edit.set_text(remark)
                if chat_only:
                    chat_only_group.click_input()
                confirm_button.click_input()
        add_friend_pane.close()
        if close_weixin:
            main_window.close()

    @staticmethod
    def mute_notification(friend:str,mute:int=0,fold_chat:int=0,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来将好友消息设置为免打扰和折叠聊天,只有在免打扰开启的时候才可以设置折叠聊天
        Args:
            friend:好友备注
            mute:关闭或设置为消息免打扰,0:关闭消息免打扰,1:开启消息免打扰
            fold_chat:是否折叠聊天,0:取消折叠聊天,1:开启折叠聊天
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if mute not in {0,1}:
            raise ValueError('mute的取整为0或1!')
        if fold_chat not in {0,1}:
            raise ValueError('fold_chat的取整为0或1!')
        chatinfo_pane,main_window=Navigator.open_chatinfo(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        chatinfo_button=main_window.child_window(**Buttons.ChatInfoButton)       
        mute_notification=chatinfo_pane.child_window(**CheckBoxes.MuteNotificationsCheckBox)
        foldchat=chatinfo_pane.child_window(**CheckBoxes.FoldChatCheckBox)
        if not mute_notification.get_toggle_state() and mute==1:
            mute_notification.click_input()
        if mute_notification.get_toggle_state() and mute==0:
            mute_notification.click_input()
        if foldchat.exists(timeout=0.1):
            if fold_chat==1 and not foldchat.get_toggle_state():
                foldchat.click_input()
            if fold_chat==0 and foldchat.get_toggle_state():
                fold_chat.click_input()
        chatinfo_button.click_input()
        if close_weixin:
            main_window.close()

    @staticmethod
    def pin_chat(friend:str,state:int=0,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来将好友聊天置顶
        Args:
            friend:好友备注
            state:置顶或不置顶,0:不置顶,1:置顶
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if state not in {0,1}:
            raise ValueError('state的取整为0或1!')
        chatinfo_pane,main_window=Navigator.open_chatinfo(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        chatinfo_button=main_window.child_window(**Buttons.ChatInfoButton)
        pinchat=chatinfo_pane.child_window(**CheckBoxes.PinChatCheckBox)
        if state==1 and not pinchat.get_toggle_state():
            pinchat.click_input()
        if state==0 and pinchat.get_toggle_state():
            pinchat.click_input()
        chatinfo_button.click_input()
        if close_weixin:
            main_window.close()

    @staticmethod
    def clear_chat_history(friend:str,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来清空与好友的聊天记录
        Args:
            friend:好友备注
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        chatinfo_pane,main_window=Navigator.open_chatinfo(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        chatinfo_button=main_window.child_window(**Buttons.ChatInfoButton)
        chatinfo_pane.child_window(**Buttons.ClearChatHistoryButton).click_input()
        main_window.child_window(**Buttons.EmptyButton).click_input()
        chatinfo_button.click_input()
        if close_weixin:main_window.close()

    @staticmethod
    def change_privacy(friend:str,chat_privacy:int=1,sns_privacy:int=0,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来设置好友权限
        Args:
            friend:好友备注
            chat_privacy:0:仅聊天,1:聊天,朋友圈,微信运动等
            sns_privacy:0:取消所有朋友圈权限,1:不让他看,2:不看他
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if chat_privacy not in {0,1}:
            raise ValueError('chat_privacy的取整为0或1!')
        if sns_privacy not in {0,1,}:
            raise ValueError('sns_privac的取整为0,1,!')
        profile_pane,main_window=Navigator.open_friend_profile(friend=friend,is_maximize=is_maximize)
        chatinfo_button=main_window.child_window(**Buttons.ChatInfoButton)
        more_button=profile_pane.child_window(**Buttons.MoreButton)
        more_button.click_input()
        pyautogui.press('down',presses=2)
        pyautogui.press('enter')
        if version.parse(GlobalConfig.Version)>=version.parse('4.1.9'):
            privacy_window=Tools.move_window_to_center(Windows.PrivacyWindow)
        else:
            privacy_window=profile_pane
        open_privacy_group=privacy_window.child_window(**Groups.OpenPrivacyGroup)
        chat_only_group=privacy_window.child_window(**Groups.ChatOnlyGroup)
        check_box1=privacy_window.child_window(**CheckBoxes.DontShowOthersCheckBox)
        check_box2=privacy_window.child_window(**CheckBoxes.DontSeeOthersCheckBox)
        if chat_privacy==1:
             open_privacy_group.click_input()
        if chat_privacy==0:
            chat_only_group.click_input()
        if check_box1.exists(timeout=0.1):
            if sns_privacy==0:
                if check_box1.get_toggle_state():
                    check_box1.click_input()
                if check_box2.get_toggle_state():   
                    check_box2.click_input()                                                    
            if sns_privacy==1: 
                if not check_box1.get_toggle_state():
                    check_box1.click_input()
            if sns_privacy==2:
                if not check_box2.get_toggle_state():
                    check_box2.click_input()
        complete_button=privacy_window.child_window(**Buttons.FinishButton)
        if complete_button.exists(timeout=0.2):
            complete_button.click_input()
        chatinfo_button.click_input()
        if close_weixin:
            main_window.close()

    @staticmethod
    def star_friend(friend:str,state:int=1,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来将好友设为星标朋友或取消星标朋友
        Args:
            friend:好友备注
            state:设置为星标朋友还是取消设置为星标朋友
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if state not in {0,1}:
            raise ValueError('state的取整为0或1!')
        star=Special_Labels.Star
        unstar=Special_Labels.UnStar
        profile_pane,main_window=Navigator.open_friend_profile(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        more_button=profile_pane.child_window(**Buttons.MoreButton)
        more_button.click_input()
        pyautogui.press('down',presses=4)
        menu=profile_pane.child_window(class_name='mmui::XMenu',title='Weixin')
        selected_item=[item for item in menu.children(control_type='MenuItem') if item.has_keyboard_focus()]
        if selected_item[0].window_text()==star and state==1:
            pyautogui.press('enter')
        if selected_item[0].window_text()==unstar and state==0:
            pyautogui.press('enter')
        main_window.child_window(**Buttons.ChatInfoButton).click_input()
        if close_weixin:
            main_window.close()

    @staticmethod
    def delete_friend(friend:str,clear_chat_history:int=1,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来删除好友
        Args:
            friend:好友备注
            clear_chat_history:删除好友时是否勾选清空聊天记录,1清空,0不清空
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if clear_chat_history not in {0,1}:
            raise ValueError('clear_chat_history的取整为0或1!')
        profile_pane,main_window=Navigator.open_friend_profile(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        more_button=profile_pane.child_window(**Buttons.MoreButton)
        more_button.click_input()
        pyautogui.press('down',presses=6)
        pyautogui.press('enter')
        check_box=profile_pane.child_window(title='',control_type='CheckBox')
        if not clear_chat_history:
            check_box.click_input()
        delete_button=profile_pane.child_window(**Buttons.DeleteButton)
        delete_button.click_input()
        main_window.child_window(**Buttons.ChatInfoButton).click_input()
        if close_weixin:
            main_window.close()
    
    @staticmethod
    def block_friend(friend:str,state:int=0,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来将好友添加至黑名单或从黑名单移出
        Args:
            friend:好友备注
            state:将好友移出黑名单还是加入黑名单,0移出黑名单,1加入黑名单
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if state not in {0,1}:
            raise ValueError('state的取整为0或1!')
        block=Special_Labels.Block
        unblock=Special_Labels.UnBlock
        profile_pane,main_window=Navigator.open_friend_profile(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        more_button=profile_pane.child_window(**Buttons.MoreButton)
        more_button.click_input()
        pyautogui.press('down',presses=5)
        menu=profile_pane.child_window(class_name='mmui::XMenu',title='Weixin')
        selected_item=[item for item in menu.children(control_type='MenuItem') if item.has_keyboard_focus()]
        if selected_item[0].window_text()==block and state==1:
            pyautogui.press('enter')
            confirm_button=profile_pane.child_window(**Buttons.ConfirmButton)
            confirm_button.click_input()
        if selected_item[0].window_text()==unblock and state==0:
            pyautogui.press('enter')
        main_window.child_window(**Buttons.ChatInfoButton).click_input()
        if close_weixin:
            main_window.close()
    
    @staticmethod
    def change_remark(friend:str,remark:str,description:str=None,phoneNum:str=None,clear_phoneNum:bool=False,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来修改好友备注,描述,电话号码等内容
        Args:
            friend:好友备注
            remark:待修改的备注
            description:对好友的描述
            phoneNum:电话号码
            clear_phoneNum:清空之前所有的电话号码
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        profile_pane,main_window=Navigator.open_friend_profile(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        profile_pane.child_window(**Buttons.MoreButton).click_input()
        pyautogui.press('down',presses=1)
        pyautogui.press('enter')
        if version.parse(GlobalConfig.Version)>=version.parse('4.1.9'):
            remarkAndtag_window=Tools.move_window_to_center(Windows.EditContactWindow)
        else:
            remarkAndtag_window=main_window.window(**Windows.EditContactWindow)
        remark_edit=remarkAndtag_window.child_window(control_type='Edit',found_index=0)
        clearPhoneNum_buttons=remarkAndtag_window.descendants(**Buttons.ClearPhoneNumButton)
        if clearPhoneNum_buttons and clear_phoneNum:
            for button in clearPhoneNum_buttons:
                button.click_input()
        if isinstance(phoneNum,str):
            addphone_button=remarkAndtag_window.child_window(**Buttons.AddPhoneNumButon)
            addphone_button.click_input()
            remarkAndtag_window.child_window(control_type='Edit',found_index=1).set_text(phoneNum)
        if isinstance(description,str):
            description_edit=remarkAndtag_window.child_window(control_type='Edit',found_index=2)
            description_edit.set_text(description)
        addphone_button=remarkAndtag_window.child_window(**Buttons.AddPhoneNumButon)
        remark_edit.set_text(remark)
        confirm_button=remarkAndtag_window.child_window(**Buttons.FinishButton)
        confirm_button.click_input()
        main_window.child_window(**Buttons.ChatInfoButton).click_input()
        if close_weixin:
            main_window.close()
    
    @staticmethod
    def get_common_groups(friend:str,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None)->list[str]:
        '''
        该方法用来获取我与某些好友加入的所有共同群聊名称
        Args:
            friend:好友备注
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            groups:所有已加入的群聊名称
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        common_groups=[]
        profile_window,main_window=Navigator.open_friend_profile(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        scroll_pos=MousePos(profile_window).ProfileWindowScrollPos
        mouse.scroll(coords=scroll_pos,wheel_dist=-100)
        shared_groups_label=profile_window.child_window(**Texts.SharedGroupsText)
        if shared_groups_label.exists(timeout=2):
            shared_groups_button=shared_groups_label.parent().parent().descendants(control_type='Button')[0]
            number_text=shared_groups_button.descendants(control_type='Text')[-1]
            total_num=int(number_text.window_text().replace('个','').replace('個',''))
            shared_groups_button.click_input()
            popup_window=desktop.window(title_re=r'\d+',control_type='Window',class_name='mmui::ProfileUniquePop')
            shared_groups_list=popup_window.child_window(**Lists.CommonGroupList)
            shared_groups_list.type_keys('{END}')
            last_item=shared_groups_list.children()[-1].window_text()
            shared_groups_list.type_keys('{HOME}')
            while len(common_groups)<total_num:
                texts=[listitem.window_text() for listitem in shared_groups_list.children()]
                texts=[text for text in texts if text not in  common_groups]
                common_groups.extend(texts)
                shared_groups_list.type_keys('{PGDN}')
                if common_groups[-1]==last_item:
                    break
        profile_window.close()
        main_window.child_window(**Buttons.ChatInfoButton).click_input() 
        if close_weixin:
            main_window.close()
        return common_groups

    # @staticmethod
    # # SessionPicker window无法ui自动化,微信直接白屏卡死程序崩溃！不信,可以尝试一下
    # def add_tag(friends:list[str],tag:str,is_maximize:bool=None,window_maximize:bool=None,close_weixin:bool=None):
    #     '''
    #     该方法用来批量给好友设置标签
    #     Args:
    #         friends:所有的好友备注列表
    #         tag:标签名字
    #         is_maximize:微信界面是否全屏，默认不全屏
    #         close_weixin:任务结束后是否关闭微信，默认关闭
    #     '''
    #     def session_picker():
    #         SessionPickerWindow=Windows.SessionPickerWindow
    #         SessionPickerWindow['title']='微信添加成员'
    #         session_pick_window=contacts_manage.child_window(**Windows.SessionPickerWindow)
    #         complete_button=session_pick_window.child_window(**Buttons.FinishButton)
    #         checkbox=session_pick_window.child_window(control_type='CheckBox',found_index=0)
    #         search_field=session_pick_window.child_window(control_type='Edit',found_index=0)
    #         search_field.click_input()
    #         for friend in friends:
    #             search_field.set_text(friend)
    #             time.sleep(1)
    #             checkbox.click_input()
    #             search_field.click_input()
    #             search_field.set_text('')
    #         complete_button.click_input()
    #     if is_maximize is None:
    #         is_maximize=GlobalConfig.is_maximize
    #     if close_weixin is None:
    #         close_weixin=GlobalConfig.close_weixin
    #     if window_maximize is None:
    #         window_maximize=GlobalConfig.window_maximize
    #     contacts_manage=Navigator.open_contacts_manage(is_maximize=is_maximize,window_maximize=window_maximize,close_weixin=close_weixin)
    #     add_button=contacts_manage.child_window(**Buttons.AddButton)
    #     tagListItem=contacts_manage.child_window(**ListItems.TagListItem)
    #     contacts_manage_list=contacts_manage.child_window(**Lists.ContactsManageList)
    #     Tools.collapse_contact_manage(contacts_manage)
    #     tagListItem.click_input()
    #     contacts_manage_list.type_keys('{END}')
    #     createLabelListItem=contacts_manage_list.children(**ListItems.CreateLabelListItem)[0]
    #     createLabelListItem.click_input()
    #     pyautogui.hotkey('ctrl','a')
    #     pyautogui.press('backspace')
    #     SystemSettings.copy_text_to_clipboard(tag)
    #     pyautogui.hotkey('ctrl','v')
    #     pyautogui.press('enter')
    #     add_button.click_input()
    #     session_picker()


class Files():
    @staticmethod
    def send_files_to_friend(friend:str,files:list[str],with_messages:bool=False,messages:list=[str],messages_first:bool=False,
        send_delay:float=None,clear:bool=None,is_maximize:bool=None,close_weixin:bool=None)->None:
        '''
        该方法用于给单个好友或群聊发送多个文件
        Args:
            friend:好友或群聊备注。格式:friend="好友或群聊备注"
            files:所有待发送文件所路径列表。
            with_messages:发送文件时是否给好友发消息。True发送消息,默认为False。
            messages:与文件一同发送的消息。格式:message=["消息1","消息2","消息3"]
            clear:是否删除编辑区域已有的内容,默认删除。
            send_delay:发送单条信息或文件的延迟,单位:秒/s,默认0.2s。
            is_maximize:微信界面是否全屏,默认不全屏。
            messages_first:默认先发送文件后发送消息,messages_first设置为True,先发送消息,后发送文件,
            close_weixin:任务结束后是否关闭微信,默认关闭
        '''
        #发送消息逻辑
        def send_messages(messages):
            for message in messages:
                if 0<len(message)<2000:
                    SystemSettings.copy_text_to_clipboard(message)
                    pyautogui.hotkey('ctrl','v',_pause=False)
                    time.sleep(send_delay)
                    pyautogui.hotkey('alt','s',_pause=False)
                if len(message)>2000:
                    SystemSettings.convert_long_text_to_txt(message)
                    pyautogui.hotkey('ctrl','v',_pause=False)
                    time.sleep(send_delay)
                    pyautogui.hotkey('alt','s',_pause=False)
                    warn(message=f"微信消息字数上限为2000,超过2000字部分将被省略,该条长文本消息已为你转换为txt发送",category=LongTextWarning) 
        #发送文件逻辑
        def send_files(files):
            if len(files)<=9:
                SystemSettings.copy_files_to_clipboard(filepaths_list=files)
                pyautogui.hotkey("ctrl","v")
                time.sleep(send_delay)
                pyautogui.hotkey('alt','s',_pause=False)
            else:
                files_num=len(files)
                rem=len(files)%9
                for i in range(0,files_num,9):
                    if i+9<files_num:
                        SystemSettings.copy_files_to_clipboard(filepaths_list=files[i:i+9])
                        pyautogui.hotkey('ctrl','v')
                        time.sleep(send_delay)
                        pyautogui.hotkey('alt','s',_pause=False)
                if rem:
                    SystemSettings.copy_files_to_clipboard(filepaths_list=files[files_num-rem:files_num])
                    pyautogui.hotkey('ctrl','v')
                    time.sleep(send_delay)
                    pyautogui.hotkey('alt','s',_pause=False)
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if send_delay is None:
            send_delay=GlobalConfig.send_delay
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if clear is None:
            clear=GlobalConfig.clear
        #对发送文件校验
        if files:            
            files=[file for file in files if os.path.isfile(file)]
            files=[file for file in files if 0<os.path.getsize(file)<1073741824]#0到1g之间的文件才可以发送
        if not files:
            raise NoFilesToSendError
        main_window=Navigator.open_dialog_window(friend=friend,is_maximize=is_maximize)
        edit_area=main_window.child_window(**Edits.CurrentChatEdit)
        if not edit_area.exists(timeout=0.1):
            raise NotFriendError(f'非正常好友,无法发送文件!')
        if clear:
            edit_area=main_window.child_window(**Edits.CurrentChatEdit)
            edit_area.set_text('')
        if with_messages and messages_first:
            send_messages(messages)
            send_files(files)
        if with_messages and not messages_first:
            send_files(files)
            send_messages(messages)
        if not with_messages:
            send_files(files)       
        if close_weixin:
            main_window.close()

    @staticmethod
    def send_files_to_friends(friends:list[str],files_list:list[list[str]],
        with_messages:bool=False,messages_list:list[list[str]]=[],messages_first:bool=False,
        clear:bool=None,send_delay:float=None,is_maximize:bool=None,close_weixin:bool=None)->None:
        '''
        该方法用于给多个好友或群聊发送文件
        Args:
            friends:好友或群聊备注。格式:friends=["好友1","好友2","好友3"]
            files_list:待发送文件列表,格式[[一些文件],[另一些文件],...[]]
            with_messages:发送文件时是否给好友发消息。True发送消息,默认为False
            messages_list:待发送消息列表,格式:message=[[一些消息],[另一些消息]....]
            messages_first:先发送消息还是先发送文件,默认先发送文件
            clear:是否删除编辑区域已有的内容,默认删除。
            send_delay:发送单条消息延迟,单位:秒/s,默认0.2s。
            is_maximize:微信界面是否全屏,默认不全屏。
            close_weixin:任务结束后是否关闭微信,默认关闭
        注意! messages_list,files_list与friends长度需一致且顺序一致,否则会出现发错的尴尬情况
        '''
        def verify(Files):
            verified_files=dict()
            if len(Files)<len(friends):
                raise ValueError(f'friends与files_lists长度不一致!发送人{len(friends)}个,发送文件列表个数{len(Files)}')
            for friend,files in Files.items():         
                files=[file for file in files if os.path.isfile(file)]
                files=[file for file in files if 0<os.path.getsize(file)<1073741824]#文件大小不能超过1个G!
                if files:
                    verified_files[friend]=files
                if not files:
                    print(f'发给{friend}的文件列表内没有可发送的文件！')
            return verified_files

        
        def open_dialog_window_by_search(friend):
            search=main_window.descendants(**Main_window.Search)[0]
            search.click_input()
            search.set_text(friend)
            time.sleep(0.8)
            search_results=main_window.child_window(**Main_window.SearchResult)
            friend_listitem=Tools.get_search_result(friend=friend,search_result=search_results)
            if friend_listitem is not None:
                friend_listitem.click_input()
                edit_area=main_window.child_window(**Edits.CurrentChatEdit)
                if edit_area.exists(timeout=0.1):
                    edit_area.click_input()
                    return True
            return False
        
        #消息发送逻辑
        def send_messages(messages):
            for message in messages:
                if 0<len(message)<2000:
                    SystemSettings.copy_text_to_clipboard(message)
                    pyautogui.hotkey('ctrl','v',_pause=False)
                    time.sleep(send_delay)
                    pyautogui.hotkey('alt','s',_pause=False)
                if len(message)>2000:
                    SystemSettings.convert_long_text_to_txt(message)
                    pyautogui.hotkey('ctrl','v',_pause=False)
                    time.sleep(send_delay)
                    pyautogui.hotkey('alt','s',_pause=False)
                    warn(message=f"微信消息字数上限为2000,超过2000字部分将被省略,该条长文本消息已为你转换为txt发送",category=LongTextWarning) 
        
        #发送文件逻辑，必须9个9个发！
        def send_files(files):
            if len(files)<=9:
                SystemSettings.copy_files_to_clipboard(filepaths_list=files)
                pyautogui.hotkey("ctrl","v")
                time.sleep(send_delay)
                pyautogui.hotkey('alt','s',_pause=False)
            else:
                files_num=len(files)
                rem=len(files)%9#
                for i in range(0,files_num,9):
                    if i+9<files_num:
                        SystemSettings.copy_files_to_clipboard(filepaths_list=files[i:i+9])
                        pyautogui.hotkey('ctrl','v')
                        time.sleep(send_delay)
                        pyautogui.hotkey('alt','s',_pause=False)
                if rem:#余数
                    SystemSettings.copy_files_to_clipboard(filepaths_list=files[files_num-rem:files_num])
                    pyautogui.hotkey('ctrl','v')
                    time.sleep(send_delay)
                    pyautogui.hotkey('alt','s',_pause=False)

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if send_delay is None:
            send_delay=GlobalConfig.send_delay
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if clear is None:
            clear=GlobalConfig.clear
        Files=dict(zip(friends,files_list))
        Files=verify(Files)
        if not Files:
            raise NoFilesToSendError
        Chats=dict(zip(friends,messages_list))
        main_window=Navigator.open_weixin(is_maximize=is_maximize)
        edit_area=main_window.child_window(**Edits.CurrentChatEdit)
        chat_button=main_window.child_window(**SideBar.Weixin)
        chat_button.click_input()
        if with_messages and messages_list:#文件消息一起发且messages_list不空
            for friend in Files:
                Navigator.open_dialog_window(friend=friend,is_maximize=is_maximize,search_pages=0)
                ret=open_dialog_window_by_search(friend)
                if clear:
                   edit_area.set_text('')
                if messages_first and ret:#打开了好友聊天界面,且先发消息
                    messages_to_send=Chats.get(friend)
                    files_to_send=Files.get(friend)
                    send_messages(messages_to_send)
                    send_files(files_to_send)
                if not messages_first and ret:#打开了好友聊天界面,后发消息
                    messages_to_send=Chats.get(friend)
                    files_to_send=Files.get(friend)
                    send_files(files_to_send)
                    send_messages(messages_to_send)
                if not ret:#没有打开好友聊天界面
                    print(f'未能正确打开好友聊天窗口！')
        else:
            for friend in Files:#只发文件
                ret=open_dialog_window_by_search(friend)
                if clear:
                    edit_area.set_text('')
                if ret:
                    files_to_send=Files.get(friend)
                    send_files(files_to_send)
                if not ret:
                     print(f'未能正确打开好友聊天窗口！')
        if close_weixin:
            main_window.close()

    @staticmethod
    def save_chatfiles(friend:str,number:int,target_folder:str=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来导出与某个好友的聊天文件,过期未下载的无法导出
        Args:
            friend:好友或群聊的名称
            target_folder:导出文件存放的文件夹路径,不传入会自动在本地新建一个
            number:导出的文件数量限制,默认是所有
            is_maximize:微信界面是否全屏,默认不全屏。
            close_weixin:任务结束后是否关闭微信,默认关闭
        Returns:
            filepaths:导出的文件路径列表 
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        
        def find_similar_files(filename, target_dir):
            name_without_ext=os.path.splitext(filename)[0]
            base_name=re.sub(r'\(\d+\)$','',name_without_ext)
            result=[]
            for f in os.listdir(target_dir):
                file_base=os.path.splitext(f)[0]
                if file_base.startswith(base_name):
                    result.append(os.path.join(target_dir, f))
            return result
    
        def extract_info(text:str):
            texts=text.split('|')
            filename=filename_pattern.search(texts[0]).group(0)
            timestamp=timestamp_pattern.search(texts[1]).group(1) 
            year=int(time.strftime('%Y'))
            month=int(time.strftime('%m'))
            if year_sep in timestamp and year_sep=='-':
                year=int(re.search(r'(\d{4})-\d{1,2}-\d{1,2}',timestamp).group(1))
            if year_sep in timestamp and year_sep=='年':
                year=int(re.search(r'(\d+)年',timestamp).group(1))
            if month_sep in timestamp and month_sep=='月':
                month=int(re.search(r'(\d+)月',timestamp).group(1))
            if month_sep in timestamp and month_sep=='-':
                month=int(re.search(r'\d{4}-(\d{1,2})-\d{1,2}',timestamp).group(1))
            dirname=f'{year}-{month}' if month>=10 else f'{year}-0{month}'
            return filename,dirname
        
        if target_folder is not None and not os.path.isdir(target_folder):
            raise NotFolderError(f'所选路径不是文件夹!无法保存聊天记录,请重新选择!')
        if target_folder is None:
            folder_name='save_files聊天文件保存'
            target_folder=os.path.join(os.getcwd(),folder_name,friend)
            os.makedirs(name=target_folder,exist_ok=True)
            print(f'未传入文件夹路径,聊天文件将保存至 {target_folder}')

        filenames=[]
        dirnames=[]
        files=[]
        year_sep=Special_Labels.YearSep
        month_sep=Special_Labels.MonthSep
        not_download=Special_Labels.NotDownloaded
        expired=Special_Labels.Expired
        send_interrupt=Special_Labels.SendInterrupt
        filename_pattern=Regex_Patterns.Filename_pattern
        timestamp_pattern=Regex_Patterns.Chafile_Timestamp_pattern
        filename_pattern=Regex_Patterns.Filename_pattern
        timestamp_pattern=Regex_Patterns.Chafile_Timestamp_pattern
        chatfile_dir=Tools.where_chatfiles_folder()
        chatfile_window=Navigator.open_chatfiles(is_maximize=is_maximize,close_weixin=close_weixin)
        empty_button=chatfile_window.child_window(**Buttons.EmptyButton)
        if empty_button.exists(timeout=0.1):empty_button.click_input()
        sender_item=chatfile_window.child_window(**ListItems.SenderListItem)
        sender_item.click_input()
        search_button=chatfile_window.child_window(title='',control_type='Button',class_name='mmui::XButton')
        search_button.click_input()
        SystemSettings.copy_text_to_clipboard(friend)
        pyautogui.hotkey('ctrl','v')
        fileList=chatfile_window.child_window(**Lists.FileList)
        if fileList.exists(timeout=0.2):
            first_item=fileList.children(control_type='ListItem')[0]
            fileList.type_keys('{END}'*100)
            last_file=fileList.children()[-1].window_text()
            fileList.type_keys('{HOME}')
            recorded_num=1
            label=first_item.window_text()
            if (not_download not in label) and (expired not in label) and (send_interrupt not in label):
                filename,dirname=extract_info(label)
                filenames.append(filename)
                dirnames.append(dirname)
            fileList.type_keys('{DOWN}')
            while recorded_num<number:
                selected=[item for item in fileList.children(control_type='ListItem',class_name='mmui::FileListCell') if item.has_keyboard_focus()]
                if selected:
                    label=selected[0].window_text()
                    print(label)
                    if (not_download not in label) and (expired not in label) and (send_interrupt not in label):
                        filename,dirname=extract_info(label)
                        filenames.append(filename)
                        dirnames.append(dirname)
                    if label==last_file:
                        break
                    fileList.type_keys('{DOWN}')
                    recorded_num+=1
                else:
                    break
        for filename,dirname in zip(filenames,dirnames):
            base_dir=os.path.join(chatfile_dir,dirname)
            filepath=os.path.join(base_dir,filename)#
            #将pyweixin(2).pdf这种带(3)后缀的同名文件也一起导出,只多不少
            similar_files=find_similar_files(filename,base_dir)
            similar_files.append(filepath)
            files.extend(similar_files)
        SystemSettings.copy_files(files,target_folder=target_folder)
        chatfile_window.close()
        return filenames

    @staticmethod
    def export_recent_files(target_folder:str=None,is_maximize:bool=None,close_weixin:bool=None):
        ''' 该方法用来导出最近打开使用的文件,过期未下载的无法导出
        Args:
            target_folder:导出文件存放的文件夹路径,不传入会自动在本地新建一个
            is_maximize:微信界面是否全屏,默认不全屏。
            close_weixin:任务结束后是否关闭微信,默认关闭
        Returns:
            filepaths:导出的文件路径列表 
        '''
        def find_similar_files(filename, target_dir):
            name_without_ext=os.path.splitext(filename)[0]
            base_name=re.sub(r'\(\d+\)$','',name_without_ext)
            result=[]
            for f in os.listdir(target_dir):
                file_base=os.path.splitext(f)[0]
                if file_base.startswith(base_name):
                    result.append(os.path.join(target_dir, f))
            return result
    
        def extract_info(text:str):
            texts=text.split('|')
            filename=filename_pattern.search(texts[0]).group(0)
            timestamp=timestamp_pattern.search(texts[1]).group(1) 
            year=int(time.strftime('%Y'))
            month=int(time.strftime('%m'))
            if year_sep in timestamp and year_sep=='-':
                year=int(re.search(r'(\d{4})-\d{1,2}-\d{1,2}',timestamp).group(1))
            if year_sep in timestamp and year_sep=='年':
                year=int(re.search(r'(\d+)年',timestamp).group(1))
            if month_sep in timestamp and month_sep=='月':
                month=int(re.search(r'(\d+)月',timestamp).group(1))
            if month_sep in timestamp and month_sep=='-':
                month=int(re.search(r'\d{4}-(\d{1,2})-\d{1,2}',timestamp).group(1))
            dirname=f'{year}-{month}' if month>=10 else f'{year}-0{month}'
            return filename,dirname
        
        if target_folder and not os.path.isdir(target_folder):
            raise NotFolderError(f'所选路径不是文件夹!无法保存聊天记录,请重新选择!')
        if not target_folder:
            folder_name='export_recent_files最近聊天文件保存'
            os.makedirs(name=folder_name,exist_ok=True)
            target_folder=os.path.join(os.getcwd(),folder_name)
            print(f'未传入文件夹路径,聊天文件将保存至 {target_folder}')

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
    
        filenames=[]
        dirnames=[]
        files=[]
        year_sep=Special_Labels.YearSep
        month_sep=Special_Labels.MonthSep
        not_download=Special_Labels.NotDownloaded
        expired=Special_Labels.Expired
        send_interrupt=Special_Labels.SendInterrupt
        filename_pattern=Regex_Patterns.Filename_pattern
        timestamp_pattern=Regex_Patterns.Chafile_Timestamp_pattern
        chatfile_dir=Tools.where_chatfiles_folder()
        chatfile_window=Navigator.open_chatfiles(is_maximize=is_maximize,close_weixin=close_weixin)
        recent_used=chatfile_window.child_window(**ListItems.RecentUsedListItem)
        recent_used.click_input()
        fileList=chatfile_window.child_window(**Lists.FileList)
        if fileList.exists(timeout=0.2):
            first_item=fileList.children(control_type='ListItem')[0]
            fileList.type_keys('{END}'*100)
            last_file=fileList.children()[-1].window_text()
            fileList.type_keys('{HOME}')
            label=first_item.window_text()
            if (not_download not in label) and (expired not in label) and (send_interrupt not in label):
                filename,dirname=extract_info(label)
                filenames.append(filename)
                dirnames.append(dirname)
            fileList.type_keys('{DOWN}')
            while True:
                selected=[item for item in fileList.children(control_type='ListItem',class_name='mmui::FileListCell') if item.has_keyboard_focus()]
                if selected:
                    label=selected[0].window_text()
                    if (not_download not in label) and (expired not in label) and (send_interrupt not in label):
                        filename,dirname=extract_info(label)
                        filenames.append(filename)
                        dirnames.append(dirname)
                    if label==last_file:
                        break
                fileList.type_keys('{DOWN}')
            for filename,dirname in zip(filenames,dirnames):
                base_dir=os.path.join(chatfile_dir,dirname)
                filepath=os.path.join(base_dir,filename)#
                #将pyweixin(2).pdf这种带(3)后缀的同名文件也一起导出,只多不少
                similar_files=find_similar_files(filename,base_dir)
                similar_files.append(filepath)
                files.extend(similar_files)
            SystemSettings.copy_files(files,target_folder=target_folder)
        chatfile_window.close()
        return filenames
    
    @staticmethod
    def export_videos(year:str=time.strftime('%Y'),month:str=time.strftime('%m'),target_folder:str=None)->list[str]:
        '''
        该方法用来导出微信保存到本地的聊天视频,只有点击下载过的视频才可以被导出
        Args:
            year:年份,除非手动删除聊天视频否则一直保存,格式:YYYY:2025,2024
            month:月份,微信聊天视屏是按照YYYY年-XX月分批存储的格式:2025-12,2025-06
            target_folder:导出的聊天视频保存的位置,需要是文件夹
        Returns:
            exported_videos:导出的mp4视频路径列表
        '''
        folder_name=f'{year}-{month}微信聊天视频导出' if month else f'{year}微信聊天视频导出' 
        if target_folder is None:
            os.makedirs(name=folder_name,exist_ok=True)
            target_folder=os.path.join(os.getcwd(),folder_name)
            print(f'未传入文件夹路径,所有导出的微信聊天视频将保存至 {target_folder}')
        if target_folder is not None and not os.path.isdir(target_folder):
            raise NotFolderError(f'给定路径不是文件夹,无法导入保存聊天文件')

        exported_videos=[]
        chatfile_dir=Tools.where_video_folder()
        folders=os.listdir(chatfile_dir)#微信聊天文件所在文件顶部文件夹
        #先找到所有以年份开头的文件夹,并将得到的文件夹名字与其根目录chatfile_folder这个路径join
        filtered_folders=[os.path.join(chatfile_dir,folder) for folder in folders if folder.startswith(year)]
        if month:
            #如果有月份传入，那么在上一步基础上根据月份筛选
            filtered_folders=[folder for folder in filtered_folders if folder.endswith(month)]
        for folder_path in filtered_folders:#遍历筛选后的每个文件夹
            #获取该文件夹下以.mp4结尾的所有文件路径列表，然后使用copy_files方法复制过去，
            videos_in_folder=[os.path.join(folder_path,filename) for filename in  os.listdir(folder_path) if filename.endswith('.mp4')]
            SystemSettings.copy_files(videos_in_folder,target_folder)
        exported_videos=[os.path.join(chatfile_dir,filename) for filename in os.listdir(target_folder) if filename.endswith('.mp4')]
        return exported_videos

    @staticmethod
    def export_wxfiles(year:str=time.strftime('%Y'),month:str=time.strftime('%m'),target_folder:str=None)->list[str]:
        '''
        该方法用来快速导出微信聊天文件
        Args:
            year:年份,除非手动删除否则聊天文件持续保存,格式:YYYY:2025,2024
            month:月份,微信聊天文件是按照xxxx年-xx月分批存储的格式:XX:06
            target_folder:导出的聊天文件保存的位置,需要是文件夹
        Returns:
            exported_files:所有导出的文件路径列表
        '''
        folder_name=f'{year}年-{month}月微信聊天文件导出' if month else f'{year}年微信聊天文件导出' 
        if not target_folder:
            os.makedirs(name=folder_name,exist_ok=True)
            target_folder=os.path.join(os.getcwd(),folder_name)
            print(f'未传入文件夹路径,所有导出的微信聊天文件将保存至 {target_folder}')
        if not os.path.isdir(target_folder):
            raise NotFolderError(f'给定路径不是文件夹,无法导入保存聊天文件')
        chatfiles_folder=Tools.where_chatfiles_folder()
        folders=os.listdir(chatfiles_folder)
        #先找到所有以年份开头的文件夹,并将得到的文件夹名字与其根目录chatfile_folder这个路径join
        filtered_folders=[os.path.join(chatfiles_folder,folder) for folder in folders if folder.startswith(year)]
        if month:
            #如果有月份传入，那么在上一步基础上根据月份筛选
            filtered_folders=[folder for folder in filtered_folders if folder.endswith(month)]
        for folder_path in filtered_folders:#遍历筛选后的每个文件夹
            #获取该文件夹下的所有文件路径列表，然后使用copy_files方法复制过去，
            files_in_folder=[os.path.join(folder_path,filename) for filename in  os.listdir(folder_path)] 
            SystemSettings.copy_files(files_in_folder,target_folder)
        exported_files=os.listdir(target_folder)#尽管路径全部存在但不一定就可以导出(文件被打开或占用时导出会失败),导出的文件一定是最终opy_files的
        return exported_files


class Moments():

    @staticmethod
    def post_moments(text:str='',medias:list[str]=[],is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来发布朋友圈
        Args:
            text:朋友圈文本内容
            medias:mp4,jpg,png等多个图像或视频的路径列表
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        '''
        def build_path(medias):
            '''用来构造windows文件选择界面内选择多个文件时底部输入的路径'''
            path=''
            for media in medias:
                if os.path.exists(media):
                    path+=f'"{media}" '
            return path
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if not text and not medias:
            raise ValueError(f'文本与图片视频至少要有一个!')
        if medias:
            paths=build_path(medias)
            if not paths:raise ValueError(f'medias列表内无可用图片或视频路径!')
        moments=Navigator.open_moments(is_maximize=is_maximize,close_weixin=close_weixin)
        moments.child_window(**Buttons.PostButton).right_click_input(),
        pyautogui.press('up',presses=2)
        if medias:
            pyautogui.press('enter')
            native_window=desktop.window(**Windows.NativeChooseFileWindow)
            edit=native_window.child_window(**Edits.NativeFileSaveEdit)
            edit.set_text(paths)
            pyautogui.hotkey('alt','o')
        if text and not medias:
            pyautogui.press('down',presses=1)
            pyautogui.press('enter')
        publish_panel=moments.child_window(**Groups.SnsPublishGroup)
        if text:
            text_input=publish_panel.child_window(**Edits.SnsEdit)
            text_input.click_input()
            text_input.set_text(text)
        post_button=publish_panel.child_window(**Buttons.PostButton)
        post_button.click_input()
    
    @staticmethod
    def post_notes(content:str=None,files:list[str]=[],text:str=None,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来新建笔记然后将笔记发布到朋友圈
        Args:
            content:笔记内容文本内容
            files:任何类型文件的路径列表,注意单个文件大小不要超过100MB,否则无法粘贴到笔记中
            text:发布到朋友圈时的文本
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if files:            
            files=[file for file in files if os.path.isfile(file)]
            files=[file for file in files if 0<os.path.getsize(file)<104857600]#0到100mb之间的文件才可以粘贴到笔记中
        if content is None and not files:
            raise ValueError(f'笔记中文本或文件至少要有一个!')
        note_window=Navigator.open_note(is_maximize=is_maximize,close_weixin=close_weixin)
        edit_area=note_window.child_window(control_type='Edit')
        edit_area.set_text(content)
        if files:
            SystemSettings.copy_files_to_clipboard(files)
            pyautogui.hotkey('ctrl','v')
        edit_area.click_input()
        pyautogui.hotkey('ctrl','s')
        time.sleep(5)#等待保存
        Tools.cancel_pin(note_window)
        container=note_window.child_window(auto_id='mainContainer')
        MoreButtonPos=MousePos(container).MoreButtonPos
        mouse.click(coords=MoreButtonPos)
        pyautogui.press('up',presses=2)
        pyautogui.press('enter')
        publish_panel=note_window.child_window(**Windows.SnsPublishWindow)
        publish_panel.wait(wait_for='ready',timeout=3)
        publish_panel.restore()
        if text:
            text_input=publish_panel.child_window(**Edits.SnsEdit)
            text_input.click_input()
            text_input.set_text(text)
        note_window.close()
        post_button=publish_panel.child_window(**Buttons.PostButton)
        post_button.click_input()
       

    @staticmethod
    def dump_recent_posts(recent:Literal['Today','Yesterday','Week','Month']='Today',number:int=None,with_name:bool=False,save_detail:bool=False,target_folder:str=None,is_maximize:bool=None,close_weixin:bool=None)->list[dict]:
        '''
        该方法用来获取最近一月内微信朋友圈内好友发布过的具体内容
        Args:
            recent:最近的时间,取值为['Today','Yesterday','Week','Month']
            number:指定的数量(如果传入了该参数那么按照recent和数量返回内容,如果不传入那么只按照recent的时间节点返回内容)
            with_name:是否连好友的名字一并获取,需要点击左侧好友头像获取(比较耗时),默认为False
            save_detail:是否保存每条朋友圈的具体内容到本地(注意,该操作比较耗时!)
            target_folder:save_detail为True时保存朋友圈内容的具体文件夹
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            posts:朋友圈具体内容,list[dict]的格式,具体为[{'好友'xx,'内容':xx,'图片数量':xx,'视频数量':xx,'发布时间':xx}]
        '''
        def save_media(content_listitem:ListItemWrapper,friend:str,content:str,photo_num:int,video_num:int):
            post_history=[dic for dic in posts if dic.get('好友')==friend]
            post_count=len(post_history)#用来保存同一个好友的多条朋友圈时,内部文件夹按照1,2,3...
            friend=re.sub(illegal_chars, '', friend)#windows路径不能有非法字符！
            detail_folder=os.path.join(target_folder,friend,str(post_count))
            os.makedirs(detail_folder,exist_ok=True)
            content_path=os.path.join(detail_folder,'内容.txt')
            capture_path=os.path.join(detail_folder,'内容截图.png')
            video_path=os.path.join(detail_folder,'朋友圈视频.mp4')
            #保存截图
            image_obj=content_listitem.capture_as_image()
            if image_obj is not None:image_obj.save(capture_path)
            with open(content_path,'w',encoding='utf-8') as f:f.write(content) if content else f.write(f'无文本内容')
            PostImagePos=MousePos(content_listitem).PostImagePos
            #保存视频
            if video_num: 
                mouse.click(coords=PostImagePos)
                image_preview_window.right_click_input()
                is_download=moments_window.child_window(**MenuItems.CopyMenuItem).exists(timeout=0.1)
                while not is_download:
                    image_preview_window.right_click_input()
                    copy_item=image_preview_window.child_window(**MenuItems.CopyMenuItem)
                    if copy_item.exists(timeout=0.2):
                        is_download=True 
                    time.sleep(0.5)    
                image_preview_window.child_window(**MenuItems.CopyMenuItem).click_input()
                time.sleep(2)#缓存到剪贴板
                SystemSettings.save_pasted_video(video_path)
                pyautogui.press('esc')
            #保存图片
            if photo_num:
                mouse.click(coords=PostImagePos)
                pyautogui.press('left',presses=photo_num,interval=0.15)
                rect=moments_window.rectangle()
                right_click_pos=rect.mid_point().x+120,rect.mid_point().y-20
                for i in range(photo_num):
                    mouse.right_click(coords=right_click_pos)
                    moments_window.child_window(**MenuItems.CopyMenuItem).click_input()
                    path=os.path.join(detail_folder,f'{i}.png')
                    time.sleep(0.5)#0.5s缓存到剪贴板时间
                    SystemSettings.save_pasted_image(path)
                    pyautogui.press('right',interval=0.05)
                pyautogui.press('esc')

        def parse_post(content_listitem:ListItemWrapper):
            '''获取朋友圈文本中的时间戳,图片数量,以及剩余内容'''
            video_num=0
            photo_num=0
            friend=''
            text=content_listitem.window_text()
            if with_name:
                PostNamePos=MousePos(content_listitem).PostNamePos
                mouse.double_click(coords=PostNamePos)
                friend=profile_window.child_window(control_type='Button',found_index=0).window_text()
                friend=friend.strip()
                mouse.click(coords=PostNamePos)
            text=text.replace(friend,'')
            post_time=sns_timestamp_pattern.findall(text)[-1]
            if GlobalConfig.language=='简体中文':
                contain_video_pattern=re.compile(rf'\s视频\s{re.escape(post_time)}')
                content_pattern=re.compile(rf'((\s包含\d+张图片\s)|(\s视频\s)){re.escape(post_time)}')
            if GlobalConfig.language=='English':
                contain_video_pattern=re.compile(rf'\sVideo\s{re.escape(post_time)}')
                content_pattern=re.compile(rf'((\sContain\s(\d+)\simage\(s\)\s)|(\sVideo\s)){re.escape(post_time)}')
            if GlobalConfig.language=='繁體中文':
                contain_video_pattern=re.compile(rf'\s影片\s{re.escape(post_time)}')
                content_pattern=re.compile(rf'((\s包含\s\d+\s張圖片\s)|(\s影片\s)){re.escape(post_time)}')
            if contain_image_pattern.search(text):
                photo_num=int(contain_image_pattern.search(text).group(1))
            if contain_video_pattern.search(text):
                video_num=1
            content=content_pattern.sub('',text)
            content=re.sub(r'^\s+','',content)
            return friend,content,photo_num,video_num,post_time
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if save_detail  and target_folder is None:
            target_folder=os.path.join(os.getcwd(),'dump_recents_posts朋友圈内容保存')
            print(f'未传入文件夹图片和内容将保存到{target_folder}内')
            os.makedirs(target_folder,exist_ok=True)
        posts=[]
        recorded_num=0
        month_days=Special_Labels.MonthDays
        week_days=Special_Labels.WeekDays
        yesterday=Special_Labels.Yesterday
        days_ago=Special_Labels.DaysAgo
        if save_detail:with_name=True
        illegal_chars=r'[\\/*?:"<>|]'#windows文件系统中的非法字符,好友名字中如果有需要替换
        sns_timestamp_pattern=Regex_Patterns.Sns_Timestamp_pattern#朋友圈好友发布内容左下角的时间戳
        contain_image_pattern=Regex_Patterns.Contain_Images_pattern#朋友圈包含1~9张图片
        not_contents=['mmui::TimelineCommentCell','mmui::TimelineCell','mmui::TimelineAdGridImageCell',
        'mmui::TimelineAdBaseCardImageCell','mmui::TimelineAdVideoCell','mmui::TimelineAdNormalCell']#评论区，余下x条,广告,这三种不需要
        moments_window=Navigator.open_moments(is_maximize=is_maximize,close_weixin=close_weixin)
        Tools.cancel_pin(moments_window)
        image_preview_window=desktop.window(**Windows.ImagePreviewWindow)
        profile_window=desktop.window(**Windows.PopUpProfileWindow)
        moments_list=moments_window.child_window(**Lists.MomentsList)
        #微信朋友圈当天发布时间是xx分钟前,xx小时前,一周内的时间在7天内,且包含当天时间,同理一月内的时间在30天内,包含本周的时间
        moments_window.child_window(**Buttons.RefreshButton).click_input()
        time.sleep(1.5)#等待一下朋友圈自动刷新,不然获取的可能是过去的内容
        moments_list.type_keys('{HOME}')
        if moments_list.children(control_type='ListItem'):
            while True:
                listitems=[listitem for listitem in moments_list.children(control_type='ListItem') if listitem.class_name() not in not_contents]
                selected=[listitem for listitem in listitems if listitem.has_keyboard_focus()]
                if selected:
                    friend,content,photo_num,video_num,post_time=parse_post(selected[0])
                    post_detail={'好友':friend,'内容':content,'图片数量':photo_num,'视频数量':video_num,'发布时间':post_time}
                    posts.append(post_detail)
                    if save_detail:save_media(selected[0],friend,content,photo_num,video_num)
                    recorded_num+=1
                    if isinstance(number,int) and recorded_num>=number:
                        break
                    if recent=='Today' and ((yesterday in post_time ) or (days_ago in post_time)):#昨天或者x天前在时间戳里不属于今天了
                        break
                    if recent=='Yesterday' and days_ago in post_time:#当前的朋友圈内容发布时间没有天前,说明是当天和昨天
                        break
                    if recent=='Week' and post_time not in week_days:#当前的朋友圈内容发布时间不在一周的时间内
                        break
                    if recent=='Month' and post_time not in month_days:#当前的朋友圈内容发布时间不在一个月的时间内
                        break
                moments_list.type_keys('{DOWN}',pause=0.2)
            if recent=='Today':
                posts=[post for post in posts if  yesterday not in post.get('发布时间')]
            if recent=='Yesterday':
                posts=[post for post in posts if post.get('发布时间')==yesterday]
            if recent=='Week':
                posts=[post for post in posts if post.get('发布时间') in week_days]
            if recent=='Month':
                posts=[post for post in posts if post.get('发布时间') in month_days]
        moments_window.close()
        return posts
    
    @staticmethod
    def like_posts(recent:Literal['Today','Yesterday','Week','Month']='Today',with_name:bool=False,number:int=None,callback:Callable[[str],str]=None,is_maximize:bool=None,close_weixin:bool=None)->list[dict]:
        '''
        该方法用来给朋友圈内最近发布的内容点赞和评论
        Args:
            recent:最近的时间,取值为['Today','Yesterday','Week','Month']
            number:数量,如果指定了一定的数量,那么点赞数量超过number时结束,如果没有则在recent指定的范围内全部点赞
            with_name:是否连好友的名字一并获取,需要点击左侧好友头像获取(比较耗时),默认为False
            callback:评论回复函数,入参为字符串是好友朋友圈的内容,返回值为要评论的内容
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
           posts:朋友圈内容,list[dict]的格式,具体为[{'好友','内容':xx,'图片数量':xx,'视频数量':xx,'发布时间':xx}]
        '''
        def parse_post(content_listitem:ListItemWrapper):
            '''获取朋友圈文本中的时间戳,图片数量,以及剩余内容'''
            video_num=0
            photo_num=0
            text=content_listitem.window_text()
            friend=''
            if with_name:
                PostNamePos=MousePos(content_listitem).PostNamePos
                mouse.double_click(coords=PostNamePos)
                friend=profile_window.child_window(control_type='Button',found_index=0).window_text()
                friend=friend.strip()
                mouse.click(coords=PostNamePos)
            post_time=sns_timestamp_pattern.findall(text)[-1]
            if GlobalConfig.language=='简体中文':
                contain_video_pattern=re.compile(rf'\s视频\s{post_time}')
                content_pattern=re.compile(rf'((\s包含\d+张图片\s)|(\s视频\s)).*{post_time}')
            if GlobalConfig.language=='English':
                contain_video_pattern=re.compile(rf'\sVideo\s{post_time}')
                content_pattern=re.compile(rf'((\sContain\s(\d+)\simage\(s\)\s)|(\sVideo\s)).*{post_time}')
            if GlobalConfig.language=='繁體中文':
                contain_video_pattern=re.compile(rf'\s影片\s{post_time}')
                content_pattern=re.compile(rf'((\s包含\s\d+\s張圖片\s)|(\s影片\s)).*{post_time}')
            if contain_image_pattern.search(text):
                photo_num=int(contain_image_pattern.search(text).group(1))
            if contain_video_pattern.search(text):
                video_num=1
            content=content_pattern.sub('',text)
            content=re.sub(r'^\s+','',content)
            return friend,content,photo_num,video_num,post_time
        
        def click_like_button(content_listitem:ListItemWrapper):
            #点赞操作
            # mouse.move(coords=center_point)
            rectangle=content_listitem.rectangle()
            ColorMatch.click_gray_ellipsis_button(rectangle)
            if like_button.exists(timeout=0.1):
                like_button.click_input()

        def comment(content_listitem:ListItemWrapper,comment_listitem:ListItemWrapper,content:str):
            #评论操作
            EllipsisPos=MousePos(content_listitem).EllipsisPos
            mouse.click(coords=EllipsisPos)
            reply=callback(content) 
            if comment_button.exists(timeout=0.1) and reply is not None:
                comment_button.click_input()
                pyautogui.hotkey('ctrl','a')
                pyautogui.press('backspace')
                SystemSettings.copy_text_to_clipboard(text=reply)
                pyautogui.hotkey('ctrl','v')
                rectangle=comment_listitem.rectangle()
                ColorMatch.click_green_send_button(rectangle,x_offset=80,y_offset=32)

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        
        posts=[]
        liked_num=0
        month_days=Special_Labels.MonthDays
        week_days=Special_Labels.WeekDays
        yesterday=Special_Labels.Yesterday
        days_ago=Special_Labels.DaysAgo
        sns_timestamp_pattern=Regex_Patterns.Sns_Timestamp_pattern#朋友圈好友发布内容左下角的时间戳
        contain_image_pattern=Regex_Patterns.Contain_Images_pattern#朋友圈包含1~9张图片
        not_contents=['mmui::TimelineCommentCell','mmui::TimelineCell','mmui::TimelineAdGridImageCell',
        'mmui::TimelineAdBaseCardImageCell','mmui::TimelineAdVideoCell','mmui::TimelineAdNormalCell']#评论区，余下x条,广告,这三种不需要
        moments_window=Navigator.open_moments(is_maximize=is_maximize,close_weixin=close_weixin)
        Tools.cancel_pin(moments_window)
        moments_window.child_window(**Buttons.RefreshButton).click_input()
        time.sleep(1.5)#等待刷新
        like_button=moments_window.child_window(**Buttons.LikeButton)
        comment_button=moments_window.child_window(**Buttons.CommentButton)
        moments_list=moments_window.child_window(**Lists.MomentsList)
        profile_window=desktop.window(**Windows.PopUpProfileWindow)
        moments_list.type_keys('{HOME}')
        if moments_list.children(control_type='ListItem'):
            while True:
                moments_list.type_keys('{DOWN}',pause=0.2)
                selected=[listitem for listitem in moments_list.children(control_type='ListItem') if listitem.has_keyboard_focus()]
                if selected and selected[0].class_name() not in not_contents:
                    friend,content,photo_num,video_num,post_time=parse_post(selected[0])
                    posts.append({'好友':friend,'内容':content,'图片数量':photo_num,'视频数量':video_num,'发布时间':post_time})
                    click_like_button(selected[0])
                    liked_num+=1
                    if callback is not None:
                        comment_listitem=Tools.get_next_item(moments_list,selected[0])
                        comment(selected[0],comment_listitem,content)
                    if isinstance(number,int) and liked_num>=number:
                        break
                    if recent=='Today' and (yesterday in post_time or days_ago in post_time):
                        break
                    if recent=='Yesterday' and days_ago in post_time:#当前的朋友圈内容发布时间没有天前,说明是当天和昨天
                        break
                    if recent=='Week' and post_time not in week_days:#当前的朋友圈内容发布时间不在一周的时间内
                        break
                    if recent=='Month' and post_time not in month_days:#当前的朋友圈内容发布时间不在一个月的时间内
                        break
        if recent=='Today':
            posts=[post for post in posts if  yesterday not in post.get('发布时间')]
        if recent=='Yesterday':
            posts=[post for post in posts if post.get('发布时间')==yesterday]
        if recent=='Week':
            posts=[post for post in posts if post.get('发布时间') in week_days]
        if recent=='Month':
            posts=[post for post in posts if post.get('发布时间') in month_days]
        moments_window.close()
        return posts

    @staticmethod
    def dump_friend_posts(friend:str,number:int,save_detail:bool=False,target_folder:str=None,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None)->list[dict]:
        '''
        该方法用来获取某个好友的微信朋友圈的内一定数量的内容
        Args:
            friend:好友备注
            number:具体数量
            save_detail:是否保存好友单条朋友圈的具体内容到本地(图片,文本,内容截图)
            target_folder:save_detail所需的文件夹路径
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            posts:朋友圈具体内容,list[dict]的格式,具体为[{'内容':xx,'图片数量':xx,'视频数量':xx,'发布时间':xx}]
        '''
        def save_media(sns_detail_list:ListViewWrapper,photo_num:int,video_num:int,detail_folder:str,content:str):
            content_path=os.path.join(detail_folder,'内容.txt')
            capture_path=os.path.join(detail_folder,'内容截图.png')
            video_path=os.path.join(detail_folder,'朋友圈视频.mp4')
            #保存截图
            sns_detail_list.children(control_type='ListItem')[0].capture_as_image().save(capture_path)
            #保存内容
            with open(content_path,'w',encoding='utf-8') as f:f.write(content) if content else f.write(f'无文本内容')
            #保存视频
            if video_num: 
                content_listitem=sns_detail_list.children(control_type='ListItem',title='')[0]
                PostDetailVideoPos=MousePos(content_listitem).PostDetailVideoPos
                PostDetailVideoClickPos=MousePos(content_listitem).PostDetailVideoClickPos
                mouse.right_click(coords=PostDetailVideoPos)
                xmenu=desktop.window(**Windows.XMenu)
                if not xmenu.exists(timeout=1,retry_interval=0.1):xmenu=moments_window.child_window(*Windows.XMenu)
                is_download=xmenu.child_window(**MenuItems.AddToFavoritesMenuItem).exists(timeout=0.1)
                mouse.click(coords=PostDetailVideoClickPos)
                mouse.double_click(coords=PostDetailVideoClickPos)
                image_preview_window.right_click_input()
                copy_item=image_preview_window.child_window(**MenuItems.CopyMenuItem)
                while not is_download:
                    image_preview_window.right_click_input()
                    copy_item=image_preview_window.child_window(**MenuItems.CopyMenuItem)
                    if copy_item.exists(timeout=0.2):
                        is_download=True 
                    time.sleep(0.5)       
                copy_item.click_input()
                time.sleep(2)#缓存到剪贴板
                SystemSettings.save_pasted_video(video_path)
                pyautogui.press('esc')
            #保存图片
            if photo_num:
                comment_detail=sns_detail_list.children(control_type='ListItem',title='')[1]
                PostDetailImagePos=MousePos(comment_detail).PostDetailImagePos
                PostDetailImageClickPos=MousePos(sns_detail_list).PostDetailImageClickPos
                mouse.click(coords=PostDetailImagePos)
                pyautogui.press('left',presses=photo_num,interval=0.15)
                for i in range(photo_num):
                    mouse.right_click(coords=PostDetailImageClickPos)
                    pyautogui.press('down')
                    pyautogui.press('enter')
                    path=os.path.join(detail_folder,f'{i}.png')
                    time.sleep(0.5)#0.5s缓存到剪贴板时间
                    SystemSettings.save_pasted_image(path)
                    pyautogui.press('right',interval=0.05)
                pyautogui.press('esc')

        def parse_friend_post(listitem:ListItemWrapper):
            '''获取朋友圈文本中的时间戳,图片数量,以及剩余内容'''
            video_num=0
            photo_num=0
            text=listitem.window_text()
            text=text.replace(friend,'')#好友
            post_time=sns_detail_pattern.findall(text)[-1].strip()
            if GlobalConfig.language=='简体中文':
                contain_video_pattern=re.compile(rf'\s视频\s{post_time}\s')
            if GlobalConfig.language=='English':
                contain_video_pattern=re.compile(rf'\sVideo\s')
            if GlobalConfig.language=='繁體中文':
                contain_video_pattern=re.compile(rf'\s影片\s{post_time}\s')
            if contain_image_pattern.search(text):
                photo_num=int(contain_image_pattern.search(text).group(1))
            if contain_video_pattern.search(text):
                video_num=1
            content=contain_video_pattern.sub('',text)
            content=contain_image_pattern.sub('',content.replace(post_time,'')).strip()
            return content,photo_num,video_num,post_time

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if save_detail  and target_folder is None:
            target_folder=os.path.join(os.getcwd(),'dump_friend_posts朋友圈内容保存')
            print(f'未传入文件夹图片和内容将保存到{target_folder}内的 {friend} 文件夹下')
            os.makedirs(target_folder,exist_ok=True)
        if save_detail and (not os.path.exists(target_folder) or not os.path.isdir(target_folder)):
            raise NotFolderError
        if save_detail and target_folder is not None:
            friend_folder=os.path.join(target_folder,f'{friend}')
            os.makedirs(friend_folder,exist_ok=True)
        posts=[]
        recorded_num=0
        sns_detail_pattern=Regex_Patterns.Snsdetail_Timestamp_pattern#朋友圈好友发布内容左下角的时间戳pattern
        contain_image_pattern=Regex_Patterns.Contain_Images_pattern#朋友圈包含1~9张图片
        not_contents=['mmui::AlbumBaseCell','mmui::AlbumTopCell']#置顶内容不需要
        image_preview_window=desktop.window(**Windows.ImagePreviewWindow)
        moments_window,main_window=Navigator.open_friend_moments(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        Tools.cancel_pin(main_window)
        Tools.cancel_pin(moments_window)
        backbutton=moments_window.child_window(**Buttons.BackButton)
        moments_list=moments_window.child_window(**Lists.MomentsList)
        sns_detail_list=moments_window.child_window(**Lists.SnsDetailList)
        Tools.activate_momentsList(moments_list)
        contents=[listitem for listitem in moments_list.children(control_type='ListItem') if listitem.class_name() not in not_contents]
        if contents:
            while recorded_num<number:
                moments_list.type_keys('{DOWN}',pause=0.2)
                selected=[listitem for listitem in moments_list.children(control_type='ListItem') if listitem.has_keyboard_focus()]
                if selected and selected[0].class_name() not in not_contents:
                    selected[0].click_input()
                    if sns_detail_list.exists(timeout=0.3):
                        listitem=sns_detail_list.children(control_type='ListItem')[0]
                        content,photo_num,video_num,post_time=parse_friend_post(listitem)
                        posts.append({'内容':content,'图片数量':photo_num,'视频数量':video_num,'发布时间':post_time})
                        if save_detail:
                            detail_folder=os.path.join(friend_folder,f'{recorded_num}')
                            os.makedirs(detail_folder,exist_ok=True)
                            save_media(sns_detail_list,photo_num,video_num,detail_folder,content)
                        recorded_num+=1
                        if sns_detail_list.exists(timeout=0.1):
                            backbutton.click_input()
                        moments_list.wait(wait_for='ready',timeout=1)
                        if Tools.is_sns_at_bottom(moments_list,selected[0]):
                            break  
        if version.Version(GlobalConfig.Version)<=version.parse('4.1.8'):
            moments_window.close()
        else:
            close_button=main_window.child_window(**Buttons.CloseButton)
            close_button.click()
        if close_weixin:
            main_window.close()
        return posts

    @staticmethod
    def like_friend_posts(friend:str,number:int,callback:Callable[[str],str]=None,is_maximize:bool=None,search_pages:int=None,close_weixin:bool=None)->list[dict]:
        '''
        该方法用来给某个好友朋友圈内发布的内容点赞和评论
        Args:
            friend:好友备注
            number:点赞或评论的数量
            callback:评论回复函数,入参为字符串是好友朋友圈的内容,返回值为要评论的内容
            is_maximize:微信界面是否全屏，默认不全屏
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
           posts:朋友圈内容,list[dict]的格式,具体为[{'内容':xx,'图片数量':xx,'视频数量':xx,'发布时间':xx}]
        '''
        def parse_friend_post(listitem:ListItemWrapper):
            '''获取朋友圈文本中的时间戳,图片数量,以及剩余内容'''
            video_num=0
            photo_num=0
            text=listitem.window_text()
            text=text.replace(friend,'')#好友
            post_time=sns_detail_pattern.findall(text)[-1].strip()
            if GlobalConfig.language=='简体中文':
                contain_video_pattern=re.compile(rf'\s视频\s{post_time}\s')
            if GlobalConfig.language=='English':
                contain_video_pattern=re.compile(rf'\sVideo\s')
            if GlobalConfig.language=='繁體中文':
                contain_video_pattern=re.compile(rf'\s影片\s{post_time}\s')
            if contain_image_pattern.search(text):
                photo_num=int(contain_image_pattern.search(text).group(1))
            if contain_video_pattern.search(text):
                video_num=1
            content=contain_video_pattern.sub('',text)
            content=contain_image_pattern.sub('',content.replace(post_time,'')).strip()
            return content,photo_num,video_num,post_time

        def click_like_button(listview:ListViewWrapper,content_listitem:ListItemWrapper):
            #点赞操作
            center_point=(listview.rectangle().mid_point().x,listview.rectangle().mid_point().y)
            mouse.move(coords=center_point)
            rectangle=content_listitem.rectangle()
            ColorMatch.click_gray_ellipsis_button(rectangle)
            timeline_menu=desktop.window(**Windows.TimeLineFloatMenu)
            if not timeline_menu.exists(timeout=0.3):
                timeline_menu=moments_window.window(**Windows.TimeLineFloatMenu)
            like_button=timeline_menu.child_window(**Buttons.LikeButton)
            if like_button.exists(timeout=0.1):
                like_button.click_input()

        def comment(listview:ListViewWrapper,content_listitem:ListItemWrapper,content:str):
            #评论操作
            comment_listitem=Tools.get_next_item(listview,content_listitem)
            center_point=(listview.rectangle().mid_point().x,listview.rectangle().mid_point().y)
            mouse.move(coords=center_point)
            ColorMatch.click_gray_ellipsis_button(content_listitem.rectangle())
            timeline_menu=desktop.window(**Windows.TimeLineFloatMenu)
            if not timeline_menu.exists(timeout=0.3):
                timeline_menu=moments_window.window(**Windows.TimeLineFloatMenu)
            reply=callback(content) 
            comment_button=timeline_menu.child_window(**Buttons.CommentButton)
            if comment_button.exists(timeout=0.1) and reply is not None:
                comment_button.click_input()
                pyautogui.hotkey('ctrl','a')
                pyautogui.press('backspace')
                SystemSettings.copy_text_to_clipboard(text=reply)
                pyautogui.hotkey('ctrl','v')
                ColorMatch.click_green_send_button(comment_listitem.rectangle(),x_offset=70,y_offset=42)
              
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        posts=[]
        liked_num=0
        sns_detail_pattern=Regex_Patterns.Snsdetail_Timestamp_pattern#朋友圈好友发布内容左下角的时间戳pattern
        contain_image_pattern=Regex_Patterns.Contain_Images_pattern#朋友圈包含1~9张图片
        not_contents=['mmui::AlbumBaseCell','mmui::AlbumTopCell']#置顶内容不需要
        moments_window,main_window=Navigator.open_friend_moments(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        backbutton=moments_window.child_window(**Buttons.BackButton)
        moments_list=moments_window.child_window(**Lists.MomentsList)
        sns_detail_list=moments_window.child_window(**Lists.SnsDetailList)
        Tools.activate_momentsList(moments_list)
        contents=[listitem for listitem in moments_list.children(control_type='ListItem') if listitem.class_name() not in not_contents]
        if contents:
            while liked_num<number:
                moments_list.type_keys('{DOWN}',pause=0.2)
                selected=[listitem for listitem in moments_list.children(control_type='ListItem') if listitem.has_keyboard_focus()]
                if selected and selected[0].class_name() not in not_contents:
                    selected[0].click_input()
                    if sns_detail_list.exists(timeout=0.3):
                        content_listitem=sns_detail_list.children(control_type='ListItem')[0]
                        content,photo_num,video_num,post_time=parse_friend_post(content_listitem)
                        posts.append({'内容':content,'图片数量':photo_num,'视频数量':video_num,'发布时间':post_time})
                        click_like_button(sns_detail_list,content_listitem)
                        if callback is not None:
                            comment(sns_detail_list,content_listitem,content)
                        liked_num+=1
                        backbutton.click_input()
                        moments_list.wait(wait_for='ready',timeout=1)
                        if Tools.is_sns_at_bottom(moments_list,selected[0]):
                            break
        if version.Version(GlobalConfig.Version)<=version.parse('4.1.8'):
            moments_window.close()
        else:
            close_button=main_window.child_window(**Buttons.CloseButton)
            close_button.click()
        if close_weixin:main_window.close()
        return posts


class Messages():

    @staticmethod
    def send_messages_to_friend(friend:str,messages:list[str],at_members:list[str]=[],
        at_all:bool=False,search_pages:bool=None,clear:bool=None,
        send_delay:float=None,is_maximize:bool=None,close_weixin:bool=None)->None:
        '''
        该方法用于给单个好友或群聊发送信息
        Args:
            friend:好友或群聊备注。格式:friend="好友或群聊备注"
            messages:所有待发送消息列表。格式:message=["消息1","消息2"]
            at_members:群聊内所有需要@的群成员昵称列表(注意必须是群昵称)
            at_all:群聊内@所有人,默认为False
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            send_delay:发送单条消息延迟,单位:秒/s,默认0.2s(0.1-0.2之间是极限)。
            clear:是否删除编辑区域已有的内容,默认删除
            is_maximize:微信界面是否全屏,默认不全屏。
            close_weixin:任务结束后是否关闭微信,默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if send_delay is None:
            send_delay=GlobalConfig.send_delay
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if clear is None:
            clear=GlobalConfig.clear
        if not messages:
            raise ValueError(f'不能发送空白消息!')
        #先使用open_dialog_window打开对话框
        main_window=Navigator.open_dialog_window(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        edit_area=main_window.child_window(**Edits.CurrentChatEdit)
        if not edit_area.exists(timeout=0.1):
            raise NotFriendError(f'非正常好友,无法发送消息')
        if clear:
            edit_area.set_text('')
        if at_all:
            At_all(main_window)
        if at_members:
            At(main_window,at_members)
        for message in messages:
            if 0<len(message)<2000:
                edit_area.click_input()
                SystemSettings.copy_text_to_clipboard(message)#不要直接set_text,直接set_text相当于默认clear了
                pyautogui.hotkey('ctrl','v',_pause=False)
                time.sleep(send_delay)
                pyautogui.hotkey('alt','s',_pause=False)
            elif len(message)>2000:#字数超过200字发送txt文件
                SystemSettings.convert_long_text_to_txt(message)
                pyautogui.hotkey('ctrl','v',_pause=False)
                time.sleep(send_delay)
                pyautogui.hotkey('alt','s',_pause=False)
                warn(message=f"微信消息字数上限为2000,超过2000字部分将被省略,该条长文本消息已为你转换为txt发送",category=LongTextWarning)
        if close_weixin:
            main_window.close()
    
    
    @staticmethod
    def reply_with_quote(friend:str,quote_text:str,reply_messages:list[str],
        at_members:list[str]=[],at_all:bool=False,search_pages:int=None,
        clear:bool=None,send_delay:float=None,is_maximize:bool=None,close_weixin:bool=None)->None:
        if is_maximize is None:is_maximize=GlobalConfig.is_maximize
        if send_delay is None:send_delay=GlobalConfig.send_delay
        if close_weixin is None:close_weixin=GlobalConfig.close_weixin
        if search_pages is None:search_pages=GlobalConfig.search_pages
        if clear is None:clear=GlobalConfig.clear
        if not reply_messages:raise ValueError('不能发送空白消息!')
        main_window=Navigator.open_dialog_window(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        edit_area=main_window.child_window(**Edits.CurrentChatEdit)
        if not edit_area.exists(timeout=0.1):raise NotFriendError('非正常好友,无法发送消息')
        chat_list=main_window.child_window(**Lists.FriendChatList)
        Tools.activate_chatList(chat_list)
        time.sleep(0.3)
        if clear:edit_area.set_text('')
        if at_all:At_all(main_window)
        if at_members:At(main_window,at_members)
        seen_ids=[]
        target=None
        for _ in range(200):
            items=chat_list.children(control_type='ListItem')
            if not items:break
            for item in reversed(items):
                cn=item.class_name()
                if cn not in ('mmui::ChatItemView',) and quote_text in item.window_text():
                    target=item
                    break
            if target:break
            rid=items[-1].element_info.runtime_id if items else None
            if rid and rid in seen_ids:break
            if rid:seen_ids.append(rid)
            chat_list.type_keys('{PGUP}')
            time.sleep(0.2)
        if not target:raise ValueError('未找到包含 ' + quote_text + ' 的消息')
        rect=target.rectangle()
        mouse.right_click(coords=(rect.left+80,rect.top+20))
        time.sleep(0.5)
        quote_btn=None
        for m in main_window.descendants(control_type='MenuItem'):
            if m.is_visible() and m.window_text() in ('引用','Quote'):
                quote_btn=m
                break
        if not quote_btn:raise ValueError('未找到引用菜单项')
        quote_btn.click_input()
        time.sleep(0.5)
        send_button=main_window.child_window(**Buttons.SendButton)
        for msg in reply_messages:
            edit_area.click_input()
            edit_area.set_text(msg)
            time.sleep(send_delay)
            send_button.click_input()
        if close_weixin:main_window.close()

    @staticmethod
    def send_audios_to_friend(friend,audios:list[str],audio_length:int=None,clear:bool=None,send_delay:int=None,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用于给单个好友或群聊发送语音
        Args:
            friend:好友或群聊备注。格式:friend="好友或群聊备注"
            audios:所有待发送消息列表。格式:audios=[r'录音.wav',r"音乐.mp3",r"音乐.ogg"]
            audio_length:语音长度,按照微信语音的限制,默认是60s,也可以自行设定,必须在1~60之间
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            send_delay:发送单条消息延迟,单位:秒/s,默认0.2s(0.1-0.2之间是极限)。
            clear:是否删除编辑区域已有的内容,默认删除
            is_maximize:微信界面是否全屏,默认不全屏。
            close_weixin:任务结束后是否关闭微信,默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if send_delay is None:
            send_delay=GlobalConfig.send_delay
        if audio_length is None:
            audio_length=GlobalConfig.audio_length
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if clear is None:
            clear=GlobalConfig.clear
        current_version=GlobalConfig.Version
        if version.parse(current_version)>=version.parse('4.1.9'):
            audios=process_audios(audios=audios,audio_length=audio_length)#处理音频片段
            if audios:
                import sounddevice as sd
                sd.default.device=SystemSettings.get_default_output()
                main_window=Navigator.open_dialog_window(friend=friend,search_pages=search_pages,is_maximize=is_maximize)
                edit_area=main_window.child_window(**Edits.CurrentChatEdit)
                if not edit_area.exists(timeout=0.1):
                    raise NotFriendError(f'非正常好友,无法发送消息')
                if clear:
                    edit_area.set_text('')
                send_audio_button=main_window.child_window(**Buttons.SendAudioButon)
                AudioButtonPos=MousePos(send_audio_button).AudioButtonPos
                MainWindowPos=MousePos(main_window).MainWindowPos
                MousePos(send_audio_button).AudioButtonPos
                for samplerate,audio in audios:
                    duration=len(audio)//samplerate
                    send_audio_button.click_input() 
                    mouse.move(coords=MainWindowPos)
                    sd.play(audio,samplerate)
                    sd.wait()
                    if duration!=60:#60s自动发，不用再点了
                        mouse.click(coords=(AudioButtonPos))
                    time.sleep(send_delay)
                if close_weixin:main_window.close() 
        else:
            print(f'当前微信版本不支持发送语音!')

    @staticmethod
    def message_chain(group:str,content:str=None,theme:str=None,example:str=None,description:str=None,search_pages:bool=None,
       is_maximize:bool=None,close_weixin:bool=None)->None:
        '''
        该方法用来在群聊中发起接龙
        Args:
            group:群聊备注
            content:发起接龙时自己所填的内容(默认是自己的群昵称)
            theme:接龙的主题
            example:接龙的例子
            description:接龙详细描述
            search_pages:在会话列表中查找群聊时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面 
            is_maximize:微信界面是否全屏,默认不全屏。
            close_weixin:任务结束后是否关闭微信,默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        #先使用open_dialog_window打开对话框
        main_window=Navigator.open_dialog_window(friend=group,is_maximize=is_maximize,search_pages=search_pages)
        edit_area=main_window.child_window(**Edits.CurrentChatEdit)
        if not edit_area.exists(timeout=0.1):
            raise NotFriendError(f'非正常好友,无法发送消息')
        if Tools.is_group_chat(main_window):
            edit_area.set_text('#接龙')
            pyautogui.press('down')
            pyautogui.press('enter')
            solitaire_window=main_window.child_window(**Windows.SolitaireWindow)
            solitaire_button=solitaire_window.child_window(**Buttons.SolitaireButton)
            solitaire_list=solitaire_window.child_window(**Lists.SolitaireList)
            if content is not None:
                SystemSettings.copy_text_to_clipboard(content)
                solitaire_list.click_input()#自己填写的内容正好在接龙列表的中间,所以直接click_input()
                pyautogui.hotkey('ctrl','a')#全选删除然后复制content
                pyautogui.press('backspace')
                pyautogui.hotkey('ctrl','v')
            if isinstance(theme,str):
                solitaire_window.child_window(control_type='Edit',found_index=0).set_text(theme)
            if isinstance(example,str):
                solitaire_window.child_window(control_type='Edit',found_index=1).set_text(example)
            if isinstance(description,str):
                AddContentText=solitaire_window.child_window(**Texts.AddContentText)
                SolitairePos=MousePos(AddContentText).SolitairePos
                mouse.click(coords=SolitairePos)
                solitaire_window.child_window(control_type='Edit',found_index=2).set_text(description)
            solitaire_button.click_input()
        if close_weixin:main_window.close()

    @staticmethod
    def send_messages_to_friends(friends:list[str],messages:list[list[str]],clear:bool=None,
        send_delay:float=None,is_maximize:bool=None,close_weixin:bool=None)->None:
        '''
        该方法用于给多个好友或群聊发送信息
        Args:
            friends:好友或群聊备注列表,格式:firends=["好友1","好友2","好友3"]。
            messages:待发送消息,格式: message=[[发给好友1的消息],[发给好友2的消息],[发给好友3的信息]]。
            clear:是否删除编辑区域已有的内容,默认删除。
            send_delay:发送单条消息延迟,单位:秒/s,默认0.2s。
            is_maximize:微信界面是否全屏,默认不全屏。
            close_weixin:任务结束后是否关闭微信,默认关闭
        注意!messages与friends长度需一致,并且messages内每一个列表顺序需与friends中好友名称出现顺序一致,否则会出现消息发错的尴尬情况
        '''
        #多个好友的发送任务不需要使用open_dialog_window方法了直接在顶部搜索栏搜索,一个一个打开好友的聊天界面，发送消息,这样最高效
        def send_messages(friend):
            if clear:
               edit_area.set_text('')
            for message in Chats.get(friend):
                if 0<len(message)<2000:
                    edit_area.set_text(message)
                    time.sleep(send_delay)
                    pyautogui.hotkey('alt','s',_pause=False)
                if len(message)>2000:
                    SystemSettings.convert_long_text_to_txt(message)
                    pyautogui.hotkey('ctrl','v',_pause=False)
                    time.sleep(send_delay)
                    pyautogui.hotkey('alt','s',_pause=False)
                    warn(message=f"微信消息字数上限为2000,超过2000字部分将被省略,该条长文本消息已为你转换为txt发送",
                    category=LongTextWarning) 
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if send_delay is None:
            send_delay=GlobalConfig.send_delay
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if clear is None:
            clear=GlobalConfig.clear
        Chats=dict(zip(friends,messages))
        main_window=Navigator.open_weixin(is_maximize=is_maximize)
        edit_area=main_window.child_window(**Edits.CurrentChatEdit)
        for friend in Chats:
            search_edits=main_window.descendants(**Main_window.Search)
            search_edit=search_edits[1] if len(search_edits)==2 else search_edits[0]
            search_edit.click_input()
            search_edits.set_text(friend)
            search_results=main_window.child_window(title='',control_type='List')
            search_results.wait(wait_for='ready',timeout=1)
            friend_button=Tools.get_search_result(friend=friend,search_result=search_results)
            if friend_button:
                friend_button.click_input()
                edit_area.click_input()
                send_messages(friend)
        if close_weixin:main_window.close()

    @staticmethod
    def check_new_messages(is_maximize:bool=None,search_pages:int=None,close_weixin:bool=None)->dict[str,list[dict]]:
        '''
        该方法用来检查一遍微信会话列表内的新消息
        Args:
            search_pages:打开好友聊天窗口时在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            newMessages:新消息字典,{'好友':pull_messages方法返回值}
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        newMessages={}
        main_window=Navigator.open_weixin(is_maximize=is_maximize)
        new_message_num=get_new_message_num(main_window,close_weixin=False)
        if new_message_num:
            new_messages=[]
            new_message_dict=scan_for_new_messages(main_window=main_window,is_maximize=is_maximize,close_weixin=False)
            for friend,num in new_message_dict.items():
                message=Messages.pull_messages(friend=friend,number=num,close_weixin=False,search_pages=search_pages)
                new_messages.append(message)
            newMessages=dict(zip(new_message_dict.keys(),new_messages))
        if not new_message_num:
            print(f'未发现新消息')
        if close_weixin:main_window.close()
        return newMessages
    
    #session_pick_window中使用ui自动化选择2个以上好友时微信会莫名奇妙白屏卡死，所以先暂时不实现这个方法了
    # @staticmethod
    # def forward_message(friends:list[str],message:str,clear:bool=None,
    #     send_delay:float=None,is_maximize:bool=None,close_weixin:bool=None)->None:
     
    #     if is_maximize is None:
    #         is_maximize=GlobalConfig.is_maximize
    #     if send_delay is None:
    #         send_delay=GlobalConfig.send_delay
    #     if close_weixin is None:
    #         close_weixin=GlobalConfig.close_weixin
    #     if clear is None:
    #         clear=GlobalConfig.clear
    #     if len(friends)<2:
    #         raise ValueError(f'friends数量不足2,无法转发消息!')
    #     def session_picker():
    #         session_pick_window=main_window.child_window(**Windows.SessionPickerWindow)
    #         send_button=session_pick_window.child_window(**Buttons.SendButton)
    #         checkbox=session_pick_window.child_window(control_type='CheckBox',found_index=0)
    #         rec=send_button.rectangle()
    #         x,y=rec.mid_point().x,rec.mid_point().y
    #         search_field=session_pick_window.child_window(control_type='Edit',found_index=0)
    #         search_field.click_input()
    #         for friend in friends[1:]:
    #             search_field.set_text(friend)
    #             checkbox.click_input()
    #         send_button.click_input()
    #     main_window=Navigator.open_dialog_window(friend=friends[0],is_maximize=is_maximize)
    #     edit_area=main_window.child_window(**Edits.CurrentChatEdit)
    #     chat_list=main_window.child_window(**Lists.FriendChatList)
    #     if not edit_area.exists(timeout=0.1):
    #         raise NotFriendError(f'非正常好友,无法发送消息')
    #     if clear:
    #         edit_area.set_text('')
    #     if len(message)==0:
    #         main_window.close()
    #         raise ValueError
    #     if 0<len(message)<2000:
    #         edit_area.set_text(message)
    #         time.sleep(send_delay)
    #         pyautogui.hotkey('alt','s',_pause=False)
    #     elif len(message)>2000:#字数超过200字发送txt文件
    #         SystemSettings.convert_long_text_to_txt(message)
    #         pyautogui.hotkey('ctrl','v',_pause=False)
    #         time.sleep(send_delay)
    #         pyautogui.hotkey('alt','s',_pause=False)
    #         warn(message=f"微信消息字数上限为2000,超过2000字部分将被省略,该条长文本消息已为你转换为txt发送",category=LongTextWarning)
    #     if len(friends)>1:
    #         listItems=chat_list.children(control_type='ListItem')
    #         message_sent=listItems[-1]
    #         rect=message_sent.rectangle()
    #         mouse.right_click(coords=(rect.right-100,rect.mid_point().y))
    #         forward_item=main_window.child_window(**MenuItems.ForwardMenuItem)
    #         forward_item.click_input()
    #         session_picker()
    #     if close_weixin:
    #         main_window.close()

    @staticmethod
    def dump_recent_sessions(recent:Literal['Today','Yesterday','Week','Month','Year']='Today',
        chat_only:bool=False,is_maximize:bool=None,close_weixin:bool=None)->list[tuple]:
        '''
        该方法用来获取会话列表内最近的聊天对象的名称,最后聊天时间
        Args:
            recent:获取最近消息的时间节点,可选值为'Today','Yesterday','Week','Month','Year'分别获取当天,昨天,本周,本月,本年
            chat_only:只获取会话列表中有消息的好友(ListItem底部有灰色消息不是空白),默认为False
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            sessions:[('发送人','最后聊天时间','最后聊天内容')]
        '''
        #去除列表重复元素
        def remove_duplicates(list):
            #把名字发送时间最后一条消息内容拼接在一起作为unique_id
            #这三者完全一样的概率很小
            seen=set()
            result=[]
            for item in list:
                unique_id=item[0]+item[1]+item[2]
                if unique_id not in seen:
                    seen.add(unique_id)
                    result.append(item)
            return result
        
        def extract_info(listitem):
            timestamp=''
            pure_text=listitem.window_text().replace(SutckOnTop_label,'').replace(MuteNotifications_label,'')
            name=listitem.automation_id().replace('session_item_','')
            timestamp=timestamp_pattern.search(pure_text)
            if timestamp:timestamp=timestamp.group(0)    
            msg=pure_text.replace(f'{name}\n','').replace(f'\n{timestamp}\n','')
            return name,timestamp,msg

        #正则匹配获取时间
        def get_sending_time(listitem):
            pure_text=listitem.window_text().replace(SutckOnTop_label,'').replace(MuteNotifications_label,'')
            timestamp=timestamp_pattern.search(pure_text)
            if timestamp:return timestamp.group(0)
            return ''
        
        #根据recent筛选和过滤会话
        def filter_sessions(ListItems):
            ListItems=[ListItem for ListItem in ListItems if get_sending_time(ListItem)]
            if recent=='Year' or recent=='Month':
                ListItems=[ListItem for ListItem in ListItems if not year_pattern.search(get_sending_time(ListItem))]
            if recent=='Week':
                ListItems=[ListItem for ListItem in ListItems if '/' not in get_sending_time(ListItem)]
            if recent=='Today' or recent=='Yesterday':
                ListItems=[ListItem for ListItem in ListItems if ':' in get_sending_time(ListItem)]
            if chat_only:
                ListItems=[ListItem for ListItem in ListItems if extract_info(ListItem)[2]!='']
            return ListItems
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        
        sessions=[]#会话对象 ListItem
        SutckOnTop_label=Special_Labels.StuckonTop
        MuteNotifications_label=Special_Labels.MuteNotifications
        Yesterday_label=Special_Labels.Yesterday
        #符合year_pattern的肯定不是今年的
        year_pattern=re.compile(r'\d{4}/\d{2}/\d{2}')#
        thismonth=str(int(time.strftime('%m')))+'/'#去年
        #最右侧时间戳正则表达式:五种,2024/05/01,10/25,昨天,星期一,10:59,
        timestamp_pattern=Regex_Patterns.Session_Timestamp_pattern
        main_window=Navigator.open_weixin(is_maximize=is_maximize)
        main_window.child_window(**SideBar.Weixin).click_input()
        session_list=main_window.child_window(**Main_window.SessionList)
        scrollable=Tools.is_scrollable(session_list,back='end')
        if not scrollable:
            listItems=session_list.children(control_type='ListItem')
            listItems=filter_sessions(listItems)
            sessions.extend([extract_info(listitem) for listitem in listItems])
        if scrollable:
            last=session_list.children(control_type='ListItem')[-1].window_text()
            session_list.type_keys('{HOME}')
            time.sleep(1)
            while True:
                listItems=session_list.children(**ListItems.SessionListItem)
                filtered_listItems=filter_sessions(listItems)
                if not filtered_listItems:
                    break
                if listItems[-1].window_text()==last:
                    break
                sessions.extend([extract_info(listitem) for listitem in  filtered_listItems])
                session_list.type_keys('{PGDN}') 
            session_list.type_keys('{HOME}')
        sessions=remove_duplicates(sessions)
        if close_weixin:
            main_window.close()
        #进一步筛选
        if recent=='Yesterday':
            sessions=[session for session in sessions if Yesterday_label in session[1]]
        if recent=='Today':
            sessions=[session for session in sessions if Yesterday_label not in session[1]]
        if recent=='Month':
            weeek_sessions=[session for session in sessions if '/' not  in session[1]]
            month_sessions=[session for session in sessions if thismonth in session[1]]
            sessions=weeek_sessions+month_sessions
        return sessions

    @staticmethod
    def dump_sessions(chat_only:bool=False,is_maximize:bool=None,close_weixin:bool=None)->list[tuple]:
        '''
        该方法用来获取会话列表内所有聊天对象的名称,最后聊天时间,以及最后一条聊天消息,使用时建议全屏这样不会有遗漏!
        Args:
            chat_only:只获取会话列表中有消息的好友(ListItem底部有灰色消息不是空白),默认为False
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            sessions:[('发送人','最后聊天时间','最后聊天内容')]
        '''
        def filter_sessions(listItems):
            listItems=[listItem for listItem in listItems if get_sending_time(listItem)]
            if chat_only:
                listItems=[listItem for listItem in listItems if extract_info(listItem)[2]!='']
            return listItems

        def get_sending_time(listitem):
            pure_text=listitem.window_text().replace(SutckOnTop_label,'').replace(MuteNotifications_label,'')
            timestamp=timestamp_pattern.search(pure_text)
            if timestamp:return timestamp.group(0)
            return ''
        
        def extract_info(listitem):
            timestamp=''
            pure_text=listitem.window_text().replace(SutckOnTop_label,'').replace(MuteNotifications_label,'')
            name=listitem.automation_id().replace('session_item_','')
            timestamp=timestamp_pattern.search(pure_text)
            if timestamp:timestamp=timestamp.group(0)    
            msg=pure_text.replace(f'{name}\n','').replace(f'\n{timestamp}\n','')
            return name,timestamp,msg
        
        def remove_duplicates(list):
            '''对sessions,这个list[tuple]对象去重'''
            #把名字，发送时间，还有最后一条消息内容拼接在一起作为unique_id
            #这三者完全一样的概率很小
            seen=set()
            result=[]
            for item in list:
                unique_id=item[0]+item[1]+item[2]
                if unique_id not in seen:
                    seen.add(unique_id)
                    result.append(item)
            return result
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin

        sessions=[]
        SutckOnTop_label=Special_Labels.StuckonTop
        MuteNotifications_label=Special_Labels.MuteNotifications
        #最右侧时间戳正则表达式:五种,2024/05/01,10/25,昨天,星期一,10:59,
        timestamp_pattern=Regex_Patterns.Session_Timestamp_pattern
        main_window=Navigator.open_weixin(is_maximize=is_maximize)
        main_window.child_window(**SideBar.Weixin).click_input()
        session_list=main_window.child_window(**Main_window.SessionList)
        scrollable=Tools.is_scrollable(session_list,back='end')
        if not scrollable:
           listItems=session_list.children(**ListItems.SessionListItem)
           filtered_listItems=filter_sessions(listItems)
           sessions.extend([extract_info(listitem) for listitem in filtered_listItems])
        if scrollable:
            time.sleep(1)
            listItems=session_list.children(**ListItems.SessionListItem)
            last=listItems[-1].window_text()
            session_list.type_keys('{HOME}')
            time.sleep(1)
            while True:
                listItems=session_list.children(**ListItems.SessionListItem)
                filtered_listItems=filter_sessions(listItems)
                sessions.extend([extract_info(listitem) for listitem in filtered_listItems])
                session_list.type_keys('{PGDN}')
                if listItems[-1].window_text()==last:
                    break
        session_list.type_keys('{HOME}')
        if close_weixin:main_window.close()
        sessions=remove_duplicates(sessions)
        return sessions

    @staticmethod
    def pull_messages(friend:str,number:int,is_json:bool=False,myName:str=None,groupMembers:list=[],search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None)->list[dict]:
        '''
        该方法用来从聊天界面向上滚动获取聊天消息
        Args:
            friend:好友或群聊备注
            number:获取的消息数量
            is_json:返回结果是否为json字符串,便于导出
            myName:个人昵称
            groupMembers:friend对应的群成员列表(可提前通过Contacts.get_groupMembers_info导出保存至本地),如果friend是群聊且传入了该参数则无需遍历二次
            search_pages:打开好友聊天窗口时在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            chat_history:[{'消息发送人':xxx,'消息内容':yyy,'消息类型'}....]
        '''
    
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        messages=[]
        main_window=Navigator.open_dialog_window(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        edit_area=main_window.child_window(**Edits.CurrentChatEdit)
        chat_list=main_window.child_window(**Lists.FriendChatList)
        if not edit_area.exists(timeout=0.1):
            print(f'非正常好友或群聊,无法获取聊天信息！')
            return messages
        else:
            if not chat_list.children(control_type='ListItem'):
                main_window.close()
                warn(message=f'你与{friend}的聊天记录为空,无法获取聊天信息',category=NoChatHistoryWarning)
                return messages
            else:
                is_group_chat=Tools.is_group_chat(main_window)
                if not is_group_chat and myName is None:myName=Contacts.check_my_info(close_weixin=False).get('昵称')
                details_with_name=traverse_message(main_window,select=True,number=number)
                if not is_group_chat:
                    contents,senders,message_tpyes=parse_messages(friend,myName,details_with_name)
                if is_group_chat:
                    if groupMembers:details_without_name=[]
                    if not groupMembers:details_without_name=traverse_message(main_window,select=False,number=number)
                    contents,senders,message_tpyes=parse_group_messages(details_with_name,details_without_name,groupMembers)
            chat_history=[{'消息发送人':chat[0],'消息内容':chat[1],'消息类型':chat[2]} for chat in zip(senders,contents,message_tpyes)]
            if is_json:chat_history=json.dumps(chat_history,ensure_ascii=False,indent=2)
            if close_weixin:main_window.close()
        return chat_history
    
    @staticmethod
    def dump_chat_history(friend:str,number:int,groupMembers:list=[],search_content:str=None,is_json:bool=False,save_detail:bool=False,
    target_folder:str=None,search_pages:int=None,is_maximize:bool=None,close_weixin:bool=None)->list[dict]:
        '''
        该方法用来获取一定数量的聊天记录
        Args:  
            friend:好友名称
            number:获取的消息数量
            groupMembers:friend对应的群成员列表(可提前通过Contacts.get_groupMembers_info导出保存至本地),如果friend是群聊且传入了该参数则直接解析发送人(无需遍历二次)
            search_content:搜索关键字,传入后会先在顶部搜索关键字然后向下遍历
            is_json:返回结果是否为json字符串,便于导出
            save_detail:是否将保存聊天记录明细包括,图片,视频,文件,聊天记录.json
            target_folder:保存图片、视频、文件、聊天记录.json的文件夹
            search_pages:打开好友聊天窗口时在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,为0时,直接从顶部搜索栏搜索好友信息
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            chat_history:[{'消息发送人':xxx,'消息内容':yyy,'消息类型':xxx,'消息发送时间':yyy}....]
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if save_detail and target_folder is None:
            target_folder=os.path.join(os.getcwd(),f'dump_chat_history聊天记录明细',f'{friend}')
            print(f'未传入文件夹路径,聊天记录明细将分别保存到{target_folder}内')
            os.makedirs(target_folder,exist_ok=True)

        main_window=Navigator.open_dialog_window(friend=friend,is_maximize=is_maximize,search_pages=search_pages)
        is_group_chat=Tools.is_group_chat(main_window)
        if not is_group_chat:
            myName=Contacts.check_my_info(close_weixin=close_weixin).get('昵称')      
        chat_history_window=Navigator.open_chat_history(friend=friend,is_maximize=is_maximize,close_weixin=close_weixin,search_pages=search_pages)
        Tools.cancel_pin(chat_history_window)
        if isinstance(search_content,str):
            search_bar=chat_history_window.descendants(**Edits.SearchEdit)[0]
            search_bar.set_text(search_content)
        chat_history_list=chat_history_window.child_window(**Lists.ChatHistoryList)
        if not chat_history_list.exists(timeout=1):
            warn(message=f"你与{friend}的聊天记录为空,无法获取聊天记录!",category=NoChatHistoryWarning)
            chat_history_window.close()
            return [],[],[]
        win32gui.SendMessage(chat_history_window.handle,win32con.WM_SYSCOMMAND,win32con.SC_MAXIMIZE,0)
        details_with_name=traverse_chat_history(chat_history_window,select=True,number=number,save_detail=save_detail,target_folder=target_folder)
        if not is_group_chat:
            contents,senders,timestamps,message_types=parse_chat_history(friend,myName,details_with_name)
        if is_group_chat:
            if groupMembers:details_without_name=[]
            if not groupMembers:
                details_without_name=traverse_chat_history(chat_history_window,select=False,number=number)
            contents,senders,timestamps,message_types=parse_group_chat_history(details_with_name,details_without_name,groupMembers)
        chat_history_window.close()
        chat_history=[{'消息发送人':chat[0],'消息内容':chat[1],'消息类型':chat[2],'消息发送时间':chat[3]} for chat in zip(senders,contents,message_types,timestamps)]
        if save_detail:
            chat_history_json=json.dumps(chat_history,ensure_ascii=False,indent=2)
            json_path=os.path.join(target_folder,f'{friend}聊天记录信息.json')
            with open(json_path,'w',encoding='utf-8') as f:
                f.write(chat_history_json)
        if is_json:
            chat_history=json.dumps(chat_history,ensure_ascii=False,indent=2)
        return chat_history

    @staticmethod
    def search_chat_history(keyword:str,number:int=None,with_content:bool=False,is_maximize:bool=None,close_weixin:bool=None)->dict[str,list[str]]:
        '''
        该方法用来在微信顶部搜索关键字然后遍历查找聊天记录
        Args:
            keyword:聊天记录关键字
            number:获取前number条相关的聊天记录,在数量达到number时结束(不传入该参数默认获取全部)
            with_content:是否获取具体的聊天记录内容,为False时只获取聊天记录数量
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        Returns:
            chat_history_detail:聊天记录明细
        '''
        def traverse_message_list(message_list:ListViewWrapper)->list[str]:
            messages=[]
            runtime_ids=[]
            total_num=int(re.search(r'\d+',total_label.window_text()).group(0))
            scrollable=Tools.is_scrollable(message_list,back='top')
            if not scrollable:
                messages=[listitem.window_text() for listitem in message_list.children(control_type='ListItem')]
            if scrollable:
                first_item=message_list.children(control_type='ListItem')[0]
                messages.append(first_item.window_text())
                runtime_ids.append(first_item.element_info.runtime_id)
                while len(messages)<total_num:
                    pyautogui.press('down',presses=2,_pause=False)
                    selected=[listitem for listitem in message_list.children(control_type='ListItem') if listitem.has_keyboard_focus()]
                    if selected:
                        runtime_ids.append(selected[0].element_info.runtime_id)
                        #同一个runtime_id挨着重复出现就说明到底部了无法继续下滑
                        if runtime_ids[-1]==runtime_ids[-2]:
                            break
                        messages.append(selected[0].window_text())
            return messages

        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        chat_history_detail={}
        chat_history_window,main_window=Navigator.open_chat_search_window(keyword=keyword,window_maximize=True)
        if chat_history_window is not None:
            search_list=chat_history_window.child_window(**Lists.SearchResult)
            message_list=chat_history_window.child_window(auto_id='message_list')
            rectangle=search_list.rectangle()
            scroll_position=(rectangle.mid_point().x,rectangle.mid_point().y)
            total_label=chat_history_window.child_window(control_type='Text',found_index=3)
            current_item=search_list.children(control_type='ListItem')[0]
            current_item.click_input()
            while True:
                Tools.activate_chatHistoryList(message_list)#激活滑块
                if with_content:
                    chat_history_detail[current_item.window_text()]=traverse_message_list(message_list)
                if not with_content:
                    chat_history_detail[current_item.window_text()]=int(re.search(r'\d+',total_label.window_text()).group(0))
                if isinstance(number,int) and len(chat_history_detail)>=number:
                    break
                next_item=Tools.get_next_item(search_list,current_item)
                if next_item is None:
                    mouse.scroll(coords=scroll_position,wheel_dist=-12)
                    next_item=Tools.get_next_item(search_list,current_item)
                if next_item is None:
                    break
                SearchChatPos=MousePos(next_item).SearchChatPos
                mouse.click(coords=SearchChatPos)
                current_item=next_item
        chat_history_window.close()
        if close_weixin:
            main_window.close()
        return chat_history_detail
    
    @staticmethod
    def save_media(friend:str,number:int,target_folder:str=None,is_maximize:bool=None,close_weixin:bool=None,search_pages:int=None)->None:
        '''
        该方法用来保存与某个好友或群聊的图片和视频到指定文件夹中
        Args:
            friend:好友或群聊备注
            number:需要保存的图片数量
            target_folder:保存图片的文件夹路径,如果不传入则默认保存在当前运行代码所在的文件夹下
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,当search_pages为0时,直接从顶部搜索栏法搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏,默认全屏。
            close_wechat:任务结束后是否关闭微信,默认关闭
        Examples:
            ```
            from pywechat import Messages
            target_folder=r'E:\\新建文件夹'
            Messages.save_media(friend='测试群',number=20,ftarget_folder=target_folder)
            ```
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages
        if target_folder is not None and not os.path.isdir(target_folder):
            raise NotFolderError(f'所选路径不是文件夹!无法保存聊天记录,请重新选择!')
        if target_folder is None:
            target_folder=os.path.join(os.getcwd(),'Messages.save_media聊天图片保存',friend)
            os.makedirs(name=target_folder,exist_ok=True)
            print(f'未传入文件夹路径,聊天图片或视频将保存至 {target_folder}')
        saved_num=0
        presses_num=1 if version.parse(GlobalConfig.Version)>=version.parse('4.1.9') else 2
        chat_history_window=Navigator.open_chat_history(friend=friend,TabItem='图片与视频',search_pages=search_pages,is_maximize=is_maximize,close_weixin=close_weixin)
        image_container=chat_history_window.child_window(control_type='Group',class_name="QFWidget")
        if not image_container.exists(timeout=0.2):#看一下是否存在聊天记录列表，如果不存在说明没有聊天记录    
            chat_history_window.close()
            raise ValueError(f'你还未与{friend}聊天,无法保存聊天图片!') 
        image_container.children()[1].click_input()
        #先右键最后一个图片激活菜单
        image_preview_window=Tools.move_window_to_center(Windows.ImagePreviewWindow)
        image_expired=image_preview_window.child_window(**Texts.ImageExpiredText)
        video_expired=image_preview_window.child_window(**Texts.VideoExpiredText)
        earliest_image=image_preview_window.child_window(**Texts.EarliestOneText)
        rotate_button=image_preview_window.child_window(**Buttons.RotateButton)
        image_area=image_preview_window.child_window(class_name='mmui::XViewPager',control_type='Custom')
        chat_history_window.close()
        while saved_num<number:
            is_image_expired=image_expired.exists(timeout=0.1)
            is_video_expired=video_expired.exists(timeout=0.1)
            is_image=rotate_button.exists(timeout=0.1)
            if is_image_expired or is_video_expired:  
                #如果图片过期或者视频直接跳过
                pyautogui.press('left',_pause=False)
            if is_image and not is_image_expired:
                #有旋转按钮是图片
                saved_num+=1
                pic_path=os.path.join(target_folder,f'与{friend}的聊天图片{saved_num}.png')
                image=image_area.capture_as_image()
                image.save(pic_path)
                pyautogui.press('left',_pause=False)
            if not is_image and not is_video_expired:
                #没有旋转按钮是视频
                is_download=False
                saved_num+=1
                image_area.right_click_input()
                video_path=os.path.join(target_folder,f'与{friend}的聊天视频{saved_num}.mp4')
                image_preview_window.click_input()
                while not is_download:
                    image_preview_window.right_click_input()
                    copy_item=image_preview_window.child_window(**MenuItems.CopyMenuItem)
                    if copy_item.exists(timeout=0.2):
                        is_download=True 
                    time.sleep(0.2)       
                pyautogui.press('down',presses=presses_num)
                pyautogui.press('enter')
                time.sleep(2)
                SystemSettings.save_pasted_video(video_path=video_path)
                pyautogui.press('left',_pause=False)
            if earliest_image.exists(timeout=0.1):
                #按下左键后可能会出现这是第一张图片的提示,那么直接退出循环
                break
        image_preview_window.close()
        if saved_num==0:
            print(f"你与{friend}无聊天图片与视频,未能保存!")
        if saved_num<number and saved_num!=0:
            print(f"你与{friend}的聊天图片与视频不足{number},已为你保存全部的{saved_num}张图片与视频")
  
    @staticmethod
    def accept_group_invitation(friend:str,number:int,max_num:int=100,is_maximize:bool=None,close_weixin:bool=None,search_pages:int=None)->None:
        '''
        该方法用来从聊天记录链接中查找入群邀请并加入
        Args:
            number:群聊邀请链接的数量
            max_num:在链接中查找入群邀请时的历史记录的最大遍历条数
            search_pages:在会话列表中查找好友时滚动列表的次数,默认为5,一次可查询5-12人,当search_pages为0时,直接从顶部搜索栏法搜索好友信息打开聊天界面
            is_maximize:微信界面是否全屏,默认全屏。
            close_wechat:任务结束后是否关闭微信,默认关闭
        Returns:
            joined_num:实际加入的数量
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if search_pages is None:
            search_pages=GlobalConfig.search_pages

        def click_cardLink(listitem):
            sign='无法加入'
            listitem.double_click_input()
            try:
                group_invitation_pane=desktop.window(**Panes.GroupInvitationPane)
                group_invitation_pane.restore()
                time.sleep(3)
                join_group_button=group_invitation_pane.child_window(**Buttons.JoinGroupButton)
                invitation_sent_text=group_invitation_pane.child_window(**Texts.InvitationSentText)
                invitation_expired_text=group_invitation_pane.child_window(**Texts.InvitationExpiredText)
                if invitation_sent_text.exists(timeout=0.1):
                    sign='邀请由自己发送,已加入该群'
                    group_invitation_pane.close()
                if invitation_expired_text.exists(timeout=0.1):
                    sign='邀请已过期'
                    group_invitation_pane.close()
                if join_group_button.exists(timeout=0.1):
                    join_group_button.click_input()
                    sign='成功入群'
            except Exception:
                sign='网络异常,未能正确打开群聊邀请界面'
                group_invitation_pane.close()
            return sign
        
        checked_num=0
        joined_num=0
        results=[]
        invitation_text='邀请你加入群聊'
        Timestamp_pattern=re.compile(r'(?<=\s)(\d{2}/\d{1,2}/\d{1,2}|\d{1,2}/\d{1,2}|星期\w|昨天|\d{2}:\d{2})$')
        chat_history_window=Navigator.open_chat_history(friend=friend,TabItem='链接',search_pages=search_pages,is_maximize=is_maximize,close_weixin=close_weixin)
        Tools.cancel_pin(chat_history_window)#取消聊天记录框置顶,不然入群邀请窗口只能在聊天记录窗口底部
        chat_history_list=chat_history_window.child_window(**Lists.ChatHistoryList)
        if not chat_history_list.exists(timeout=1):
            warn(message=f"你与{friend}的聊天记录为空,无法获取入群链接",category=NoChatHistoryWarning)
            chat_history_window.close()
            return [],[]
        search_edit=chat_history_window.child_window(control_type='Edit')
        search_edit.set_text(invitation_text)
        win32gui.SendMessage(chat_history_window.handle,win32con.WM_SYSCOMMAND,win32con.SC_MAXIMIZE,0)
        scrollable=Tools.is_scrollable(chat_history_list)
        if not scrollable:
            for listitem in chat_history_list.children(control_type='ListItem'):
                title=Timestamp_pattern.sub('',listitem.window_text()).strip()
                if title==invitation_text:
                    sign=click_cardLink(listitem)
                    results.append(sign)
        else:
            current_item=chat_history_list.children(control_type='ListItem')[0]
            while checked_num<max_num:
                next_item=Tools.get_next_item(chat_history_list,current_item)
                if next_item is None:
                    pyautogui.press('pagedown',interval=0.5)
                    chat_history_list=chat_history_window.child_window(**Lists.ChatHistoryList)
                    next_item=Tools.get_next_item(chat_history_list,current_item)
                if next_item is None:#到达底部
                    break
                sign=click_cardLink(current_item)
                results.append(sign)
                if sign=='成功入群':
                    joined_num+=1
                if joined_num>=number:
                    break
                current_item=next_item
                checked_num+=1
        chat_history_list.type_keys('{HOME}')
        chat_history_window.close()
        return results


class Monitor():
    '''监听消息的一些方法'''          

    @staticmethod
    def listen_on_chat(dialog_window:WindowSpecification,duration:str,groupMembers:list=[],save_file:bool=False,save_media:bool=False,target_folder:str=None,close_dialog_window:bool=True)->dict:
        '''
        该方法用来在指定时间内监听会话窗口内的新消息(可以配合多线程使用,一次监听多个会话内的消息)
        Args:
            dialog_window:好友单独的聊天窗口或主界面内的聊天窗口,可使用Navigator内的方法打开
            duraiton:监听持续时长,监听消息持续时长,格式:'s','min','h'单位:s/秒,min/分,h/小时
            groupMembers:如果监听的是群聊需要传入群成员,否则无法获取到具体的消息发送人,需要自行从文本内容中获取
            save_file:是否保存文件,需开启自动下载文件并设置为1024MB,默认为False
            save_media:是否保存图片,注意不要在多线程中设置为True,针对单个好友可以设置为True,默认为False
            target_folder:文件或图片视频的保存文件夹
            close_dialog_window:是否关闭dialog_window,默认关闭
        涉及到键鼠操作的选项须为False,无论是主界面还是单独聊天窗口都可以最小化到状态栏,但千万不要关闭！
        Examples:
            多线程使用示例:
            >>> from concurrent.futures import ThreadPoolExecutor
            >>> from pyweixin import Navigator,Monitor
            >>> #先打开所有好友的独立窗口
            >>> dialog_windows=[]
            >>> friends=['Hello,Mr Crab','Pywechat测试群']
            >>> durations=['1min']*len(friends)
            >>> for friend in friends:
            >>>    dialog_window=Navigator.open_seperate_dialog_window(friend=friend,select=True,window_minimize=True,close_weixin=True)
            >>>    dialog_windows.append(dialog_window)
            >>> with ThreadPoolExecutor() as pool:
            >>>    results=pool.map(lambda args: Monitor.listen_on_chat(*args),list(zip(dialog_windows,durations)))
            >>> for friend,result in zip(friends,results):
            >>>    print(friend,result)
        Returns:
            details:该聊天窗口内的新消息(文本内容),格式为{'新消息总数':x,'文本数量':x,'文件数量':x,'图片数量':x,'视频数量':x,'链接数量':x,'文本内容':x,'消息发送人':x}
        '''
        def extract_info(texts):
            senders=[]
            contents=[]
            if not is_group:
                for text in texts:
                    search_result=re.search(rf'^({re.escape(friend)})\s',text)
                    sender=myName if search_result is None else friend
                    content=re.sub(rf'^{re.escape(sender)}\s','',text)
                    senders.append(sender)
                    contents.append(content)
            if is_group and groupMembers:
                for text in texts:
                    for groupMember in groupMembers:
                        search_result=re.search(rf'^({groupMember})\s',text)
                        if search_result is not None:
                            sender=search_result.group(1)
                    content=re.sub(rf'^{sender}\s','',text)
                    senders.append(sender)
                    contents.append(content)
            if is_group and not groupMembers:
                contents=texts
            return contents,senders

        friend=dialog_window.window_text()
        chatName=dialog_window.child_window(**Texts.CurrentChatNameText)
        if chatName.exists(timeout=0.2):friend=chatName.window_text()
        duration=Tools.match_duration(duration)#将's','min','h'转换为秒
        if duration is None:#不按照指定的时间格式输入,需要提前中断退出
            raise TimeNotCorrectError
        if (save_file or save_media ) and target_folder is None:
            target_folder=os.path.join(os.getcwd(),f'{friend}_listen_on_chat聊天文件保存')
            print(f'未传入文件夹路径,文件,图片将分别保存到{target_folder}内的Files,Images文件夹下\n')
            os.makedirs(target_folder,exist_ok=True)
        if save_file:
            file_folder=os.path.join(target_folder,'Files')
            os.makedirs(file_folder,exist_ok=True)
        if save_media:
            media_folder=os.path.join(target_folder,'Images')
            os.makedirs(media_folder,exist_ok=True)
        total=0
        link_count=0
        video_count=0
        image_count=0
        files=[]
        texts=[]
        visibile_items=[]
        memberEvents=[]
        link_label=Special_Labels.Link
        image_labal=Special_Labels.Image
        video_label=Special_Labels.Video
        file_label=Special_Labels.File
        file_pattern=Regex_Patterns.File_pattern
        is_group=Tools.is_group_chat(dialog_window)
        myName='本人(MySelf)'
        timestamp=time.strftime('%Y-%m')
        chatfile_folder=Tools.where_chatfiles_folder()
        chatList=dialog_window.child_window(**Lists.FriendChatList)#聊天界面内存储所有信息的容器
        timestamp_pattern=Regex_Patterns.Message_Timestamp_pattern#系统消息的时间戳
        if chatList.children(control_type='CheckBox'):
            visibile_items=chatList.children(control_type='CheckBox')
            initial_runtimeids=[item.element_info.runtime_id for item in visibile_items]
        if not chatList.children(control_type='CheckBox'):initial_runtimeids=[]
        end_timestamp=time.time()+duration#根据秒数计算截止时间
        SystemSettings.open_listening_mode(volume=False)
        while time.time()<end_timestamp:
            visibile_items=chatList.children(control_type='CheckBox')
            newItems=[item for item in visibile_items if item.element_info.runtime_id not in initial_runtimeids]
            if newItems: 
                #改为列表轮询
                for item in newItems:
                    texts.append(item.window_text())
                    if item.class_name()=='mmui::ChatItemView' and not timestamp_pattern.search(item.window_text()):
                        memberEvents.append(item.window_text())
                    if item.class_name()=='mmui::ChatBubbleItemView' and link_label in item.window_text():
                        link_count+=1
                    if item.class_name()=='mmui::ChatBubbleReferItemView' and image_labal in item.window_text():
                        image_count+=1
                    if item.class_name()=='mmui::ChatBubbleReferItemView' and video_label in item.window_text():
                        video_count+=1#视频需要下载直接右键复制不行,需要先点击,如果时间长,要等半天，不太方便
                    if item.class_name()=='mmui::ChatBubbleItemView' and file_label in item.window_text():
                        filename=file_pattern.search(item.window_text()).group(1)
                        filepath=os.path.join(chatfile_folder,timestamp,filename)
                        files.append(filepath)
                total+=len(newItems)
                initial_runtimeids=[item.element_info.runtime_id for item in visibile_items]
        media_count=image_count+video_count
        SystemSettings.close_listening_mode()
        contents,senders=extract_info(texts)
        #最后结束时再批量复制到target_folder,不在循环里逐个复制是考虑到若文件过大(几百mb)没有自动下载完成移动不了
        if save_file and files:SystemSettings.copy_files(files,file_folder)#文件复制粘贴到target_folder/Files内
        if save_media and media_count:Messages.save_media(friend=friend,number=media_count,target_folder=target_folder)#保存图片到target_folder/Images内
        details={'新消息总数':total,'文本数量':len(texts),'文件数量':len(files),'图片数量':image_count,'视频数量':video_count,'链接数量':link_count,'文本内容':contents,'消息发送人':senders,'出入群通知':memberEvents}
        if close_dialog_window:dialog_window.close()
        return details

    @staticmethod
    def listen_on_newMemberJoin(dialog_window:WindowSpecification,duration:str,close_dialog_window:bool=True)->list[str]:
        '''
        该方法用来在指定时间内监听群聊内的出入群消息
        Args:
            dialog_window:群聊单独的聊天窗口或主界面内的聊天窗口,可使用Navigator内的方法打开
            duraiton:监听持续时长,监听消息持续时长,格式:'s','min','h'单位:s/秒,min/分,h/小时
            close_dialog_window:是否关闭dialog_window,默认关
        Examples:
            多线程使用示例:
            >>> from concurrent.futures import ThreadPoolExecutor
            >>> from pyweixin import Navigator,Monitor
            >>> #先打开所有好友的独立窗口
            >>> dialog_windows=[]
            >>> friends=['小号测试','Pywechat测试群']
            >>> durations=['1min']*len(friends)
            >>> for friend in friends:
            >>>    dialog_window=Navigator.open_seperate_dialog_window(friend=friend,window_minimize=True,close_weixin=True)
            >>>    dialog_windows.append(dialog_window)
            >>> with ThreadPoolExecutor() as pool:
            >>>    results=pool.map(lambda args: Monitor.listen_on_newMemberJoin(*args),list(zip(dialog_windows,durations)))
            >>> for friend,result in zip(friends,results):
            >>>    print(friend,result)
        Returns:
            details:出入群消息列表
        '''
        details=[]
        duration=Tools.match_duration(duration)#将's','min','h'转换为秒
        if duration is None:#不按照指定的时间格式输入,需要提前中断退出
            raise TimeNotCorrectError
        is_group=Tools.is_group_chat(dialog_window)
        chatList=dialog_window.child_window(**Lists.FriendChatList)#聊天界面内存储所有信息的容器
        Tools.activate_chatList(chatList)
        if chatList.children(control_type='ListItem'):
            initial_message=chatList.children(control_type='ListItem')[-1]#刚打开聊天界面时的最后一条消息的listitem
            initial_runtime_id=initial_message.element_info.runtime_id
        if not chatList.children(control_type='ListItem'):
            initial_runtime_id=0
        timestamp_pattern=Regex_Patterns.Message_Timestamp_pattern#系统消息的时间戳
        end_timestamp=time.time()+duration#根据秒数计算截止时间
        SystemSettings.open_listening_mode(volume=False)
        while time.time()<end_timestamp:
            if chatList.children(control_type='ListItem') and is_group:
                newMessage=chatList.children(control_type='ListItem')[-1]
                runtime_id=newMessage.element_info.runtime_id
                if runtime_id!=initial_runtime_id: 
                    if newMessage.class_name()=='mmui::ChatItemView' and not timestamp_pattern.search(newMessage.window_text()):
                        details.append(newMessage.window_text())
                    initial_runtime_id=runtime_id
        SystemSettings.close_listening_mode()
        if close_dialog_window:dialog_window.close()
        return details

    @staticmethod
    def listen_on_sessionList(duration:str,maxPages:int=0,scroll_delay:float=0.5,is_maximize:bool=None,close_weixin:bool=None)->dict:
        '''
        该方法用来监听会话列表中新消息对应的好友及数量,最大查找数量=maxPages*(8~10)
        Args:
            duration:监听持续时长,格式:'s','min','h'单位:s/秒,min/分,h/小时
            maxPages:遍历会话列表页数,一页为8~10人,为0时只在可见顶部置顶会话列表中查找不滚动遍历
            scroll_delay:滚动遍历maxPages页会话列表间隔
            is_maximize:微信界面是否全屏,默认全屏
            close_weixin:任务结束后是否关闭微信,默认关闭
        Returns:
            newMessageDict:{'好友A':10,'好友B':11,...}
        '''
        def traverse_session_list(sessionList:ListViewWrapper)->dict:
            '''遍历会话列表内的lisitem获取新消息'''
            listItems=[listItem for listItem in sessionList.children(control_type='ListItem') if listItem.automation_id().replace('session_item_','') not in NeverReply
            and muteNotifications_Lable not in listItem.window_text()]
            listItems=[listItem for listItem in listItems if new_message_pattern.search(listItem.window_text())]
            newMessageTips=[listItem.window_text() for listItem in listItems]
            senders=[listItem.automation_id().replace('session_item_','') for listItem in listItems]
            nums=[int(new_message_pattern.search(text).group(1)) for text in newMessageTips]
            newMessages_dict=dict(zip(senders,nums))
            return newMessages_dict
        
        def sacn_for_new_messages(sessionList:ListViewWrapper)->dict:
            '''扫描会话列表内的新消息,返回{'小号':3,'A群':4,'B群':5}这样的新消息列表'''
            new_message_dict={}
            full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)
            new_message_num=int(re.search(r'\d+',full_desc).group(0)) if re.search(r'\d+',full_desc) is not None else 0
            if new_message_num and scorllable:#有新消息且可以滚动的时候才滚动
                if maxPages:#max_pages设置为0，只关注顶部置顶可见的好友
                    for _ in range(maxPages):
                        traverse_result=traverse_session_list(sessionList)
                        new_message_dict.update(traverse_result)
                        sessionList.type_keys('{PGDN}',pause=scroll_delay)
                        if sum(new_message_dict.values())>=new_message_num:
                            break
                    sessionList.type_keys('{HOME}',pause=scroll_delay)
                else:#
                    traverse_result=traverse_session_list(sessionList)
                    new_message_dict.update(traverse_result)
            if new_message_num and not scorllable:
                traverse_result=traverse_session_list(sessionList)
                new_message_dict.update(traverse_result)
            return new_message_dict
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        
        newMessageDict={}
        NeverReply=Special_Labels.NeverReply#不回复的对象,这里监听时也同样不去监听
        FileTransfer_Label=Special_Labels.FileTransfer#文件传输助手
        duration=Tools.match_duration(duration)
        if not duration:raise TimeNotCorrectError
        main_window=Navigator.open_dialog_window(friend=FileTransfer_Label,is_maximize=is_maximize)#打开到文件传输助手
        weixinButton=main_window.child_window(**Buttons.WeixinButton)
        weixinButton.click_input()
        muteNotifications_Lable=Special_Labels.MuteNotifications
        new_message_pattern=Regex_Patterns.newMessage_pattern
        sessionList=main_window.child_window(**Main_window.SessionList)#左侧的会话列表
        full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)
        if re.search(r'\d+',full_desc) is not None:
            has_newMessage=True
            initial_newMessage_num=int(re.search(r'\d+',full_desc).group(0))
        else:
            has_newMessage=False
            initial_newMessage_num=0
        scorllable=Tools.is_scrollable(sessionList)#只调用一次Scrollable函数来判断会话列表是否可以滚动
        if scorllable:sessionList.type_keys('{HOME}')
        if has_newMessage:
            new_message_dict=sacn_for_new_messages(sessionList)
            newMessageDict.update(new_message_dict)
        end_timestamp=time.time()+duration
        SystemSettings.open_listening_mode()#开个不息屏,不然时间长息屏了就难办了
        #轮询监听会话列表
        while time.time()<end_timestamp:
            full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)
            if re.search(r'\d+',full_desc) is not None:
                newMessage_num=int(re.search(r'\d+',full_desc).group(0))
            else:
                newMessage_num=0
            #新消息增量
            has_newMessage=newMessage_num-initial_newMessage_num#这个是关键，得判断用不用扫描，如果没变化不用扫描
            if has_newMessage:
                new_message_dict=sacn_for_new_messages(sessionList)
                initial_newMessage_num=newMessage_num
                newMessageDict.update(new_message_dict)
        SystemSettings.close_listening_mode()#最后把不息屏关掉
        if close_weixin:main_window.close()
        return newMessageDict

    @staticmethod
    def listen_on_newMessages(duration:str,maxPages:int=0,scroll_delay:float=0.5,is_maximize:bool=None,close_weixin:bool=None)->dict:
        '''
        该方法用来遍历会话列表监听新消息,最大查找数量=maxPages*(8~10)
        Args:
            duration:监听持续时长,格式:'s','min','h'单位:s/秒,min/分,h/小时
            maxPages:遍历会话列表页数,一页为8~10人,为0时只在可见顶部置顶会话列表中查找不滚动遍历
            scroll_delay:滚动遍历maxPages页会话列表间隔
            is_maximize:微信界面是否全屏,默认全屏
            close_weixin:任务结束后是否关闭微信,默认关闭
        Returns:
            newMessageDetail:{'好友A':[{},{}],'好友B':[{},{}],...}
        '''
        def traverse_session_list(sessionList:ListViewWrapper)->dict:
            '''遍历会话列表内的lisitem获取新消息'''
            listItems=[listItem for listItem in sessionList.children(control_type='ListItem') if listItem.automation_id().replace('session_item_','') not in NeverReply
            and muteNotifications_Lable not in listItem.window_text()]
            listItems=[listItem for listItem in listItems if new_message_pattern.search(listItem.window_text())]
            newMessageTips=[listItem.window_text() for listItem in listItems]
            senders=[listItem.automation_id().replace('session_item_','') for listItem in listItems]
            nums=[int(new_message_pattern.search(text).group(1)) for text in newMessageTips]
            newMessages_dict=dict(zip(senders,nums))
            return newMessages_dict
        
        def sacn_for_new_messages(sessionList:ListViewWrapper)->dict:
            '''扫描会话列表内的新消息,返回{'小号':3,'A群':4,'B群':5}这样的新消息列表'''
            new_message_dict={}
            full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)     
            new_message_num=int(re.search(r'\d+',full_desc).group(0)) if re.search(r'\d+',full_desc) is not None else 0
            if new_message_num and scorllable:#有新消息且可以滚动的时候才滚动
                if maxPages:
                    for _ in range(maxPages):
                        traverse_result=traverse_session_list(sessionList)
                        new_message_dict.update(traverse_result)
                        sessionList.type_keys('{PGDN}',pause=scroll_delay)
                        if sum(new_message_dict.values())>=new_message_num:
                            break
                    sessionList.type_keys('{HOME}',pause=scroll_delay)
                else:#max_pages设置为0，只关注顶部置顶可见的好友
                    traverse_result=traverse_session_list(sessionList)
                    new_message_dict.update(traverse_result)
            if new_message_num and not scorllable:
                traverse_result=traverse_session_list(sessionList)
                new_message_dict.update(traverse_result)
            return new_message_dict
        
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin

        newMessageDict={}
        newMessageDetail={}
        FileTransfer_Label=Special_Labels.FileTransfer
        muteNotifications_Lable=Special_Labels.MuteNotifications
        new_message_pattern=Regex_Patterns.newMessage_pattern
        NeverReply=Special_Labels.NeverReply#不回复的对象,这里监听时也同样不去监听
        duration=Tools.match_duration(duration)
        if not duration:raise TimeNotCorrectError
        main_window=Navigator.open_dialog_window(friend=FileTransfer_Label,is_maximize=is_maximize)#打开到文件传输助手
        myName=Contacts.check_my_info(is_maximize=is_maximize,close_weixin=False).get('昵称')
        weixinButton=main_window.child_window(**Buttons.WeixinButton)
        weixinButton.click_input()
        sessionList=main_window.child_window(**Main_window.SessionList)#左侧的会话列表
        full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)
        if re.search(r'\d+',full_desc) is not None:
            has_newMessage=True
            initial_newMessage_num=int(re.search(r'\d+',full_desc).group(0))
        else:
            has_newMessage=False
            initial_newMessage_num=0
        scorllable=Tools.is_scrollable(sessionList)#只调用一次Scrollable函数来判断会话列表是否可以滚动
        if scorllable:sessionList.type_keys('{HOME}')
        if has_newMessage:
            new_message_dict=sacn_for_new_messages(sessionList)
            newMessageDict.update(new_message_dict)
        end_timestamp=time.time()+duration
        SystemSettings.open_listening_mode()#开个不息屏,不然时间长息屏了就难办了
        #轮询监听会话列表
        while time.time()<end_timestamp:
            full_desc=weixinButton.element_info.element.GetCurrentPropertyValue(30159)
            if re.search(r'\d+',full_desc) is not None:
                newMessage_num=int(re.search(r'\d+',full_desc).group(0))
            else:
                newMessage_num=0
            #新消息增量
            has_newMessage=newMessage_num-initial_newMessage_num#这个是关键，得判断用不用扫描，如果没变化不用扫描
            if has_newMessage:
                new_message_dict=sacn_for_new_messages(sessionList)
                initial_newMessage_num=newMessage_num
                newMessageDict.update(new_message_dict)
        for friend,num in newMessageDict.items():
            newMessageDetail[friend]=Messages.pull_messages(friend=friend,number=num,myName=myName,search_pages=maxPages+1,close_weixin=False)
        SystemSettings.close_listening_mode()#最后把不息屏关掉
        if close_weixin:main_window.close()
        return newMessageDetail

class Settings():

    @staticmethod
    def Log_out(is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用来退出登录当前登录的微信账号
        Args:
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        settings_window=Navigator.open_settings(is_maximize=is_maximize,close_weixin=close_weixin)
        settings_window.child_window(**Buttons.LogOutButton).click_input()
        confirm_button=settings_window.child_window(**Buttons.ConfirmButton)
        confirm_button.click_input()

    @staticmethod
    def change_style(style:int,is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用来修改微信的主题样式
        Args:
            style:主题样式,0:跟随系统,1:浅色模式,2:深色模式
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        style_map={0:'跟随系统',1:'浅色模式',2:'深色模式'}
        DarkMode=Special_Labels.DarkMode
        LightMode=Special_Labels.LightMode
        settings_window=Navigator.open_settings(is_maximize=is_maximize,close_weixin=close_weixin)
        settings_window.child_window(**Buttons.GeneralButton).click_input()
        outline_text=settings_window.child_window(**Texts.OutLineText)
        outline_button=outline_text.parent().children()[1]
        current_style=outline_button.children(control_type='Text')[0].window_text()
        outline_button.click_input()
        #弹出的菜单无论怎么都无法定位到，干脆纯按键操作
        #顺序是固定的:跟随系统,浅色模式,深色模式
        #无论怎么说先回到顶部
        if current_style==LightMode:
            pyautogui.press('up')
        if current_style==DarkMode:
            pyautogui.press('up',presses=2)
        #回到顶部后根据传入的style来选择向下按几次
        if style==1:
            pyautogui.press('down')
        if style==2:
            pyautogui.press('down',presses=2)
        pyautogui.press('enter')
        print(f'已将微信主题设置为{style_map.get(style)}')
        settings_window.close()
    
    @staticmethod
    def change_language(language:int,is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用来修改微信的语言
        Args:
            language:语言,0:跟随系统,1:简体中文,2:'English',3:'繁體中文'
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        language_map={0:'跟随系统',1:'简体中文',2:'English',3:'繁體中文'}
        settings_window=Navigator.open_settings(is_maximize=is_maximize,close_weixin=close_weixin)
        settings_window.child_window(**Buttons.GeneralButton).click_input()
        language_text=settings_window.child_window(**Texts.LanguageText)
        language_button=language_text.parent().children()[1]
        current_language=language_button.children(control_type='Text')[0].window_text()
        language_button.click_input()
        #弹出的菜单无论怎么都无法定位到，干脆纯按键操作
        #顺序是固定的:'跟随系统,简体中文,English,繁體中文
        #无论怎么说先回到顶部
        if current_language=='简体中文':
            pyautogui.press('up')
        if current_language=='English':
            pyautogui.press('up',presses=2)
        if current_language=='繁體中文':
            pyautogui.press('down',presses=1)
        #回到顶部后根据传入的style来选择向下按几次
        if language==1:
            pyautogui.press('down')
        if language==2:
            pyautogui.press('down',presses=2)
        if language==3:
            pyautogui.press('down',presses=3)
        pyautogui.press('enter')
        confirm_button=settings_window.child_window(**Buttons.ConfirmButton)
        if confirm_button.exists(timeout=0.1):
            confirm_button.click_input()
        print(f'已将微信语言设置为{language_map.get(language)},如需进行后续自动化操作,请手动登录')

    @staticmethod
    def auto_download_size(size:int=1024,state:bool=True,is_maximize:bool=None,close_weixin:bool=None):
        '''该方法用来修改微信自动下载文件大小
        Args:
            size:大小,1~1024之间的整数
            state:是否开启自动下载文件
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:任务结束后是否关闭微信，默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if size<=0:
            raise ValueError(f'size取值在1-1024之间!')
        if size>1024:
            size=1024
        settings_window=Navigator.open_settings(is_maximize=is_maximize,close_weixin=close_weixin)
        input_filed=settings_window.child_window(control_type='Text',class_name='mmui::XLineField')
        checkbox=input_filed.parent().children(control_type='CheckBox')[0]
        if state:
            input_filed.click_input()
            SystemSettings.copy_text_to_clipboard(str(size))
            pyautogui.hotkey('ctrl','a',_pause=False)
            pyautogui.press('backspace')
            pyautogui.hotkey('ctrl','v',_pause=False)
            if not checkbox.get_toggle_state():
                checkbox.click_input()
            print(f'已开启自动下载小于{size}MB文件功能')
        if not state and checkbox.get_toggle_state():
            checkbox.click_input()
            print(f'已关闭自动下载文件功能')
        settings_window.close()
    
    @staticmethod
    def change_fontsize(value:int=2,is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用来修改微信的字体大小
        Args:
            value:字体大小,1-9之间,2为标准
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:是否关闭微信，默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        if value<1 or value>10:
            raise ValueError(f"值必须在1到9 之间")
        settings_window=Navigator.open_settings(is_maximize=is_maximize,close_weixin=close_weixin)
        settings_window.child_window(**Buttons.GeneralButton).click_input()
        fontsize_text=settings_window.child_window(**Texts.FontSizeText)
        slider=fontsize_text.parent().children(control_type='Slider')[0]
        value_map={1:0,2:24,3:48,4:96,5:120,6:144,7:168,8:192,9:220}
        rec=slider.rectangle()
        y=rec.mid_point().y#y方向在中间
        x=rec.left+value_map.get(value)#增加offset然后点击,经过测试,value_map中的offset可以实现
        mouse.click(coords=(x,y))
        settings_window.close()
    
    @staticmethod
    def notification_alert(alert_map:dict={'newMessage':True,'Call':True,'Moments':True,'Game':True,'Interaction_only':True},
        is_maximize:bool=None,close_weixin:bool=None):
        '''
        该方法用于修改微信设置中的通知或声音标记
        Args:
            alert_map:微信通知标记字典,格式:{'newMessage':True,'Call':True,'Moments':True,'Game':True,'Interaction_only':True}
            is_maximize:微信界面是否全屏，默认不全屏
            close_weixin:是否关闭微信，默认关闭
        '''
        if is_maximize is None:
            is_maximize=GlobalConfig.is_maximize
        if close_weixin is None:
            close_weixin=GlobalConfig.close_weixin
        settings_window=Navigator.open_settings(is_maximize=is_maximize,close_weixin=close_weixin)
        settings_window.child_window(**Buttons.NotificationButton).click_input()
        newMessage_checkbox=settings_window.child_window(**CheckBoxes.newMessageAlertCheckBox)
        call_checkbox=settings_window.child_window(**CheckBoxes.CallAlertCheckBox)
        moments_checkbox=settings_window.child_window(**CheckBoxes.MomentsCheckBox)
        game_checkbox=settings_window.child_window(**CheckBoxes.GameCheckBox)
        interactionOnly_checkbox=settings_window.child_window(**CheckBoxes.InteractionOnlyCheckBox)
        #异或,不一样的才点checkbox
        if alert_map.get('newMessage') is not None:
            if alert_map.get('newMessage')^newMessage_checkbox.get_toggle_state():
                newMessage_checkbox.click_input()
        if alert_map.get('Call') is not None:
            if alert_map.get('Call')^call_checkbox.get_toggle_state():
                call_checkbox.click_input()
        if alert_map.get('Moments') is not None and moments_checkbox.exists(timeout=0.1):
            if alert_map.get('Moments')^moments_checkbox.get_toggle_state():
                moments_checkbox.click_input()
        if alert_map.get('Game') is not None and game_checkbox.exists(timeout=0.1):
            if alert_map.get('Game')^game_checkbox.get_toggle_state():
                game_checkbox.click_input()
        if alert_map.get('Interaction_only') is not None and interactionOnly_checkbox.exists(timeout=0.1):
            if alert_map.get('Interaction_only')^interactionOnly_checkbox.get_toggle_state():
                interactionOnly_checkbox.click_input()
        settings_window.close()